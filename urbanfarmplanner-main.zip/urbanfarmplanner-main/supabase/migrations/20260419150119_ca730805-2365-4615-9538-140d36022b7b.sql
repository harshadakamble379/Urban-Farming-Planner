
-- Public buckets serve files via direct URL; the SELECT policy only enabled
-- file LISTING, which is what the linter flags. Drop it again.
DROP POLICY IF EXISTS "Anyone can view product images" ON storage.objects;
