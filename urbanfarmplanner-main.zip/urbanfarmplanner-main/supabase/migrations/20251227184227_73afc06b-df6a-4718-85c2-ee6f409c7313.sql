-- Make storage buckets private for security
UPDATE storage.buckets 
SET public = false 
WHERE id IN ('plant-photos', 'avatars');

-- Note: product-images bucket stays public as it likely contains
-- catalog images that should be publicly accessible