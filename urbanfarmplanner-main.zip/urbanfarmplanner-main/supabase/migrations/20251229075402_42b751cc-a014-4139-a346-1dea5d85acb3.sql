-- Drop the existing view and recreate with SECURITY INVOKER
DROP VIEW IF EXISTS public.public_inventory_items;

CREATE VIEW public.public_inventory_items 
WITH (security_invoker=on)
AS 
SELECT 
  id, 
  name, 
  description, 
  category, 
  price, 
  quantity, 
  min_stock,
  unit, 
  image_url, 
  condition, 
  is_available, 
  created_at,
  updated_at
FROM inventory_items 
WHERE is_available = true;

-- Grant SELECT access on the view to anonymous and authenticated users
GRANT SELECT ON public.public_inventory_items TO anon, authenticated;