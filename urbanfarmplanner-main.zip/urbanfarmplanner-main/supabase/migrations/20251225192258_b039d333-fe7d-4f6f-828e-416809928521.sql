-- Add share_token column for public sharing of garden layouts
ALTER TABLE public.garden_layouts 
ADD COLUMN share_token TEXT UNIQUE,
ADD COLUMN is_public BOOLEAN NOT NULL DEFAULT false;

-- Create index for faster share token lookups
CREATE INDEX idx_garden_layouts_share_token ON public.garden_layouts(share_token) WHERE share_token IS NOT NULL;

-- Create policy to allow anyone to view public layouts via share token
CREATE POLICY "Anyone can view shared layouts via token" 
ON public.garden_layouts 
FOR SELECT 
USING (is_public = true AND share_token IS NOT NULL);