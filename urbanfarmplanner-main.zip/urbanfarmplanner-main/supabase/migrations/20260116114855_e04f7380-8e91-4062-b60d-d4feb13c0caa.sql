-- Drop the existing view and recreate it without user_id
DROP VIEW IF EXISTS public.public_inventory_items;

-- Create a secure view that excludes user_id to protect seller identity
CREATE VIEW public.public_inventory_items
WITH (security_invoker=on) AS
SELECT 
  id,
  price,
  quantity,
  min_stock,
  is_available,
  created_at,
  updated_at,
  image_url,
  condition,
  name,
  description,
  category,
  unit
FROM public.inventory_items
WHERE is_available = true;

-- Grant access to the view for authenticated and anon users
GRANT SELECT ON public.public_inventory_items TO authenticated;
GRANT SELECT ON public.public_inventory_items TO anon;

-- Add a comment explaining the view's purpose
COMMENT ON VIEW public.public_inventory_items IS 'Public view of available inventory items. Excludes user_id to protect seller identity from competitors.';