-- Drop the existing permissive SELECT policy that exposes user_id
DROP POLICY IF EXISTS "Anyone can view available items" ON public.inventory_items;

-- Create a new SELECT policy that only allows users to view their own items
-- Public browsing should go through the public_inventory_items view which excludes user_id
CREATE POLICY "Users can view their own items" 
ON public.inventory_items 
FOR SELECT 
USING (auth.uid() = user_id);

-- Add a comment explaining the security design
COMMENT ON TABLE public.inventory_items IS 'Private inventory table. For public product browsing, use the public_inventory_items view which excludes sensitive user_id field.';