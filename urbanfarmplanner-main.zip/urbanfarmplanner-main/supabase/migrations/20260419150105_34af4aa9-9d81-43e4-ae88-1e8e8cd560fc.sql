
-- 1) Avatars bucket — remove broad public read, restrict to owner folder
DROP POLICY IF EXISTS "Avatar images are publicly accessible" ON storage.objects;

CREATE POLICY "Users can view their own avatar"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'avatars'
  AND (auth.uid())::text = (storage.foldername(name))[1]
);

-- 2) product-images — add explicit narrow public SELECT policy
CREATE POLICY "Anyone can view product images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'product-images');

-- 3) Remove the shared-code admin escalation path entirely
DROP FUNCTION IF EXISTS public.grant_shoper_admin(text);
