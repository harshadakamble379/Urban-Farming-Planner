-- Create user_settings table for storing user preferences
CREATE TABLE public.user_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  name TEXT DEFAULT 'Urban Farmer',
  organization TEXT,
  city TEXT DEFAULT 'New York',
  climate_zone TEXT DEFAULT 'Temperate (Zone 7)',
  watering_reminders BOOLEAN DEFAULT true,
  low_inventory_alerts BOOLEAN DEFAULT true,
  growth_milestones BOOLEAN DEFAULT false,
  weekly_reports BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create plant_reminders table for watering schedules
CREATE TABLE public.plant_reminders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  plant_name TEXT NOT NULL,
  reminder_type TEXT NOT NULL DEFAULT 'watering',
  schedule_days INTEGER NOT NULL DEFAULT 3,
  last_completed_at TIMESTAMP WITH TIME ZONE,
  next_due_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN DEFAULT true,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plant_reminders ENABLE ROW LEVEL SECURITY;

-- RLS policies for user_settings
CREATE POLICY "Users can view their own settings" 
ON public.user_settings FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own settings" 
ON public.user_settings FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own settings" 
ON public.user_settings FOR UPDATE USING (auth.uid() = user_id);

-- RLS policies for plant_reminders
CREATE POLICY "Users can view their own reminders" 
ON public.plant_reminders FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own reminders" 
ON public.plant_reminders FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own reminders" 
ON public.plant_reminders FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own reminders" 
ON public.plant_reminders FOR DELETE USING (auth.uid() = user_id);

-- Triggers for updated_at
CREATE TRIGGER update_user_settings_updated_at
BEFORE UPDATE ON public.user_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_plant_reminders_updated_at
BEFORE UPDATE ON public.plant_reminders
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();