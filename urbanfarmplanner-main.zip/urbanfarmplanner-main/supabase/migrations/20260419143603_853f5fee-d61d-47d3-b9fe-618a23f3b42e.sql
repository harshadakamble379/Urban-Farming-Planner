
-- Public buckets serve files via direct URL without needing a SELECT policy.
-- The existing SELECT policy lets anyone LIST every file in the bucket, which
-- is the issue flagged by the linter. Removing it preserves public image
-- access (URLs still work) while blocking enumeration.
DROP POLICY IF EXISTS "Anyone can view product images" ON storage.objects;
