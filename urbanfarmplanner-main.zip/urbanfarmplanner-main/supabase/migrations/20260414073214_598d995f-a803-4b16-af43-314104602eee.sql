
-- Allow authenticated users to view all orders (for shoper admin)
CREATE POLICY "Authenticated users can view all orders"
ON public.orders
FOR SELECT
TO authenticated
USING (true);

-- Allow authenticated users to view all order items
CREATE POLICY "Authenticated users can view all order items"
ON public.order_items
FOR SELECT
TO authenticated
USING (true);

-- Allow authenticated users to update any inventory item (for shoper admin)
CREATE POLICY "Authenticated users can update any inventory item"
ON public.inventory_items
FOR UPDATE
TO authenticated
USING (true);

-- Allow authenticated users to update any order
CREATE POLICY "Authenticated users can update any order"
ON public.orders
FOR UPDATE
TO authenticated
USING (true);
