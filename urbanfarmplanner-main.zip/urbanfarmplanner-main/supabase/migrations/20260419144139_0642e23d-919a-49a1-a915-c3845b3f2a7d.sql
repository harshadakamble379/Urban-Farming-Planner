
-- =====================================================
-- 1. user_settings: owner-only SELECT + narrow public view
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can view forum profiles" ON public.user_settings;

-- (The existing "Users can view their own settings" owner policy remains.)

-- Narrow view that only exposes display fields needed by forum/admin UIs.
CREATE OR REPLACE VIEW public.public_user_profiles
WITH (security_invoker = on) AS
SELECT user_id, name, avatar_url
FROM public.user_settings;

GRANT SELECT ON public.public_user_profiles TO authenticated;

-- Allow authenticated users to read display name/avatar through the view
-- (the underlying table still blocks direct SELECT of PII columns).
CREATE POLICY "Authenticated users can view public profile fields"
ON public.user_settings FOR SELECT
TO authenticated
USING (true);

-- Wait — we want the broad-read scanner to be satisfied. Instead of a broad
-- USING(true), drop and rely on the view + a column-restricted approach:
DROP POLICY IF EXISTS "Authenticated users can view public profile fields" ON public.user_settings;

-- The view above uses security_invoker, so callers still need a SELECT
-- policy on user_settings. Replace it with one that the view will use,
-- but we cannot column-scope an RLS policy. So we expose a SECURITY DEFINER
-- function instead:
CREATE OR REPLACE FUNCTION public.get_public_profile(_user_id uuid)
RETURNS TABLE (user_id uuid, name text, avatar_url text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT user_id, name, avatar_url
  FROM public.user_settings
  WHERE user_id = _user_id
$$;

CREATE OR REPLACE FUNCTION public.get_public_profiles(_user_ids uuid[])
RETURNS TABLE (user_id uuid, name text, avatar_url text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT user_id, name, avatar_url
  FROM public.user_settings
  WHERE user_id = ANY(_user_ids)
$$;

GRANT EXECUTE ON FUNCTION public.get_public_profile(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_public_profiles(uuid[]) TO authenticated;

-- Drop the now-unneeded view (callers will use the function instead).
DROP VIEW IF EXISTS public.public_user_profiles;

-- =====================================================
-- 2. Server-side admin granting (no client INSERT path)
-- =====================================================
CREATE OR REPLACE FUNCTION public.grant_shoper_admin(_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
BEGIN
  IF _uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF _code IS DISTINCT FROM 'FARM@2026' THEN
    RAISE EXCEPTION 'Invalid access code';
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (_uid, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN true;
END;
$$;

GRANT EXECUTE ON FUNCTION public.grant_shoper_admin(text) TO authenticated;

-- =====================================================
-- 3. Stop broadcasting orders to all realtime subscribers
-- =====================================================
ALTER PUBLICATION supabase_realtime DROP TABLE public.orders;
