-- Drop the existing restrictive SELECT policy
DROP POLICY IF EXISTS "Users can view their own items" ON public.inventory_items;

-- Create a new policy that allows anyone to view available items (for the shop)
CREATE POLICY "Anyone can view available items"
ON public.inventory_items
FOR SELECT
USING (is_available = true);

-- Create a separate policy for owners to view ALL their items (including unavailable)
CREATE POLICY "Owners can view all their items"
ON public.inventory_items
FOR SELECT
USING (auth.uid() = user_id);