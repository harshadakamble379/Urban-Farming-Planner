-- Create storage bucket for plant photos
INSERT INTO storage.buckets (id, name, public) 
VALUES ('plant-photos', 'plant-photos', true);

-- Storage policies for plant photos
CREATE POLICY "Users can view all plant photos" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'plant-photos');

CREATE POLICY "Users can upload their own plant photos" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'plant-photos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own plant photos" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'plant-photos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own plant photos" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'plant-photos' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create plant health logs table
CREATE TABLE public.plant_health_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  plant_name TEXT NOT NULL,
  health_status TEXT NOT NULL DEFAULT 'healthy',
  notes TEXT,
  photo_url TEXT,
  height_cm DECIMAL,
  leaves_count INTEGER,
  temperature_celsius DECIMAL,
  humidity_percent DECIMAL,
  logged_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.plant_health_logs ENABLE ROW LEVEL SECURITY;

-- RLS policies for plant health logs
CREATE POLICY "Users can view their own health logs" 
ON public.plant_health_logs FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own health logs" 
ON public.plant_health_logs FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own health logs" 
ON public.plant_health_logs FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own health logs" 
ON public.plant_health_logs FOR DELETE USING (auth.uid() = user_id);