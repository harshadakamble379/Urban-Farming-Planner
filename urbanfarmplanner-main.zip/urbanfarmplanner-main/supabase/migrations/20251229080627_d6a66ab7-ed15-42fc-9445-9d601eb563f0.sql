-- Add CHECK constraints to reviews table for server-side validation
-- This prevents bypassing client-side validation with direct API calls

ALTER TABLE public.reviews 
ADD CONSTRAINT reviews_title_length CHECK (title IS NULL OR length(title) <= 100);

ALTER TABLE public.reviews 
ADD CONSTRAINT reviews_comment_length CHECK (comment IS NULL OR length(comment) <= 1000);

ALTER TABLE public.reviews 
ADD CONSTRAINT reviews_rating_range CHECK (rating >= 1 AND rating <= 5);