
-- =====================================================
-- 1. CREATE ROLES INFRASTRUCTURE (for Shoper admins)
-- =====================================================
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
ON public.user_roles FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles"
ON public.user_roles FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- =====================================================
-- 2. FIX: orders – remove broad authenticated access
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can view all orders" ON public.orders;
DROP POLICY IF EXISTS "Authenticated users can update any order" ON public.orders;

CREATE POLICY "Admins can view all orders"
ON public.orders FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update any order"
ON public.orders FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- order_items: same restriction
DROP POLICY IF EXISTS "Authenticated users can view all order items" ON public.order_items;

CREATE POLICY "Admins can view all order items"
ON public.order_items FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- =====================================================
-- 3. FIX: inventory_items – remove broad update policy
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can update any inventory item" ON public.inventory_items;

CREATE POLICY "Admins can update any inventory item"
ON public.inventory_items FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- =====================================================
-- 4. FIX: plant-photos storage bucket – restrict to owner
-- =====================================================
DROP POLICY IF EXISTS "Users can view all plant photos" ON storage.objects;

CREATE POLICY "Users can view their own plant photos"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'plant-photos'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- =====================================================
-- 5. FIX: user_settings – remove anonymous PII exposure
-- =====================================================
DROP POLICY IF EXISTS "Anyone can view user profiles for forum" ON public.user_settings;

CREATE POLICY "Authenticated users can view forum profiles"
ON public.user_settings FOR SELECT
TO authenticated
USING (true);
