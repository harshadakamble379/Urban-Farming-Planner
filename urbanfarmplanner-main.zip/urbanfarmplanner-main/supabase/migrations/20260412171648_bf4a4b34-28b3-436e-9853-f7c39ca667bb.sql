
CREATE POLICY "Anyone can view user profiles for forum"
ON public.user_settings
FOR SELECT
TO public
USING (true);
