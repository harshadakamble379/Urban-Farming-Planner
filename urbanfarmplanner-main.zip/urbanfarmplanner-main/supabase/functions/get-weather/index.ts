import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema with proper coordinate ranges
const WeatherRequestSchema = z.object({
  lat: z.number({ invalid_type_error: "Latitude must be a number" })
    .min(-90, "Latitude must be between -90 and 90")
    .max(90, "Latitude must be between -90 and 90"),
  lon: z.number({ invalid_type_error: "Longitude must be a number" })
    .min(-180, "Longitude must be between -180 and 180")
    .max(180, "Longitude must be between -180 and 180"),
  forecast: z.boolean().optional().default(false),
});

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse and validate request body
    let requestBody: unknown;
    try {
      requestBody = await req.json();
    } catch {
      console.error("Invalid JSON in request body");
      return new Response(
        JSON.stringify({ error: "Invalid JSON in request body" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate with zod schema
    const parsed = WeatherRequestSchema.safeParse(requestBody);
    if (!parsed.success) {
      const errorMessage = parsed.error.errors.map(e => e.message).join(", ");
      console.error("Validation error:", errorMessage);
      return new Response(
        JSON.stringify({ error: `Invalid coordinates: ${errorMessage}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { lat, lon, forecast } = parsed.data;
    console.log("Fetching weather for coordinates:", { lat, lon, forecast });

    // Use Open-Meteo API (free, no API key required)
    const forecastParams = forecast
      ? "&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_sum,wind_speed_10m_max&forecast_days=7"
      : "";
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m${forecastParams}&timezone=auto`;

    // Retry up to 3 times to handle transient TLS/network errors
    let lastError: Error | null = null;
    let data: any = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await fetch(weatherUrl);
        if (!response.ok) {
          throw new Error(`Weather API error: ${response.statusText}`);
        }
        data = await response.json();
        lastError = null;
        break;
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));
        console.warn(`Weather fetch attempt ${attempt + 1} failed:`, lastError.message);
        if (attempt < 2) await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
      }
    }

    if (lastError || !data) {
      throw lastError || new Error("Failed after retries");
    }

    const weatherData: any = {
      temperature: Math.round(data.current.temperature_2m),
      humidity: data.current.relative_humidity_2m,
      windSpeed: data.current.wind_speed_10m,
      weatherCode: data.current.weather_code,
      unit: data.current_units.temperature_2m,
      timestamp: new Date().toISOString(),
    };

    if (forecast && data.daily) {
      weatherData.forecast = data.daily.time.map((date: string, i: number) => ({
        date,
        tempMax: Math.round(data.daily.temperature_2m_max[i]),
        tempMin: Math.round(data.daily.temperature_2m_min[i]),
        weatherCode: data.daily.weather_code[i],
        precipitation: data.daily.precipitation_sum[i],
        windSpeed: data.daily.wind_speed_10m_max[i],
      }));
    }

    console.log("Weather data fetched successfully");

    return new Response(JSON.stringify(weatherData), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error fetching weather:", error);
    // Return generic error message to client (don't expose internal details)
    return new Response(
      JSON.stringify({ error: "Failed to fetch weather data" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
