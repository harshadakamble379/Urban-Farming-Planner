export type Season = 'spring' | 'summer' | 'monsoon' | 'autumn' | 'winter';
export type ClimateZone = 'tropical' | 'subtropical' | 'temperate' | 'arid' | 'mediterranean';

export interface PlantingWindow {
  seedName: string;
  category: string;
  optimalMonths: number[]; // 1-12
  sowingType: 'direct' | 'indoor' | 'both';
  germinationTemp: { min: number; max: number };
  notes: string;
}

export const plantingCalendarData: PlantingWindow[] = [
  // Vegetables
  {
    seedName: 'Tomato Seeds',
    category: 'Vegetable Seeds',
    optimalMonths: [2, 3, 4, 6, 7],
    sowingType: 'indoor',
    germinationTemp: { min: 18, max: 29 },
    notes: 'Start indoors 6-8 weeks before last frost. Transplant after soil warms.'
  },
  {
    seedName: 'Chili Pepper Seeds',
    category: 'Vegetable Seeds',
    optimalMonths: [2, 3, 4, 6, 7],
    sowingType: 'indoor',
    germinationTemp: { min: 21, max: 32 },
    notes: 'Start indoors early. Needs warm soil to thrive.'
  },
  {
    seedName: 'Spinach Seeds',
    category: 'Vegetable Seeds',
    optimalMonths: [2, 3, 9, 10, 11],
    sowingType: 'direct',
    germinationTemp: { min: 7, max: 24 },
    notes: 'Cool season crop. Avoid hot summer months. Succession plant every 2 weeks.'
  },
  {
    seedName: 'Cucumber Seeds',
    category: 'Vegetable Seeds',
    optimalMonths: [3, 4, 5, 6],
    sowingType: 'direct',
    germinationTemp: { min: 16, max: 35 },
    notes: 'Plant after last frost when soil is warm. Needs consistent moisture.'
  },
  {
    seedName: 'Brinjal Seeds',
    category: 'Vegetable Seeds',
    optimalMonths: [2, 3, 6, 7],
    sowingType: 'indoor',
    germinationTemp: { min: 21, max: 32 },
    notes: 'Start indoors 8-10 weeks before transplanting. Loves heat.'
  },
  {
    seedName: 'Carrot Seeds',
    category: 'Vegetable Seeds',
    optimalMonths: [2, 3, 4, 8, 9, 10],
    sowingType: 'direct',
    germinationTemp: { min: 7, max: 29 },
    notes: 'Direct sow only. Keep soil moist until germination. Thin seedlings.'
  },
  {
    seedName: 'Okra Seeds',
    category: 'Vegetable Seeds',
    optimalMonths: [4, 5, 6, 7],
    sowingType: 'direct',
    germinationTemp: { min: 21, max: 35 },
    notes: 'Soak seeds overnight. Plant when soil is warm. Loves hot weather.'
  },
  // Herbs
  {
    seedName: 'Coriander Seeds',
    category: 'Herb Seeds',
    optimalMonths: [3, 4, 9, 10, 11],
    sowingType: 'direct',
    germinationTemp: { min: 13, max: 24 },
    notes: 'Direct sow. Bolts in heat. Succession plant every 2-3 weeks.'
  },
  {
    seedName: 'Mint Seeds',
    category: 'Herb Seeds',
    optimalMonths: [3, 4, 5, 9, 10],
    sowingType: 'indoor',
    germinationTemp: { min: 15, max: 24 },
    notes: 'Start indoors. Very invasive - grow in containers.'
  },
  {
    seedName: 'Basil Seeds',
    category: 'Herb Seeds',
    optimalMonths: [3, 4, 5, 6],
    sowingType: 'both',
    germinationTemp: { min: 18, max: 29 },
    notes: 'Frost sensitive. Start indoors or direct sow after frost.'
  },
  {
    seedName: 'Oregano Seeds',
    category: 'Herb Seeds',
    optimalMonths: [3, 4, 5, 9],
    sowingType: 'indoor',
    germinationTemp: { min: 15, max: 21 },
    notes: 'Surface sow - needs light to germinate. Perennial in mild climates.'
  },
  {
    seedName: 'Rosemary Seeds',
    category: 'Herb Seeds',
    optimalMonths: [3, 4, 5],
    sowingType: 'indoor',
    germinationTemp: { min: 18, max: 24 },
    notes: 'Very slow to germinate. Better grown from cuttings.'
  },
  // Flowers
  {
    seedName: 'Sunflower Seeds',
    category: 'Flower Seeds',
    optimalMonths: [3, 4, 5, 6],
    sowingType: 'direct',
    germinationTemp: { min: 18, max: 29 },
    notes: 'Direct sow after frost. Stake tall varieties.'
  },
  {
    seedName: 'Marigold Seeds',
    category: 'Flower Seeds',
    optimalMonths: [3, 4, 5, 6],
    sowingType: 'both',
    germinationTemp: { min: 18, max: 24 },
    notes: 'Easy to grow. Start indoors or direct sow after frost.'
  },
  {
    seedName: 'Lavender Seeds',
    category: 'Flower Seeds',
    optimalMonths: [2, 3, 4],
    sowingType: 'indoor',
    germinationTemp: { min: 15, max: 21 },
    notes: 'Cold stratify for 3-4 weeks. Start indoors early.'
  },
  {
    seedName: 'Rose Seeds',
    category: 'Flower Seeds',
    optimalMonths: [1, 2, 3],
    sowingType: 'indoor',
    germinationTemp: { min: 15, max: 21 },
    notes: 'Cold stratify for 6-8 weeks. Very slow to establish.'
  },
  {
    seedName: 'Zinnia Seeds',
    category: 'Flower Seeds',
    optimalMonths: [4, 5, 6],
    sowingType: 'direct',
    germinationTemp: { min: 21, max: 29 },
    notes: 'Direct sow after frost. Fast growing annual.'
  },
  // Fruits
  {
    seedName: 'Strawberry Seeds',
    category: 'Fruit Seeds',
    optimalMonths: [1, 2, 3],
    sowingType: 'indoor',
    germinationTemp: { min: 15, max: 21 },
    notes: 'Cold stratify. Start indoors under lights. Slow to establish.'
  },
  {
    seedName: 'Watermelon Seeds',
    category: 'Fruit Seeds',
    optimalMonths: [4, 5, 6],
    sowingType: 'both',
    germinationTemp: { min: 21, max: 35 },
    notes: 'Needs warm soil. Plant in mounds. Long growing season.'
  },
  {
    seedName: 'Lemon Seeds',
    category: 'Fruit Seeds',
    optimalMonths: [3, 4, 5, 6],
    sowingType: 'indoor',
    germinationTemp: { min: 21, max: 29 },
    notes: 'Plant fresh seeds. Keep warm and moist. Takes years to fruit.'
  },
  // Indoor Plants (year-round)
  {
    seedName: 'Peace Lily Seeds',
    category: 'Indoor Plants',
    optimalMonths: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    sowingType: 'indoor',
    germinationTemp: { min: 18, max: 27 },
    notes: 'Usually propagated by division. Can plant year-round indoors.'
  },
  {
    seedName: 'Snake Plant Seeds',
    category: 'Indoor Plants',
    optimalMonths: [3, 4, 5, 6, 7, 8, 9],
    sowingType: 'indoor',
    germinationTemp: { min: 21, max: 29 },
    notes: 'Usually propagated by division or leaf cuttings. Very hardy.'
  },
  {
    seedName: 'Aloe Vera Seeds',
    category: 'Indoor Plants',
    optimalMonths: [4, 5, 6, 7, 8],
    sowingType: 'indoor',
    germinationTemp: { min: 21, max: 29 },
    notes: 'Usually propagated from pups. Seeds are slow to germinate.'
  }
];

export const monthNames = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

export const getPlantingInfo = (seedName: string): PlantingWindow | undefined => {
  return plantingCalendarData.find(p => p.seedName === seedName);
};

export const getSeedsForMonth = (month: number): PlantingWindow[] => {
  return plantingCalendarData.filter(p => p.optimalMonths.includes(month));
};

export const isOptimalMonth = (seedName: string, month: number): boolean => {
  const info = getPlantingInfo(seedName);
  return info?.optimalMonths.includes(month) || false;
};

export const getCurrentMonthSeeds = (): PlantingWindow[] => {
  const currentMonth = new Date().getMonth() + 1;
  return getSeedsForMonth(currentMonth);
};
