export interface GrowthStage {
  name: string;
  daysFromStart: number;
  description: string;
}

export interface SupplyItem {
  name: string;
  quantity: number;
  unit: string;
  category: "seeds" | "soil" | "fertilizer" | "tools" | "containers";
  pricePerUnit: number;
}

export type PlantFamily = "flowering" | "foliage" | "palm" | "succulent" | "fern" | "vine" | "herb";
export type SoilImpact = "heavy-feeder" | "moderate-feeder" | "light-feeder" | "nitrogen-fixer";

export const BALCONY_FRIENDLY_PLANTS = [
  "Cherry Tomato", "Basil", "Green Chili", "Mint", "Lettuce",
  "Spinach", "Strawberry", "Coriander", "Spring Onion", "Radish",
  "Lavender", "Aloe Vera", "Snake Plant", "Money Plant", "Spider Plant"
];

export interface PlantInfo {
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  daysToHarvest: number;
  growthStages: GrowthStage[];
  waterPerWeek: number;
  sunRequirement: "full" | "partial" | "shade";
  supplies: SupplyItem[];
  companions: string[];
  incompatible: string[];
  family: PlantFamily;
  soilImpact: SoilImpact;
  oxygenOutput?: "very-high" | "high" | "medium" | "low";
}

export const plantData: PlantInfo[] = [
  // Flowering Plants
  {
    type: "fruit",
    name: "Peace Lily",
    daysToHarvest: 45,
    waterPerWeek: 10,
    sunRequirement: "shade",
    companions: ["Snake Plant", "Spider Plant"],
    incompatible: [],
    family: "flowering",
    soilImpact: "moderate-feeder",
    oxygenOutput: "high",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "New plant establishes roots" },
      { name: "Growth", daysFromStart: 14, description: "Leaves develop and expand" },
      { name: "Maturing", daysFromStart: 30, description: "Plant reaches full size" },
      { name: "Blooming", daysFromStart: 45, description: "White flowers appear" },
    ],
    supplies: [
      { name: "Peace Lily plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 12.00 },
      { name: "Indoor potting mix", quantity: 4, unit: "liters", category: "soil", pricePerUnit: 1.20 },
      { name: "Decorative pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 15.00 },
    ],
  },
  {
    type: "fruit",
    name: "Jasmine",
    daysToHarvest: 90,
    waterPerWeek: 12,
    sunRequirement: "full",
    companions: ["Lavender", "Hibiscus"],
    incompatible: [],
    family: "flowering",
    soilImpact: "moderate-feeder",
    oxygenOutput: "high",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Plant establishes in new location" },
      { name: "Vegetative", daysFromStart: 21, description: "Vine grows and spreads" },
      { name: "Budding", daysFromStart: 60, description: "Flower buds form" },
      { name: "Blooming", daysFromStart: 90, description: "Fragrant white flowers bloom" },
    ],
    supplies: [
      { name: "Jasmine plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 15.00 },
      { name: "Well-draining soil", quantity: 6, unit: "liters", category: "soil", pricePerUnit: 1.00 },
      { name: "Trellis", quantity: 1, unit: "pcs", category: "tools", pricePerUnit: 8.00 },
    ],
  },
  {
    type: "fruit",
    name: "Orchid",
    daysToHarvest: 120,
    waterPerWeek: 5,
    sunRequirement: "partial",
    companions: ["Peace Lily", "Anthurium"],
    incompatible: [],
    family: "flowering",
    soilImpact: "light-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Adjustment", daysFromStart: 0, description: "Plant adjusts to environment" },
      { name: "Root Growth", daysFromStart: 30, description: "New roots develop" },
      { name: "Spike Formation", daysFromStart: 75, description: "Flower spike emerges" },
      { name: "Blooming", daysFromStart: 120, description: "Exotic blooms open" },
    ],
    supplies: [
      { name: "Orchid plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 25.00 },
      { name: "Orchid bark mix", quantity: 2, unit: "liters", category: "soil", pricePerUnit: 3.00 },
      { name: "Clear orchid pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 6.00 },
    ],
  },
  {
    type: "herb",
    name: "Lavender",
    daysToHarvest: 180,
    waterPerWeek: 4,
    sunRequirement: "full",
    companions: ["Jasmine", "Rosemary"],
    incompatible: ["Mint"],
    family: "herb",
    soilImpact: "light-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout slowly" },
      { name: "Seedling", daysFromStart: 30, description: "Small silvery leaves appear" },
      { name: "Vegetative", daysFromStart: 90, description: "Bush forms" },
      { name: "Flowering", daysFromStart: 180, description: "Purple flower spikes bloom" },
    ],
    supplies: [
      { name: "Lavender seeds", quantity: 10, unit: "pcs", category: "seeds", pricePerUnit: 0.20 },
      { name: "Sandy soil mix", quantity: 5, unit: "liters", category: "soil", pricePerUnit: 0.90 },
      { name: "Terracotta pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 10.00 },
    ],
  },
  {
    type: "fruit",
    name: "Gerbera Daisy",
    daysToHarvest: 120,
    waterPerWeek: 10,
    sunRequirement: "full",
    companions: ["Chrysanthemum", "Anthurium"],
    incompatible: [],
    family: "flowering",
    soilImpact: "moderate-feeder",
    oxygenOutput: "very-high",
    growthStages: [
      { name: "Seedling", daysFromStart: 0, description: "Seeds germinate" },
      { name: "Rosette", daysFromStart: 35, description: "Leaves form rosette" },
      { name: "Budding", daysFromStart: 80, description: "Flower buds emerge" },
      { name: "Blooming", daysFromStart: 120, description: "Vibrant flowers open" },
    ],
    supplies: [
      { name: "Gerbera seeds", quantity: 5, unit: "pcs", category: "seeds", pricePerUnit: 0.50 },
      { name: "Rich potting mix", quantity: 4, unit: "liters", category: "soil", pricePerUnit: 1.50 },
      { name: "Flower fertilizer", quantity: 100, unit: "g", category: "fertilizer", pricePerUnit: 0.03 },
    ],
  },
  // High Oxygen Producers
  {
    type: "leafy",
    name: "Areca Palm",
    daysToHarvest: 365,
    waterPerWeek: 15,
    sunRequirement: "partial",
    companions: ["Snake Plant", "Money Plant"],
    incompatible: [],
    family: "palm",
    soilImpact: "moderate-feeder",
    oxygenOutput: "very-high",
    growthStages: [
      { name: "Establishment", daysFromStart: 0, description: "Palm adjusts to location" },
      { name: "Root Development", daysFromStart: 60, description: "Strong roots form" },
      { name: "Frond Growth", daysFromStart: 180, description: "New fronds emerge" },
      { name: "Mature", daysFromStart: 365, description: "Full size palm" },
    ],
    supplies: [
      { name: "Areca Palm", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 35.00 },
      { name: "Palm potting mix", quantity: 10, unit: "liters", category: "soil", pricePerUnit: 1.20 },
      { name: "Large pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 25.00 },
    ],
  },
  {
    type: "leafy",
    name: "Snake Plant",
    daysToHarvest: 60,
    waterPerWeek: 3,
    sunRequirement: "shade",
    companions: ["Peace Lily", "Areca Palm", "Spider Plant"],
    incompatible: [],
    family: "succulent",
    soilImpact: "light-feeder",
    oxygenOutput: "very-high",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Plant settles in" },
      { name: "Root Growth", daysFromStart: 21, description: "Roots establish" },
      { name: "Leaf Growth", daysFromStart: 40, description: "New leaves emerge" },
      { name: "Established", daysFromStart: 60, description: "Plant is thriving" },
    ],
    supplies: [
      { name: "Snake Plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 18.00 },
      { name: "Cactus mix", quantity: 3, unit: "liters", category: "soil", pricePerUnit: 1.50 },
      { name: "Modern pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 12.00 },
    ],
  },
  {
    type: "leafy",
    name: "Money Plant",
    daysToHarvest: 30,
    waterPerWeek: 8,
    sunRequirement: "partial",
    companions: ["Spider Plant", "Snake Plant"],
    incompatible: [],
    family: "vine",
    soilImpact: "light-feeder",
    oxygenOutput: "high",
    growthStages: [
      { name: "Cutting", daysFromStart: 0, description: "Cutting placed in soil/water" },
      { name: "Rooting", daysFromStart: 10, description: "Roots develop" },
      { name: "Growing", daysFromStart: 20, description: "Vine begins to trail" },
      { name: "Established", daysFromStart: 30, description: "Healthy growth" },
    ],
    supplies: [
      { name: "Money Plant cutting", quantity: 3, unit: "pcs", category: "seeds", pricePerUnit: 3.00 },
      { name: "All-purpose soil", quantity: 3, unit: "liters", category: "soil", pricePerUnit: 0.80 },
      { name: "Hanging basket", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 8.00 },
    ],
  },
  {
    type: "herb",
    name: "Aloe Vera",
    daysToHarvest: 90,
    waterPerWeek: 3,
    sunRequirement: "partial",
    companions: ["Snake Plant", "Lavender"],
    incompatible: [],
    family: "succulent",
    soilImpact: "light-feeder",
    oxygenOutput: "high",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Aloe planted in dry soil" },
      { name: "Rooting", daysFromStart: 21, description: "Roots establish" },
      { name: "Growing", daysFromStart: 50, description: "New leaves form" },
      { name: "Mature", daysFromStart: 90, description: "Ready for gel harvest" },
    ],
    supplies: [
      { name: "Aloe Vera plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 8.00 },
      { name: "Succulent mix", quantity: 3, unit: "liters", category: "soil", pricePerUnit: 1.80 },
      { name: "Terracotta pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 6.00 },
    ],
  },
  {
    type: "leafy",
    name: "Spider Plant",
    daysToHarvest: 45,
    waterPerWeek: 10,
    sunRequirement: "partial",
    companions: ["Money Plant", "Snake Plant", "Peace Lily"],
    incompatible: [],
    family: "foliage",
    soilImpact: "moderate-feeder",
    oxygenOutput: "very-high",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Plant or baby spider planted" },
      { name: "Rooting", daysFromStart: 14, description: "Roots develop" },
      { name: "Growing", daysFromStart: 30, description: "Leaves cascade outward" },
      { name: "Producing", daysFromStart: 45, description: "Baby spiders appear" },
    ],
    supplies: [
      { name: "Spider Plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 10.00 },
      { name: "All-purpose potting mix", quantity: 4, unit: "liters", category: "soil", pricePerUnit: 1.00 },
      { name: "Hanging pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 10.00 },
    ],
  },
  {
    type: "leafy",
    name: "Boston Fern",
    daysToHarvest: 60,
    waterPerWeek: 15,
    sunRequirement: "partial",
    companions: ["Peace Lily", "Spider Plant"],
    incompatible: [],
    family: "fern",
    soilImpact: "moderate-feeder",
    oxygenOutput: "very-high",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Fern placed in humid spot" },
      { name: "Adjustment", daysFromStart: 14, description: "Plant adjusts" },
      { name: "Frond Growth", daysFromStart: 35, description: "New fronds unfurl" },
      { name: "Lush", daysFromStart: 60, description: "Full lush appearance" },
    ],
    supplies: [
      { name: "Boston Fern", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 15.00 },
      { name: "Peat-based mix", quantity: 5, unit: "liters", category: "soil", pricePerUnit: 1.30 },
      { name: "Hanging basket", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 12.00 },
    ],
  },
  {
    type: "leafy",
    name: "Rubber Plant",
    daysToHarvest: 120,
    waterPerWeek: 8,
    sunRequirement: "partial",
    companions: ["Areca Palm", "Snake Plant"],
    incompatible: [],
    family: "foliage",
    soilImpact: "moderate-feeder",
    oxygenOutput: "very-high",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Plant settles in" },
      { name: "Root Development", daysFromStart: 30, description: "Roots grow strong" },
      { name: "Leaf Production", daysFromStart: 70, description: "New glossy leaves appear" },
      { name: "Growing", daysFromStart: 120, description: "Steady upward growth" },
    ],
    supplies: [
      { name: "Rubber Plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 22.00 },
      { name: "Rich potting mix", quantity: 6, unit: "liters", category: "soil", pricePerUnit: 1.20 },
      { name: "Large decorative pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 20.00 },
    ],
  },
  // Balcony Food Plants
  {
    type: "vegetable",
    name: "Cherry Tomato",
    daysToHarvest: 70,
    waterPerWeek: 12,
    sunRequirement: "full",
    companions: ["Basil", "Coriander"],
    incompatible: ["Green Chili"],
    family: "herb",
    soilImpact: "heavy-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout in 5-10 days" },
      { name: "Seedling", daysFromStart: 14, description: "First true leaves appear" },
      { name: "Vegetative", daysFromStart: 35, description: "Plant grows bushy" },
      { name: "Fruiting", daysFromStart: 70, description: "Red cherry tomatoes ripen" },
    ],
    supplies: [
      { name: "Cherry Tomato seeds", quantity: 10, unit: "pcs", category: "seeds", pricePerUnit: 0.50 },
      { name: "Potting mix", quantity: 5, unit: "liters", category: "soil", pricePerUnit: 1.00 },
      { name: "Container pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 8.00 },
    ],
  },
  {
    type: "herb",
    name: "Basil",
    daysToHarvest: 30,
    waterPerWeek: 8,
    sunRequirement: "full",
    companions: ["Cherry Tomato", "Coriander"],
    incompatible: [],
    family: "herb",
    soilImpact: "light-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout in 5-7 days" },
      { name: "Seedling", daysFromStart: 10, description: "Small aromatic leaves" },
      { name: "Growing", daysFromStart: 20, description: "Bushy growth" },
      { name: "Harvest", daysFromStart: 30, description: "Ready for continuous picking" },
    ],
    supplies: [
      { name: "Basil seeds", quantity: 15, unit: "pcs", category: "seeds", pricePerUnit: 0.20 },
      { name: "Herb potting mix", quantity: 3, unit: "liters", category: "soil", pricePerUnit: 1.20 },
      { name: "Small pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 5.00 },
    ],
  },
  {
    type: "vegetable",
    name: "Green Chili",
    daysToHarvest: 65,
    waterPerWeek: 10,
    sunRequirement: "full",
    companions: ["Basil", "Coriander"],
    incompatible: [],
    family: "herb",
    soilImpact: "moderate-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout in 7-14 days" },
      { name: "Seedling", daysFromStart: 21, description: "Small plant establishes" },
      { name: "Flowering", daysFromStart: 45, description: "White flowers appear" },
      { name: "Fruiting", daysFromStart: 65, description: "Green chilies ready to pick" },
    ],
    supplies: [
      { name: "Green Chili seeds", quantity: 10, unit: "pcs", category: "seeds", pricePerUnit: 0.40 },
      { name: "Potting mix", quantity: 4, unit: "liters", category: "soil", pricePerUnit: 1.00 },
      { name: "Medium pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 7.00 },
    ],
  },
  {
    type: "herb",
    name: "Mint",
    daysToHarvest: 21,
    waterPerWeek: 12,
    sunRequirement: "partial",
    companions: ["Lettuce", "Spinach"],
    incompatible: ["Lavender"],
    family: "herb",
    soilImpact: "moderate-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Cutting or seed planted" },
      { name: "Rooting", daysFromStart: 7, description: "Roots establish" },
      { name: "Spreading", daysFromStart: 14, description: "Runners spread" },
      { name: "Harvest", daysFromStart: 21, description: "Lush mint ready" },
    ],
    supplies: [
      { name: "Mint plant", quantity: 1, unit: "pcs", category: "seeds", pricePerUnit: 6.00 },
      { name: "Potting mix", quantity: 3, unit: "liters", category: "soil", pricePerUnit: 0.80 },
      { name: "Wide pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 6.00 },
    ],
  },
  {
    type: "leafy",
    name: "Lettuce",
    daysToHarvest: 40,
    waterPerWeek: 10,
    sunRequirement: "partial",
    companions: ["Mint", "Radish", "Spring Onion"],
    incompatible: [],
    family: "herb",
    soilImpact: "light-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout in 3-7 days" },
      { name: "Seedling", daysFromStart: 10, description: "Small leaves emerge" },
      { name: "Growing", daysFromStart: 25, description: "Leaves fill out" },
      { name: "Harvest", daysFromStart: 40, description: "Cut-and-come-again harvest" },
    ],
    supplies: [
      { name: "Lettuce seeds", quantity: 20, unit: "pcs", category: "seeds", pricePerUnit: 0.15 },
      { name: "Potting mix", quantity: 4, unit: "liters", category: "soil", pricePerUnit: 1.00 },
      { name: "Rectangular planter", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 10.00 },
    ],
  },
  {
    type: "leafy",
    name: "Spinach",
    daysToHarvest: 45,
    waterPerWeek: 10,
    sunRequirement: "partial",
    companions: ["Lettuce", "Radish"],
    incompatible: [],
    family: "herb",
    soilImpact: "moderate-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout in 5-9 days" },
      { name: "Seedling", daysFromStart: 14, description: "First leaves appear" },
      { name: "Growing", daysFromStart: 30, description: "Leaves grow large" },
      { name: "Harvest", daysFromStart: 45, description: "Pick outer leaves" },
    ],
    supplies: [
      { name: "Spinach seeds", quantity: 20, unit: "pcs", category: "seeds", pricePerUnit: 0.12 },
      { name: "Rich potting mix", quantity: 4, unit: "liters", category: "soil", pricePerUnit: 1.20 },
      { name: "Deep planter", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 9.00 },
    ],
  },
  {
    type: "fruit",
    name: "Strawberry",
    daysToHarvest: 90,
    waterPerWeek: 10,
    sunRequirement: "full",
    companions: ["Lettuce", "Spinach"],
    incompatible: [],
    family: "herb",
    soilImpact: "moderate-feeder",
    oxygenOutput: "medium",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Plant settles in" },
      { name: "Rooting", daysFromStart: 21, description: "Roots establish" },
      { name: "Flowering", daysFromStart: 60, description: "White flowers bloom" },
      { name: "Fruiting", daysFromStart: 90, description: "Red berries ripen" },
    ],
    supplies: [
      { name: "Strawberry plant", quantity: 3, unit: "pcs", category: "seeds", pricePerUnit: 8.00 },
      { name: "Berry mix soil", quantity: 5, unit: "liters", category: "soil", pricePerUnit: 1.50 },
      { name: "Hanging basket", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 12.00 },
    ],
  },
  {
    type: "herb",
    name: "Coriander",
    daysToHarvest: 25,
    waterPerWeek: 8,
    sunRequirement: "partial",
    companions: ["Cherry Tomato", "Basil"],
    incompatible: [],
    family: "herb",
    soilImpact: "light-feeder",
    oxygenOutput: "low",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout in 7-10 days" },
      { name: "Seedling", daysFromStart: 10, description: "Delicate leaves appear" },
      { name: "Growing", daysFromStart: 18, description: "Full foliage" },
      { name: "Harvest", daysFromStart: 25, description: "Fresh coriander ready" },
    ],
    supplies: [
      { name: "Coriander seeds", quantity: 20, unit: "pcs", category: "seeds", pricePerUnit: 0.10 },
      { name: "Potting mix", quantity: 3, unit: "liters", category: "soil", pricePerUnit: 0.80 },
      { name: "Small pot", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 4.00 },
    ],
  },
  {
    type: "vegetable",
    name: "Spring Onion",
    daysToHarvest: 35,
    waterPerWeek: 8,
    sunRequirement: "full",
    companions: ["Lettuce", "Radish"],
    incompatible: [],
    family: "herb",
    soilImpact: "light-feeder",
    oxygenOutput: "low",
    growthStages: [
      { name: "Planting", daysFromStart: 0, description: "Seeds or sets planted" },
      { name: "Rooting", daysFromStart: 10, description: "Roots establish" },
      { name: "Growing", daysFromStart: 20, description: "Green tops grow tall" },
      { name: "Harvest", daysFromStart: 35, description: "Cut green tops to harvest" },
    ],
    supplies: [
      { name: "Spring Onion seeds", quantity: 15, unit: "pcs", category: "seeds", pricePerUnit: 0.15 },
      { name: "Potting mix", quantity: 3, unit: "liters", category: "soil", pricePerUnit: 0.80 },
      { name: "Narrow planter", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 6.00 },
    ],
  },
  {
    type: "vegetable",
    name: "Radish",
    daysToHarvest: 28,
    waterPerWeek: 8,
    sunRequirement: "full",
    companions: ["Lettuce", "Spinach", "Spring Onion"],
    incompatible: [],
    family: "herb",
    soilImpact: "light-feeder",
    oxygenOutput: "low",
    growthStages: [
      { name: "Germination", daysFromStart: 0, description: "Seeds sprout in 3-5 days" },
      { name: "Seedling", daysFromStart: 7, description: "Leaves emerge" },
      { name: "Bulbing", daysFromStart: 18, description: "Root swells underground" },
      { name: "Harvest", daysFromStart: 28, description: "Pull radishes from soil" },
    ],
    supplies: [
      { name: "Radish seeds", quantity: 20, unit: "pcs", category: "seeds", pricePerUnit: 0.10 },
      { name: "Loose potting mix", quantity: 4, unit: "liters", category: "soil", pricePerUnit: 0.90 },
      { name: "Deep container", quantity: 1, unit: "pcs", category: "containers", pricePerUnit: 7.00 },
    ],
  },
];

export const getPlantInfo = (name: string): PlantInfo | undefined => {
  return plantData.find(p => p.name === name);
};

export const getGrowthProgress = (plantedAt: string, daysToHarvest: number): number => {
  const planted = new Date(plantedAt);
  const now = new Date();
  const daysPassed = Math.floor((now.getTime() - planted.getTime()) / (1000 * 60 * 60 * 24));
  return Math.min(100, Math.max(0, (daysPassed / daysToHarvest) * 100));
};

export const getCurrentStage = (plantedAt: string, growthStages: GrowthStage[]): GrowthStage => {
  const planted = new Date(plantedAt);
  const now = new Date();
  const daysPassed = Math.floor((now.getTime() - planted.getTime()) / (1000 * 60 * 60 * 24));
  
  let currentStage = growthStages[0];
  for (const stage of growthStages) {
    if (daysPassed >= stage.daysFromStart) {
      currentStage = stage;
    }
  }
  return currentStage;
};

export const getDaysUntilHarvest = (plantedAt: string, daysToHarvest: number): number => {
  const planted = new Date(plantedAt);
  const now = new Date();
  const daysPassed = Math.floor((now.getTime() - planted.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(0, daysToHarvest - daysPassed);
};

export const getHarvestDate = (plantedAt: string, daysToHarvest: number): Date => {
  const planted = new Date(plantedAt);
  return new Date(planted.getTime() + daysToHarvest * 24 * 60 * 60 * 1000);
};
