export interface CompanionInfo {
  name: string;
  companions: string[];
  incompatible: string[];
  benefits: string[];
  category: string;
}

export const companionPlantingData: CompanionInfo[] = [
  // Vegetables
  {
    name: 'Tomato Seeds',
    category: 'Vegetable Seeds',
    companions: ['Basil Seeds', 'Carrot Seeds', 'Marigold Seeds', 'Spinach Seeds'],
    incompatible: ['Brinjal Seeds', 'Cucumber Seeds'],
    benefits: ['Basil repels pests and improves flavor', 'Carrots loosen soil', 'Marigolds deter nematodes']
  },
  {
    name: 'Chili Pepper Seeds',
    category: 'Vegetable Seeds',
    companions: ['Basil Seeds', 'Tomato Seeds', 'Carrot Seeds', 'Oregano Seeds'],
    incompatible: ['Brinjal Seeds'],
    benefits: ['Basil repels aphids', 'Tomatoes provide shade', 'Oregano deters pests']
  },
  {
    name: 'Spinach Seeds',
    category: 'Vegetable Seeds',
    companions: ['Strawberry Seeds', 'Tomato Seeds', 'Carrot Seeds', 'Coriander Seeds'],
    incompatible: [],
    benefits: ['Grows well in partial shade of taller plants', 'Strawberries are natural companions']
  },
  {
    name: 'Cucumber Seeds',
    category: 'Vegetable Seeds',
    companions: ['Sunflower Seeds', 'Marigold Seeds', 'Coriander Seeds', 'Mint Seeds'],
    incompatible: ['Tomato Seeds'],
    benefits: ['Sunflowers attract pollinators', 'Marigolds repel beetles', 'Mint deters pests']
  },
  {
    name: 'Brinjal Seeds',
    category: 'Vegetable Seeds',
    companions: ['Spinach Seeds', 'Marigold Seeds', 'Oregano Seeds'],
    incompatible: ['Tomato Seeds', 'Chili Pepper Seeds'],
    benefits: ['Spinach acts as ground cover', 'Marigolds deter pests', 'Oregano provides pest control']
  },
  {
    name: 'Carrot Seeds',
    category: 'Vegetable Seeds',
    companions: ['Tomato Seeds', 'Rosemary Seeds', 'Coriander Seeds', 'Chili Pepper Seeds'],
    incompatible: [],
    benefits: ['Tomatoes provide shade and deter carrot fly', 'Rosemary repels pests', 'Coriander attracts beneficial insects']
  },
  {
    name: 'Okra Seeds',
    category: 'Vegetable Seeds',
    companions: ['Sunflower Seeds', 'Cucumber Seeds', 'Basil Seeds', 'Mint Seeds'],
    incompatible: [],
    benefits: ['Sunflowers attract pollinators', 'Basil improves growth', 'Mint deters pests']
  },
  // Herbs
  {
    name: 'Coriander Seeds',
    category: 'Herb Seeds',
    companions: ['Spinach Seeds', 'Tomato Seeds', 'Carrot Seeds', 'Cucumber Seeds'],
    incompatible: [],
    benefits: ['Attracts beneficial insects', 'Repels aphids', 'Improves germination of neighbors']
  },
  {
    name: 'Mint Seeds',
    category: 'Herb Seeds',
    companions: ['Tomato Seeds', 'Cucumber Seeds', 'Okra Seeds'],
    incompatible: ['Lavender Seeds', 'Rosemary Seeds'],
    benefits: ['Repels aphids and ants', 'Attracts pollinators', 'Improves plant vigor']
  },
  {
    name: 'Basil Seeds',
    category: 'Herb Seeds',
    companions: ['Tomato Seeds', 'Chili Pepper Seeds', 'Oregano Seeds', 'Marigold Seeds'],
    incompatible: [],
    benefits: ['Improves tomato flavor', 'Repels flies and mosquitoes', 'Attracts pollinators']
  },
  {
    name: 'Oregano Seeds',
    category: 'Herb Seeds',
    companions: ['Chili Pepper Seeds', 'Brinjal Seeds', 'Basil Seeds', 'Rosemary Seeds'],
    incompatible: [],
    benefits: ['General pest deterrent', 'Improves flavor of nearby vegetables', 'Attracts beneficial insects']
  },
  {
    name: 'Rosemary Seeds',
    category: 'Herb Seeds',
    companions: ['Carrot Seeds', 'Lavender Seeds', 'Oregano Seeds'],
    incompatible: ['Mint Seeds'],
    benefits: ['Repels carrot fly', 'Deters cabbage moths', 'Improves overall garden health']
  },
  // Flowers
  {
    name: 'Sunflower Seeds',
    category: 'Flower Seeds',
    companions: ['Cucumber Seeds', 'Okra Seeds', 'Zinnia Seeds', 'Marigold Seeds'],
    incompatible: [],
    benefits: ['Attracts pollinators', 'Provides shade for heat-sensitive plants', 'Attracts beneficial insects']
  },
  {
    name: 'Marigold Seeds',
    category: 'Flower Seeds',
    companions: ['Tomato Seeds', 'Cucumber Seeds', 'Brinjal Seeds', 'Basil Seeds', 'Sunflower Seeds'],
    incompatible: [],
    benefits: ['Repels nematodes', 'Deters many pests', 'Attracts beneficial insects']
  },
  {
    name: 'Lavender Seeds',
    category: 'Flower Seeds',
    companions: ['Rosemary Seeds', 'Rose Seeds', 'Oregano Seeds'],
    incompatible: ['Mint Seeds'],
    benefits: ['Repels moths and fleas', 'Attracts pollinators', 'Deters deer and rabbits']
  },
  {
    name: 'Rose Seeds',
    category: 'Flower Seeds',
    companions: ['Lavender Seeds', 'Marigold Seeds', 'Oregano Seeds'],
    incompatible: [],
    benefits: ['Lavender repels aphids', 'Marigolds deter pests', 'Oregano improves health']
  },
  {
    name: 'Zinnia Seeds',
    category: 'Flower Seeds',
    companions: ['Sunflower Seeds', 'Cucumber Seeds', 'Tomato Seeds'],
    incompatible: [],
    benefits: ['Attracts butterflies and pollinators', 'Provides color diversity', 'Supports beneficial insects']
  },
  // Fruits
  {
    name: 'Strawberry Seeds',
    category: 'Fruit Seeds',
    companions: ['Spinach Seeds', 'Carrot Seeds', 'Marigold Seeds'],
    incompatible: [],
    benefits: ['Spinach provides ground cover', 'Marigolds deter pests', 'Carrots loosen soil']
  },
  {
    name: 'Watermelon Seeds',
    category: 'Fruit Seeds',
    companions: ['Sunflower Seeds', 'Marigold Seeds', 'Oregano Seeds'],
    incompatible: [],
    benefits: ['Sunflowers attract pollinators', 'Marigolds deter pests', 'Oregano provides pest control']
  },
  {
    name: 'Lemon Seeds',
    category: 'Fruit Seeds',
    companions: ['Lavender Seeds', 'Marigold Seeds', 'Basil Seeds'],
    incompatible: [],
    benefits: ['Lavender deters pests', 'Marigolds protect roots', 'Basil improves growth']
  }
];

export const getCompanionInfo = (seedName: string): CompanionInfo | undefined => {
  return companionPlantingData.find(c => c.name === seedName);
};

export const getCompanionsForSeed = (seedName: string): string[] => {
  const info = getCompanionInfo(seedName);
  return info?.companions || [];
};

export const getIncompatibleForSeed = (seedName: string): string[] => {
  const info = getCompanionInfo(seedName);
  return info?.incompatible || [];
};
