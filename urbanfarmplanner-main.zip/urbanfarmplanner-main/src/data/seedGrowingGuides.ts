export interface GrowingGuide {
  seedName: string;
  category: 'Vegetable Seeds' | 'Flower Seeds' | 'Herb Seeds' | 'Fruit Seeds';
  germinationDays: string;
  soilType: string;
  sunlight: string;
  wateringFrequency: string;
  optimalTemperature: string;
  plantingDepth: string;
  spacing: string;
  harvestTime: string;
  tips: string[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export const seedGrowingGuides: Record<string, GrowingGuide> = {
  'Tomato Seeds': {
    seedName: 'Tomato Seeds',
    category: 'Vegetable Seeds',
    germinationDays: '5-10 days',
    soilType: 'Well-drained, loamy soil rich in organic matter',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Deep watering 2-3 times per week',
    optimalTemperature: '21-27°C (70-80°F)',
    plantingDepth: '0.5-1 cm deep',
    spacing: '45-60 cm apart',
    harvestTime: '60-85 days after transplanting',
    tips: [
      'Start seeds indoors 6-8 weeks before last frost',
      'Harden off seedlings before transplanting',
      'Use stakes or cages for support',
      'Mulch around plants to retain moisture',
      'Remove suckers for larger fruits'
    ],
    difficulty: 'Medium'
  },
  'Chili Pepper Seeds': {
    seedName: 'Chili Pepper Seeds',
    category: 'Vegetable Seeds',
    germinationDays: '7-14 days',
    soilType: 'Sandy loam with good drainage',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Regular watering, keep soil moist',
    optimalTemperature: '24-32°C (75-90°F)',
    plantingDepth: '0.5 cm deep',
    spacing: '30-45 cm apart',
    harvestTime: '60-90 days after transplanting',
    tips: [
      'Use heat mats for faster germination',
      'Peppers love warm conditions',
      'Pinch early flowers for bushier plants',
      'Harvest regularly to encourage more fruiting',
      'Wear gloves when handling hot varieties'
    ],
    difficulty: 'Medium'
  },
  'Spinach Seeds': {
    seedName: 'Spinach Seeds',
    category: 'Vegetable Seeds',
    germinationDays: '5-9 days',
    soilType: 'Rich, well-drained soil with neutral pH',
    sunlight: 'Partial to full sun (4-6 hours)',
    wateringFrequency: 'Keep soil consistently moist',
    optimalTemperature: '10-20°C (50-68°F)',
    plantingDepth: '1-2 cm deep',
    spacing: '10-15 cm apart',
    harvestTime: '35-45 days',
    tips: [
      'Best grown in cooler weather',
      'Sow seeds every 2 weeks for continuous harvest',
      'Harvest outer leaves first',
      'Bolts quickly in hot weather',
      'Add nitrogen-rich fertilizer for leafy growth'
    ],
    difficulty: 'Easy'
  },
  'Coriander Seeds': {
    seedName: 'Coriander Seeds',
    category: 'Herb Seeds',
    germinationDays: '7-10 days',
    soilType: 'Light, well-drained soil',
    sunlight: 'Partial shade to full sun',
    wateringFrequency: 'Moderate, avoid overwatering',
    optimalTemperature: '17-27°C (62-80°F)',
    plantingDepth: '0.5-1 cm deep',
    spacing: '15-20 cm apart',
    harvestTime: '21-30 days for leaves, 90 days for seeds',
    tips: [
      'Sow directly as it dislikes transplanting',
      'Crush seeds before sowing for better germination',
      'Harvest leaves before flowering',
      'Let some plants flower for seeds',
      'Succession plant every 2-3 weeks'
    ],
    difficulty: 'Easy'
  },
  'Sunflower Seeds': {
    seedName: 'Sunflower Seeds',
    category: 'Flower Seeds',
    germinationDays: '7-10 days',
    soilType: 'Any well-drained soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Deep watering once a week',
    optimalTemperature: '21-26°C (70-78°F)',
    plantingDepth: '2-3 cm deep',
    spacing: '30-45 cm apart',
    harvestTime: '70-100 days for flowers',
    tips: [
      'Plant directly outdoors after frost',
      'Stake tall varieties to prevent toppling',
      'Attracts pollinators to your garden',
      'Cut flowers when petals start to open',
      'Leave heads for birds in fall'
    ],
    difficulty: 'Easy'
  },
  'Marigold Seeds': {
    seedName: 'Marigold Seeds',
    category: 'Flower Seeds',
    germinationDays: '5-7 days',
    soilType: 'Any well-drained soil',
    sunlight: 'Full sun (6+ hours)',
    wateringFrequency: 'Regular watering, allow soil to dry between',
    optimalTemperature: '18-24°C (65-75°F)',
    plantingDepth: '0.5 cm deep',
    spacing: '20-30 cm apart',
    harvestTime: '45-50 days to bloom',
    tips: [
      'Remove spent blooms for continuous flowering',
      'Natural pest repellent for gardens',
      'Great companion plant for vegetables',
      'Very heat and drought tolerant',
      'Start indoors 6-8 weeks before last frost'
    ],
    difficulty: 'Easy'
  },
  'Cucumber Seeds': {
    seedName: 'Cucumber Seeds',
    category: 'Vegetable Seeds',
    germinationDays: '3-10 days',
    soilType: 'Rich, well-drained soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Consistent watering, 1-2 inches per week',
    optimalTemperature: '21-30°C (70-86°F)',
    plantingDepth: '1-2 cm deep',
    spacing: '30-60 cm apart',
    harvestTime: '50-70 days',
    tips: [
      'Use trellises for vertical growing',
      'Keep soil consistently moist',
      'Harvest when young for best flavor',
      'Avoid overhead watering to prevent disease',
      'Plant after soil warms to at least 21°C'
    ],
    difficulty: 'Easy'
  },
  'Brinjal Seeds': {
    seedName: 'Brinjal Seeds',
    category: 'Vegetable Seeds',
    germinationDays: '7-14 days',
    soilType: 'Rich, well-drained loamy soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Deep watering twice a week',
    optimalTemperature: '24-32°C (75-90°F)',
    plantingDepth: '0.5 cm deep',
    spacing: '45-60 cm apart',
    harvestTime: '65-80 days after transplanting',
    tips: [
      'Start seeds indoors 8-10 weeks before transplanting',
      'Needs warm soil and air temperatures',
      'Stake plants for support',
      'Harvest when skin is glossy',
      'Mulch to retain soil moisture'
    ],
    difficulty: 'Medium'
  },
  'Mint Seeds': {
    seedName: 'Mint Seeds',
    category: 'Herb Seeds',
    germinationDays: '10-15 days',
    soilType: 'Moist, rich soil',
    sunlight: 'Partial shade to full sun',
    wateringFrequency: 'Keep soil consistently moist',
    optimalTemperature: '18-21°C (65-70°F)',
    plantingDepth: 'Surface sow, press lightly',
    spacing: '30-45 cm apart',
    harvestTime: '60-90 days',
    tips: [
      'Grow in containers to prevent spreading',
      'Very invasive - control spread',
      'Pinch tips for bushier growth',
      'Harvest before flowering for best flavor',
      'Can grow in partial shade'
    ],
    difficulty: 'Easy'
  },
  'Basil Seeds': {
    seedName: 'Basil Seeds',
    category: 'Herb Seeds',
    germinationDays: '5-10 days',
    soilType: 'Rich, moist, well-drained soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Regular watering, keep soil moist',
    optimalTemperature: '21-27°C (70-80°F)',
    plantingDepth: '0.5 cm deep',
    spacing: '15-30 cm apart',
    harvestTime: '60-90 days',
    tips: [
      'Pinch off flowers to extend harvest',
      'Harvest from top to encourage bushy growth',
      'Very frost sensitive',
      'Great companion for tomatoes',
      'Harvest in the morning for best flavor'
    ],
    difficulty: 'Easy'
  },
  'Rose Seeds': {
    seedName: 'Rose Seeds',
    category: 'Flower Seeds',
    germinationDays: '14-42 days',
    soilType: 'Rich, well-drained soil with good organic matter',
    sunlight: 'Full sun (6+ hours)',
    wateringFrequency: 'Deep watering 2-3 times per week',
    optimalTemperature: '15-24°C (60-75°F)',
    plantingDepth: '0.5 cm deep',
    spacing: '60-90 cm apart',
    harvestTime: '1-2 years to bloom',
    tips: [
      'Cold stratify seeds for 4-6 weeks before planting',
      'Be patient - roses from seed take time',
      'Prune regularly for better blooms',
      'Mulch around base to retain moisture',
      'Watch for aphids and treat promptly'
    ],
    difficulty: 'Hard'
  },
  'Lavender Seeds': {
    seedName: 'Lavender Seeds',
    category: 'Flower Seeds',
    germinationDays: '14-28 days',
    soilType: 'Well-drained, slightly alkaline soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Light watering, drought tolerant once established',
    optimalTemperature: '18-21°C (65-70°F)',
    plantingDepth: 'Surface sow, press lightly',
    spacing: '30-45 cm apart',
    harvestTime: '90-200 days to bloom',
    tips: [
      'Cold stratify seeds for 3-4 weeks',
      'Do not overwater - prefers dry conditions',
      'Prune after flowering to maintain shape',
      'Harvest when flowers just open',
      'Excellent for dried arrangements'
    ],
    difficulty: 'Medium'
  },
  'Strawberry Seeds': {
    seedName: 'Strawberry Seeds',
    category: 'Fruit Seeds',
    germinationDays: '14-28 days',
    soilType: 'Rich, well-drained acidic soil (pH 5.5-6.8)',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Regular watering, keep soil moist',
    optimalTemperature: '15-24°C (60-75°F)',
    plantingDepth: 'Surface sow, press lightly',
    spacing: '30-45 cm apart',
    harvestTime: '4-6 months from transplanting',
    tips: [
      'Cold stratify seeds for 3-4 weeks',
      'Start indoors under grow lights',
      'Remove runners for larger fruits',
      'Mulch with straw to protect fruits',
      'Best fruit production in year 2-3'
    ],
    difficulty: 'Hard'
  },
  'Watermelon Seeds': {
    seedName: 'Watermelon Seeds',
    category: 'Fruit Seeds',
    germinationDays: '4-10 days',
    soilType: 'Sandy loam, well-drained',
    sunlight: 'Full sun (8+ hours)',
    wateringFrequency: 'Deep watering, reduce when fruits develop',
    optimalTemperature: '24-32°C (75-90°F)',
    plantingDepth: '2-3 cm deep',
    spacing: '90-180 cm apart',
    harvestTime: '70-90 days',
    tips: [
      'Plant in mounds for better drainage',
      'Needs lots of space to spread',
      'Thump test - sounds hollow when ripe',
      'Reduce watering as fruits ripen',
      'Use black plastic mulch to warm soil'
    ],
    difficulty: 'Medium'
  },
  'Lemon Seeds': {
    seedName: 'Lemon Seeds',
    category: 'Fruit Seeds',
    germinationDays: '14-28 days',
    soilType: 'Well-drained, slightly acidic soil',
    sunlight: 'Full sun (8+ hours)',
    wateringFrequency: 'Regular watering, allow top soil to dry',
    optimalTemperature: '21-29°C (70-85°F)',
    plantingDepth: '1-2 cm deep',
    spacing: '3-4 meters apart when mature',
    harvestTime: '3-5 years to fruit',
    tips: [
      'Plant fresh seeds immediately after extraction',
      'Keep soil consistently warm',
      'Grows well in containers',
      'Protect from frost',
      'Patience required - trees take years to fruit'
    ],
    difficulty: 'Hard'
  },
  'Zinnia Seeds': {
    seedName: 'Zinnia Seeds',
    category: 'Flower Seeds',
    germinationDays: '5-7 days',
    soilType: 'Well-drained, fertile soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Moderate, at base of plant',
    optimalTemperature: '21-27°C (70-80°F)',
    plantingDepth: '0.5 cm deep',
    spacing: '10-30 cm apart',
    harvestTime: '60-70 days to bloom',
    tips: [
      'Direct sow after last frost',
      'Deadhead regularly for more blooms',
      'Avoid overhead watering',
      'Great cut flowers',
      'Attracts butterflies'
    ],
    difficulty: 'Easy'
  },
  'Oregano Seeds': {
    seedName: 'Oregano Seeds',
    category: 'Herb Seeds',
    germinationDays: '7-14 days',
    soilType: 'Well-drained, slightly alkaline soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Light watering, drought tolerant',
    optimalTemperature: '18-24°C (65-75°F)',
    plantingDepth: 'Surface sow, press lightly',
    spacing: '20-30 cm apart',
    harvestTime: '60-90 days',
    tips: [
      'Surface sow - needs light to germinate',
      'Pinch flowers to extend harvest',
      'More flavorful in poor soil',
      'Cut back after flowering',
      'Perennial in mild climates'
    ],
    difficulty: 'Easy'
  },
  'Rosemary Seeds': {
    seedName: 'Rosemary Seeds',
    category: 'Herb Seeds',
    germinationDays: '14-21 days',
    soilType: 'Sandy, well-drained alkaline soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Light watering, very drought tolerant',
    optimalTemperature: '18-24°C (65-75°F)',
    plantingDepth: 'Surface sow, press lightly',
    spacing: '45-60 cm apart',
    harvestTime: '90-180 days',
    tips: [
      'Very slow to germinate - be patient',
      'Better to start from cuttings',
      'Do not overwater',
      'Prune regularly to prevent woodiness',
      'Excellent in containers'
    ],
    difficulty: 'Medium'
  },
  'Carrot Seeds': {
    seedName: 'Carrot Seeds',
    category: 'Vegetable Seeds',
    germinationDays: '14-21 days',
    soilType: 'Sandy, loose, stone-free soil',
    sunlight: 'Full sun to partial shade',
    wateringFrequency: 'Consistent moisture, light watering',
    optimalTemperature: '15-21°C (60-70°F)',
    plantingDepth: '0.5 cm deep',
    spacing: '5-8 cm apart after thinning',
    harvestTime: '70-80 days',
    tips: [
      'Sow directly - do not transplant',
      'Keep soil moist until germination',
      'Mix seeds with sand for even sowing',
      'Thin seedlings when 5 cm tall',
      'Harvest when tops are 2 cm diameter'
    ],
    difficulty: 'Medium'
  },
  'Okra Seeds': {
    seedName: 'Okra Seeds',
    category: 'Vegetable Seeds',
    germinationDays: '7-14 days',
    soilType: 'Rich, well-drained loamy soil',
    sunlight: 'Full sun (6-8 hours)',
    wateringFrequency: 'Deep watering once a week',
    optimalTemperature: '24-35°C (75-95°F)',
    plantingDepth: '2-3 cm deep',
    spacing: '30-45 cm apart',
    harvestTime: '50-65 days',
    tips: [
      'Soak seeds overnight before planting',
      'Loves hot weather',
      'Harvest pods when 7-10 cm long',
      'Pick every 2 days for continuous harvest',
      'Wear gloves - plants can irritate skin'
    ],
    difficulty: 'Easy'
  }
};

export const seedCategories = [
  { value: 'All Seeds', label: 'All Seeds' },
  { value: 'Vegetable Seeds', label: 'Vegetable Seeds' },
  { value: 'Flower Seeds', label: 'Flower Seeds' },
  { value: 'Herb Seeds', label: 'Herb Seeds' },
  { value: 'Fruit Seeds', label: 'Fruit Seeds' },
];

export const getGuideByName = (seedName: string): GrowingGuide | undefined => {
  return seedGrowingGuides[seedName];
};

export const getGuidesByCategory = (category: string): GrowingGuide[] => {
  return Object.values(seedGrowingGuides).filter(guide => guide.category === category);
};
