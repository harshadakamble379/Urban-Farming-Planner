import { useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { isPast } from "date-fns";

interface Reminder {
  id: string;
  plant_name: string;
  reminder_type: string;
  next_due_at: string;
}

export function useNotifications() {
  const notifiedReminders = useRef<Set<string>>(new Set());
  const permissionGranted = useRef(false);

  const requestPermission = useCallback(async () => {
    if (!("Notification" in window)) {
      console.log("This browser does not support notifications");
      return false;
    }

    if (Notification.permission === "granted") {
      permissionGranted.current = true;
      return true;
    }

    if (Notification.permission !== "denied") {
      const permission = await Notification.requestPermission();
      permissionGranted.current = permission === "granted";
      return permission === "granted";
    }

    return false;
  }, []);

  const sendNotification = useCallback((title: string, body: string, icon?: string) => {
    if (!permissionGranted.current && Notification.permission !== "granted") {
      return;
    }

    const notification = new Notification(title, {
      body,
      icon: icon || "/favicon.ico",
      badge: "/favicon.ico",
      tag: `plant-care-${Date.now()}`,
      requireInteraction: true,
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };

    // Auto-close after 10 seconds
    setTimeout(() => notification.close(), 10000);
  }, []);

  const checkOverdueReminders = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: reminders } = await supabase
      .from("plant_reminders")
      .select("*")
      .eq("user_id", user.id)
      .eq("is_active", true);

    if (!reminders) return;

    const overdueReminders = reminders.filter(
      (r: Reminder) => isPast(new Date(r.next_due_at)) && !notifiedReminders.current.has(r.id)
    );

    if (overdueReminders.length > 0) {
      // Send a summary notification for multiple overdue items
      if (overdueReminders.length === 1) {
        const reminder = overdueReminders[0];
        sendNotification(
          `🌱 ${reminder.plant_name} needs ${reminder.reminder_type}!`,
          `Your ${reminder.plant_name} is overdue for ${reminder.reminder_type}. Take care of it soon!`
        );
      } else {
        sendNotification(
          `🌱 ${overdueReminders.length} plants need attention!`,
          `You have ${overdueReminders.length} overdue care tasks. Check your dashboard.`
        );
      }

      // Mark these as notified
      overdueReminders.forEach((r: Reminder) => notifiedReminders.current.add(r.id));
    }
  }, [sendNotification]);

  useEffect(() => {
    // Request permission on mount
    requestPermission();

    // Check for overdue reminders immediately
    checkOverdueReminders();

    // Check every 5 minutes
    const interval = setInterval(checkOverdueReminders, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [requestPermission, checkOverdueReminders]);

  return {
    requestPermission,
    sendNotification,
    checkOverdueReminders,
    isSupported: "Notification" in window,
    permission: typeof Notification !== "undefined" ? Notification.permission : "denied",
  };
}
