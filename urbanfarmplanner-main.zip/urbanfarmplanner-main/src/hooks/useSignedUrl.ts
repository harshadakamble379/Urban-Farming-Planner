import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

/**
 * Hook to generate signed URLs for private storage buckets
 * Returns a signed URL that expires after the specified duration
 */
export function useSignedUrl(
  bucket: string,
  path: string | null | undefined,
  expiresIn: number = 3600 // 1 hour default
) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!path) {
      setSignedUrl(null);
      return;
    }

    // Extract just the file path from a full URL if needed
    const filePath = extractFilePath(bucket, path);
    if (!filePath) {
      setSignedUrl(null);
      return;
    }

    const fetchSignedUrl = async () => {
      setLoading(true);
      setError(null);

      try {
        const { data, error: signError } = await supabase.storage
          .from(bucket)
          .createSignedUrl(filePath, expiresIn);

        if (signError) throw signError;
        setSignedUrl(data?.signedUrl || null);
      } catch (err) {
        console.error('Error creating signed URL:', err);
        setError(err instanceof Error ? err : new Error('Failed to create signed URL'));
        setSignedUrl(null);
      } finally {
        setLoading(false);
      }
    };

    fetchSignedUrl();
  }, [bucket, path, expiresIn]);

  return { signedUrl, loading, error };
}

/**
 * Utility function to generate a signed URL imperatively
 */
export async function getSignedUrl(
  bucket: string,
  path: string,
  expiresIn: number = 3600
): Promise<string | null> {
  const filePath = extractFilePath(bucket, path);
  if (!filePath) return null;

  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(filePath, expiresIn);

    if (error) throw error;
    return data?.signedUrl || null;
  } catch (err) {
    console.error('Error creating signed URL:', err);
    return null;
  }
}

/**
 * Extract the file path from a full storage URL or return the path as-is
 */
function extractFilePath(bucket: string, path: string): string | null {
  if (!path) return null;

  // If it's already just a path (e.g., "userId/avatar.png"), return as-is
  if (!path.startsWith('http')) {
    return path;
  }

  // Extract path from full Supabase storage URL
  // Format: https://xxx.supabase.co/storage/v1/object/public/bucket-name/path
  try {
    const url = new URL(path);
    const pathParts = url.pathname.split('/');
    
    // Find the bucket name in the path and get everything after it
    const bucketIndex = pathParts.findIndex(part => part === bucket);
    if (bucketIndex !== -1) {
      return pathParts.slice(bucketIndex + 1).join('/');
    }

    // Try alternate format: /storage/v1/object/public/bucket/path
    const storageIndex = pathParts.indexOf('storage');
    if (storageIndex !== -1 && pathParts.length > storageIndex + 4) {
      // Skip: storage, v1, object, public/sign, bucket
      const possibleBucketIndex = storageIndex + 4;
      if (pathParts[possibleBucketIndex] === bucket) {
        return pathParts.slice(possibleBucketIndex + 1).join('/');
      }
    }

    return null;
  } catch {
    return null;
  }
}
