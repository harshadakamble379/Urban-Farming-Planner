import { useState, useEffect } from "react";
import { Separator } from "@/components/ui/separator";
import { MainLayout } from "@/components/layout/MainLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { PageSkeleton } from "@/components/ui/page-skeleton";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Search, 
  Package,
  SlidersHorizontal,
  Grid3X3,
  List,
  Loader2
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { ProductCard } from "@/components/inventory/ProductCard";
import { ShoppingCart } from "@/components/inventory/ShoppingCart";
import { Wishlist } from "@/components/inventory/Wishlist";
import { OrderTracking } from "@/components/inventory/OrderTracking";
import { GardenPlanner } from "@/components/inventory/GardenPlanner";
import { ShoperSection } from "@/components/inventory/ShoperSection";

interface InventoryItem {
  id: string;
  name: string;
  description: string | null;
  category: string;
  price: number;
  quantity: number;
  min_stock: number;
  unit: string | null;
  image_url: string | null;
  condition: string | null;
  is_available: boolean;
  reviews?: Review[];
  averageRating?: number;
}

interface CartItem {
  id: string;
  item_id: string;
  name: string;
  price: number;
  quantity: number;
  image_url: string | null;
  max_quantity: number;
}

interface WishlistItem {
  id: string;
  item_id: string;
  name: string;
  price: number;
  image_url: string | null;
  quantity: number;
  category: string;
}

interface Review {
  id: string;
  rating: number;
  title: string | null;
  comment: string | null;
  created_at: string;
  user_id: string;
}

interface Order {
  id: string;
  status: string;
  total_amount: number;
  created_at: string;
  tracking_number?: string | null;
  carrier?: string | null;
  estimated_delivery?: string | null;
  shipping_address?: string | null;
}

const categories = ["All", "Balcony Friendly", "Tools", "Materials", "Equipment", "Seeds", "Indoor Plants"];
const seedSubcategories = ["All Seeds", "Vegetable Seeds", "Flower Seeds", "Herb Seeds", "Fruit Seeds"];

const BALCONY_FRIENDLY_NAMES = [
  "cherry tomato", "basil", "green chili", "mint", "lettuce",
  "spinach", "strawberry", "coriander", "spring onion", "radish",
  "lavender", "aloe vera", "snake plant", "money plant", "spider plant"
];
const sortOptions = [
  { value: "newest", label: "Newest First" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "name", label: "Name A-Z" },
  { value: "rating", label: "Highest Rated" },
];

export default function Inventory() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<Record<string, Review[]>>({});
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedSeedCategory, setSelectedSeedCategory] = useState("All Seeds");
  const [sortBy, setSortBy] = useState("newest");
  const [priceRange, setPriceRange] = useState([0, 50000]);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    loadData();

    // Real-time subscription for inventory item changes (public availability data)
    const inventoryChannel = supabase
      .channel('inventory-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'inventory_items' },
        () => { loadItems(); }
      )
      .subscribe();

    // Refresh own orders when window regains focus (orders are no longer
    // broadcast over Realtime to prevent leaking other users' shipping data).
    const onFocus = () => { loadOrders(); };
    window.addEventListener('focus', onFocus);

    return () => {
      supabase.removeChannel(inventoryChannel);
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  const loadData = async () => {
    setLoading(true);
    await Promise.all([loadItems(), loadCart(), loadWishlist(), loadOrders(), loadReviews()]);
    setLoading(false);
  };

  const loadOrders = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error loading orders:", error);
      return;
    }

    setOrders(data || []);
  };

  const loadReviews = async () => {
    const { data, error } = await supabase
      .from("reviews")
      .select("id, item_id, rating, title, comment, created_at")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error loading reviews:", error);
      return;
    }

    // Group reviews by item_id
    const reviewsByItem: Record<string, Review[]> = {};
    (data || []).forEach((review: any) => {
      if (!reviewsByItem[review.item_id]) {
        reviewsByItem[review.item_id] = [];
      }
      reviewsByItem[review.item_id].push(review);
    });

    setReviews(reviewsByItem);
  };

  const loadItems = async () => {
    // Use public_inventory_items view which excludes user_id to protect seller identity
    const { data, error } = await supabase
      .from("public_inventory_items")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error loading items:", error);
      return;
    }

    setItems(data || []);
  };

  const loadCart = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("shopping_cart")
      .select(`
        id,
        item_id,
        quantity,
        inventory_items (
          id,
          name,
          price,
          image_url,
          quantity
        )
      `)
      .eq("user_id", user.id);

    if (error) {
      console.error("Error loading cart:", error);
      return;
    }

    const cartData = (data || []).map((item: any) => ({
      id: item.id,
      item_id: item.item_id,
      name: item.inventory_items?.name || "Unknown",
      price: item.inventory_items?.price || 0,
      quantity: item.quantity,
      image_url: item.inventory_items?.image_url,
      max_quantity: item.inventory_items?.quantity || 0,
    }));

    setCartItems(cartData);
  };

  const loadWishlist = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("wishlist")
      .select(`
        id,
        item_id,
        inventory_items (
          id,
          name,
          price,
          image_url,
          quantity,
          category
        )
      `)
      .eq("user_id", user.id);

    if (error) {
      console.error("Error loading wishlist:", error);
      return;
    }

    const wishlistData = (data || []).map((item: any) => ({
      id: item.id,
      item_id: item.item_id,
      name: item.inventory_items?.name || "Unknown",
      price: item.inventory_items?.price || 0,
      image_url: item.inventory_items?.image_url,
      quantity: item.inventory_items?.quantity || 0,
      category: item.inventory_items?.category || "Other",
    }));

    setWishlistItems(wishlistData);
  };

  const handleAddToCart = async (itemId: string, qty: number) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please login to add items to cart");
      return;
    }

    const existingItem = cartItems.find((c) => c.item_id === itemId);

    if (existingItem) {
      const { error } = await supabase
        .from("shopping_cart")
        .update({ quantity: existingItem.quantity + qty })
        .eq("id", existingItem.id);

      if (error) {
        toast.error("Failed to update cart");
        return;
      }
    } else {
      const { error } = await supabase
        .from("shopping_cart")
        .insert({
          user_id: user.id,
          item_id: itemId,
          quantity: qty,
        });

      if (error) {
        toast.error("Failed to add to cart");
        return;
      }
    }

    await loadCart();
  };

  const handleToggleWishlist = async (itemId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please login to add items to wishlist");
      return;
    }

    const existingItem = wishlistItems.find((w) => w.item_id === itemId);

    if (existingItem) {
      const { error } = await supabase
        .from("wishlist")
        .delete()
        .eq("id", existingItem.id);

      if (error) {
        toast.error("Failed to remove from wishlist");
        return;
      }
      toast.success("Removed from wishlist");
    } else {
      const { error } = await supabase
        .from("wishlist")
        .insert({
          user_id: user.id,
          item_id: itemId,
        });

      if (error) {
        toast.error("Failed to add to wishlist");
        return;
      }
      toast.success("Added to wishlist");
    }

    await loadWishlist();
  };

  const handleRemoveFromWishlist = async (wishlistItemId: string) => {
    const { error } = await supabase
      .from("wishlist")
      .delete()
      .eq("id", wishlistItemId);

    if (error) {
      toast.error("Failed to remove from wishlist");
      return;
    }

    toast.success("Removed from wishlist");
    await loadWishlist();
  };

  const handleUpdateCartQuantity = async (cartItemId: string, quantity: number) => {
    const { error } = await supabase
      .from("shopping_cart")
      .update({ quantity })
      .eq("id", cartItemId);

    if (error) {
      toast.error("Failed to update quantity");
      return;
    }

    await loadCart();
  };

  const handleRemoveFromCart = async (cartItemId: string) => {
    const { error } = await supabase
      .from("shopping_cart")
      .delete()
      .eq("id", cartItemId);

    if (error) {
      toast.error("Failed to remove item");
      return;
    }

    toast.success("Item removed from cart");
    await loadCart();
  };

  const handleCheckout = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please login to checkout");
      return;
    }

    const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

    // Create order
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: user.id,
        status: "pending",
        total_amount: total,
      })
      .select()
      .single();

    if (orderError) {
      toast.error("Failed to create order");
      return;
    }

    // Create order items
    const orderItems = cartItems.map((item) => ({
      order_id: order.id,
      item_id: item.item_id,
      quantity: item.quantity,
      price_at_purchase: item.price,
    }));

    const { error: itemsError } = await supabase
      .from("order_items")
      .insert(orderItems);

    if (itemsError) {
      toast.error("Failed to save order items");
      return;
    }

    // Clear cart
    const { error: clearError } = await supabase
      .from("shopping_cart")
      .delete()
      .eq("user_id", user.id);

    if (clearError) {
      console.error("Failed to clear cart:", clearError);
    }

    toast.success("Order placed successfully!");
    await loadData();
  };

  // Calculate average rating for each item
  const getAverageRating = (itemId: string) => {
    const itemReviews = reviews[itemId] || [];
    if (itemReviews.length === 0) return 0;
    return itemReviews.reduce((sum, r) => sum + r.rating, 0) / itemReviews.length;
  };

  // Check if item is a seed type
  const isSeedCategory = (category: string) => {
    return category === 'Seeds' || category.toLowerCase().includes('seed');
  };

  // Filter and sort items
  const filteredItems = items
    .filter((item) => {
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Category filtering logic
      let matchesCategory = false;
      if (selectedCategory === "All") {
        matchesCategory = true;
      } else if (selectedCategory === "Balcony Friendly") {
        matchesCategory = BALCONY_FRIENDLY_NAMES.some(name => 
          item.name.toLowerCase().includes(name)
        );
      } else if (selectedCategory === "Seeds") {
        if (selectedSeedCategory === "All Seeds") {
          matchesCategory = isSeedCategory(item.category);
        } else {
          matchesCategory = item.category === selectedSeedCategory;
        }
      } else {
        matchesCategory = item.category === selectedCategory;
      }
      
      const matchesPrice = item.price >= priceRange[0] && item.price <= priceRange[1];
      return matchesSearch && matchesCategory && matchesPrice;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price-asc":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "name":
          return a.name.localeCompare(b.name);
        case "rating":
          return getAverageRating(b.id) - getAverageRating(a.id);
        default:
          return 0;
      }
    });

  const totalItems = items.length;
  const wishlistedItemIds = new Set(wishlistItems.map((w) => w.item_id));

  if (loading) {
    return (
      <MainLayout>
        <PageSkeleton variant="grid" />
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Shop</h1>
            <p className="mt-1 text-muted-foreground">
              Browse and purchase farming supplies
            </p>
          </div>
          <div className="flex gap-2">
            <GardenPlanner seeds={items} />
            <OrderTracking orders={orders} onRefresh={loadOrders} />
            <Wishlist
              items={wishlistItems}
              onRemoveItem={handleRemoveFromWishlist}
              onAddToCart={(itemId) => handleAddToCart(itemId, 1)}
            />
            <ShoppingCart
              items={cartItems}
              onUpdateQuantity={handleUpdateCartQuantity}
              onRemoveItem={handleRemoveFromCart}
              onCheckout={handleCheckout}
            />
          </div>
        </div>

        {/* Search and Filter Bar */}
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  setSelectedCategory(category);
                  if (category !== "Seeds") {
                    setSelectedSeedCategory("All Seeds");
                  }
                }}
              >
                {category}
              </Button>
            ))}
          </div>
          
          {/* Seed Subcategories */}
          {selectedCategory === "Seeds" && (
            <div className="flex flex-wrap gap-2">
              {seedSubcategories.map((subcat) => (
                <Button
                  key={subcat}
                  variant={selectedSeedCategory === subcat ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setSelectedSeedCategory(subcat)}
                  className="text-xs"
                >
                  {subcat}
                </Button>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowFilters(!showFilters)}
            >
              <SlidersHorizontal className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
            >
              {viewMode === "grid" ? (
                <List className="h-4 w-4" />
              ) : (
                <Grid3X3 className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Price Filter */}
        {showFilters && (
          <div className="rounded-xl bg-card p-4 shadow-card">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">
                  Price Range: ₹{priceRange[0]} - ₹{priceRange[1]}
                </label>
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  min={0}
                  max={50000}
                  step={100}
                  className="mt-2"
                />
              </div>
            </div>
          </div>
        )}

        {/* Results Count */}
        <p className="text-sm text-muted-foreground">
          Showing {filteredItems.length} of {totalItems} products
        </p>

        {/* Product Grid */}
        {filteredItems.length === 0 ? (
          <div className="rounded-xl bg-card p-12 text-center shadow-card">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-semibold text-lg">No products found</h3>
            <p className="text-muted-foreground mt-1">
              Try adjusting your search or filters
            </p>
          </div>
        ) : (
          <div
            className={
              viewMode === "grid"
                ? "grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                : "space-y-4"
            }
          >
            {filteredItems.map((item) => (
              <ProductCard
                key={item.id}
                id={item.id}
                name={item.name}
                description={item.description}
                category={item.category}
                price={item.price}
                quantity={item.quantity}
                unit={item.unit}
                image_url={item.image_url}
                condition={item.condition}
                is_available={item.is_available}
                isWishlisted={wishlistedItemIds.has(item.id)}
                reviews={reviews[item.id] || []}
                averageRating={getAverageRating(item.id)}
                onAddToCart={handleAddToCart}
                onToggleWishlist={handleToggleWishlist}
                onReviewAdded={loadReviews}
              />
            ))}
          </div>
        )}

        {/* Shoper Admin Section */}
        <Separator className="my-8" />
        <ShoperSection />
      </div>
    </MainLayout>
  );
}
