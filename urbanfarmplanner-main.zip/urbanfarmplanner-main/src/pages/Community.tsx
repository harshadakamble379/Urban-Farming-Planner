import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  MessageSquare, Plus, Heart, MessageCircle, Search, 
  ArrowLeft, Send, Loader2, Leaf, Bug, Droplets, Sun, Sprout
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ForumPost {
  id: string;
  user_id: string;
  title: string;
  content: string;
  category: string;
  likes_count: number;
  replies_count: number;
  created_at: string;
}

interface ForumReply {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  likes_count: number;
  created_at: string;
}

interface UserProfile {
  user_id: string;
  name: string | null;
  avatar_url: string | null;
}

const forumCategories = [
  { value: "general", label: "General", icon: MessageSquare },
  { value: "tips", label: "Tips & Tricks", icon: Leaf },
  { value: "pest-control", label: "Pest Control", icon: Bug },
  { value: "watering", label: "Watering", icon: Droplets },
  { value: "sunlight", label: "Sunlight & Growth", icon: Sun },
  { value: "beginners", label: "Beginners", icon: Sprout },
];

const categoryColorMap: Record<string, string> = {
  general: "bg-muted text-muted-foreground",
  tips: "bg-primary/15 text-primary",
  "pest-control": "bg-destructive/15 text-destructive",
  watering: "bg-blue-500/15 text-blue-700 dark:text-blue-400",
  sunlight: "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400",
  beginners: "bg-green-500/15 text-green-700 dark:text-green-400",
};

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function getInitials(name: string | null, userId: string): string {
  if (name && name.trim()) {
    return name.trim().split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  }
  return userId.slice(0, 2).toUpperCase();
}

function getDisplayName(profiles: Map<string, UserProfile>, userId: string): string {
  const profile = profiles.get(userId);
  return profile?.name || 'Anonymous Gardener';
}

function getAvatarUrl(profiles: Map<string, UserProfile>, userId: string): string | null {
  const profile = profiles.get(userId);
  return profile?.avatar_url || null;
}

export default function Community() {
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [selectedPost, setSelectedPost] = useState<ForumPost | null>(null);
  const [replies, setReplies] = useState<ForumReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [showNewPost, setShowNewPost] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [newCategory, setNewCategory] = useState("general");
  const [replyContent, setReplyContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [userProfiles, setUserProfiles] = useState<Map<string, UserProfile>>(new Map());

  useEffect(() => {
    loadPosts();
    loadCurrentUser();
  }, []);

  const loadUserProfiles = async (userIds: string[]) => {
    const uniqueIds = [...new Set(userIds)];
    const missingIds = uniqueIds.filter(id => !userProfiles.has(id));
    if (missingIds.length === 0) return;

    const { data } = await supabase
      .rpc("get_public_profiles", { _user_ids: missingIds });

    if (data) {
      const newProfiles = new Map(userProfiles);
      data.forEach(profile => {
        newProfiles.set(profile.user_id, profile);
      });
      // Set defaults for users without settings
      missingIds.forEach(id => {
        if (!newProfiles.has(id)) {
          newProfiles.set(id, { user_id: id, name: null, avatar_url: null });
        }
      });
      setUserProfiles(newProfiles);
    }
  };

  const loadCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      setCurrentUserId(user.id);
      const { data } = await supabase
        .from("forum_likes")
        .select("post_id")
        .eq("user_id", user.id);
      if (data) {
        setLikedPosts(new Set(data.map((l: any) => l.post_id).filter(Boolean)));
      }
    }
  };

  const loadPosts = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("forum_posts")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error loading posts:", error);
    } else {
      setPosts(data || []);
      if (data && data.length > 0) {
        await loadUserProfiles(data.map(p => p.user_id));
      }
    }
    setLoading(false);
  };

  const loadReplies = async (postId: string) => {
    const { data, error } = await supabase
      .from("forum_replies")
      .select("*")
      .eq("post_id", postId)
      .order("created_at", { ascending: true });

    if (error) {
      console.error("Error loading replies:", error);
    } else {
      setReplies(data || []);
      if (data && data.length > 0) {
        await loadUserProfiles(data.map(r => r.user_id));
      }
    }
  };

  const handleCreatePost = async () => {
    if (!newTitle.trim() || !newContent.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error("Please log in"); return; }

    setSubmitting(true);
    const { error } = await supabase.from("forum_posts").insert({
      user_id: user.id,
      title: newTitle.trim(),
      content: newContent.trim(),
      category: newCategory,
    });

    if (error) {
      toast.error("Failed to create post");
    } else {
      toast.success("Post created!");
      setNewTitle(""); setNewContent(""); setNewCategory("general");
      setShowNewPost(false);
      loadPosts();
    }
    setSubmitting(false);
  };

  const handleReply = async () => {
    if (!replyContent.trim() || !selectedPost) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error("Please log in"); return; }

    setSubmitting(true);
    const { error } = await supabase.from("forum_replies").insert({
      post_id: selectedPost.id,
      user_id: user.id,
      content: replyContent.trim(),
    });

    if (!error) {
      await supabase.from("forum_posts").update({ 
        replies_count: selectedPost.replies_count + 1 
      }).eq("id", selectedPost.id);
      
      setSelectedPost({ ...selectedPost, replies_count: selectedPost.replies_count + 1 });
      setReplyContent("");
      loadReplies(selectedPost.id);
      toast.success("Reply posted!");
    }
    setSubmitting(false);
  };

  const handleLikePost = async (postId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error("Please log in"); return; }

    const isLiked = likedPosts.has(postId);
    if (isLiked) {
      await supabase.from("forum_likes").delete().eq("user_id", user.id).eq("post_id", postId);
      const newLiked = new Set(likedPosts);
      newLiked.delete(postId);
      setLikedPosts(newLiked);
      setPosts(posts.map(p => p.id === postId ? { ...p, likes_count: p.likes_count - 1 } : p));
      await supabase.from("forum_posts").update({ likes_count: posts.find(p => p.id === postId)!.likes_count - 1 }).eq("id", postId);
    } else {
      await supabase.from("forum_likes").insert({ user_id: user.id, post_id: postId });
      const newLiked = new Set(likedPosts);
      newLiked.add(postId);
      setLikedPosts(newLiked);
      setPosts(posts.map(p => p.id === postId ? { ...p, likes_count: p.likes_count + 1 } : p));
      await supabase.from("forum_posts").update({ likes_count: posts.find(p => p.id === postId)!.likes_count + 1 }).eq("id", postId);
    }
  };

  const openPost = (post: ForumPost) => {
    setSelectedPost(post);
    loadReplies(post.id);
  };

  const filteredPosts = posts.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === "all" || p.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  if (selectedPost) {
    const postAvatarUrl = getAvatarUrl(userProfiles, selectedPost.user_id);
    const postDisplayName = getDisplayName(userProfiles, selectedPost.user_id);
    
    return (
      <MainLayout>
        <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
          <Button variant="ghost" className="gap-2" onClick={() => { setSelectedPost(null); setReplies([]); }}>
            <ArrowLeft className="h-4 w-4" /> Back to Forum
          </Button>

          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      {postAvatarUrl && <AvatarImage src={postAvatarUrl} alt={postDisplayName} />}
                      <AvatarFallback className="bg-primary/15 text-primary text-sm">
                        {getInitials(userProfiles.get(selectedPost.user_id)?.name || null, selectedPost.user_id)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-foreground">{postDisplayName}</p>
                      <p className="text-xs text-muted-foreground">{timeAgo(selectedPost.created_at)}</p>
                    </div>
                  </div>
                  <Badge className={categoryColorMap[selectedPost.category] || categoryColorMap.general}>
                    {forumCategories.find(c => c.value === selectedPost.category)?.label || selectedPost.category}
                  </Badge>
                  <CardTitle className="text-2xl">{selectedPost.title}</CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="whitespace-pre-wrap text-foreground/90 leading-relaxed">{selectedPost.content}</p>
              <div className="flex items-center gap-4 mt-6 pt-4 border-t">
                <Button 
                  variant="ghost" size="sm" className="gap-2"
                  onClick={() => handleLikePost(selectedPost.id)}
                >
                  <Heart className={`h-4 w-4 ${likedPosts.has(selectedPost.id) ? "fill-red-500 text-red-500" : ""}`} />
                  {selectedPost.likes_count}
                </Button>
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <MessageCircle className="h-4 w-4" /> {replies.length} replies
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Replies */}
          <div className="space-y-3">
            {replies.map(reply => {
              const replyAvatarUrl = getAvatarUrl(userProfiles, reply.user_id);
              const replyDisplayName = getDisplayName(userProfiles, reply.user_id);
              return (
                <Card key={reply.id} className="bg-muted/30">
                  <CardContent className="pt-4">
                    <div className="flex items-start gap-3">
                      <Avatar className="h-8 w-8">
                        {replyAvatarUrl && <AvatarImage src={replyAvatarUrl} alt={replyDisplayName} />}
                        <AvatarFallback className="text-xs bg-primary/20 text-primary">
                          {getInitials(userProfiles.get(reply.user_id)?.name || null, reply.user_id)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="text-sm font-medium text-foreground">{replyDisplayName}</p>
                          <p className="text-xs text-muted-foreground">{timeAgo(reply.created_at)}</p>
                        </div>
                        <p className="text-sm whitespace-pre-wrap">{reply.content}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Reply Input */}
          <Card>
            <CardContent className="pt-4">
              <div className="flex gap-3">
                <Textarea
                  placeholder="Write a reply..."
                  value={replyContent}
                  onChange={e => setReplyContent(e.target.value)}
                  className="min-h-[80px]"
                />
                <Button onClick={handleReply} disabled={submitting || !replyContent.trim()} className="self-end gap-2">
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  Reply
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Community Forum</h1>
            <p className="mt-1 text-muted-foreground">Share tips, ask questions, and connect with fellow gardeners</p>
          </div>
          <Dialog open={showNewPost} onOpenChange={setShowNewPost}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="h-4 w-4" /> New Post</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Create a New Post</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input placeholder="Post title" value={newTitle} onChange={e => setNewTitle(e.target.value)} />
                <Select value={newCategory} onValueChange={setNewCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {forumCategories.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Textarea placeholder="Share your thoughts..." value={newContent} onChange={e => setNewContent(e.target.value)} className="min-h-[120px]" />
                <Button onClick={handleCreatePost} disabled={submitting} className="w-full gap-2">
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                  Create Post
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search posts..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-9" />
          </div>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-full sm:w-48"><SelectValue placeholder="All Categories" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {forumCategories.map(c => (
                <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Posts List */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filteredPosts.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-semibold text-lg">No posts yet</h3>
              <p className="text-muted-foreground text-sm mt-1">Be the first to start a discussion!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredPosts.map(post => {
              const avatarUrl = getAvatarUrl(userProfiles, post.user_id);
              const displayName = getDisplayName(userProfiles, post.user_id);
              return (
                <Card key={post.id} className="cursor-pointer hover:bg-muted/30 transition-colors" onClick={() => openPost(post)}>
                  <CardContent className="py-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-10 w-10 mt-1">
                        {avatarUrl && <AvatarImage src={avatarUrl} alt={displayName} />}
                        <AvatarFallback className="bg-primary/15 text-primary text-sm">
                          {getInitials(userProfiles.get(post.user_id)?.name || null, post.user_id)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="text-sm font-medium text-foreground">{displayName}</span>
                          <Badge className={`text-xs ${categoryColorMap[post.category] || categoryColorMap.general}`}>
                            {forumCategories.find(c => c.value === post.category)?.label || post.category}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{timeAgo(post.created_at)}</span>
                        </div>
                        <h3 className="font-semibold text-foreground truncate">{post.title}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{post.content}</p>
                        <div className="flex items-center gap-4 mt-3">
                          <button
                            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-red-500 transition-colors"
                            onClick={e => { e.stopPropagation(); handleLikePost(post.id); }}
                          >
                            <Heart className={`h-4 w-4 ${likedPosts.has(post.id) ? "fill-red-500 text-red-500" : ""}`} />
                            {post.likes_count}
                          </button>
                          <span className="flex items-center gap-1 text-sm text-muted-foreground">
                            <MessageCircle className="h-4 w-4" /> {post.replies_count}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
