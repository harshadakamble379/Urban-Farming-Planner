import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Leaf, 
  Grid3X3, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowLeft,
  Printer,
  Calendar
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { companionPlantingData } from "@/data/companionPlanting";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface PlantedSeed {
  id: string;
  name: string;
  row: number;
  col: number;
}

interface SharedLayout {
  id: string;
  name: string;
  planted_seeds: PlantedSeed[];
  grid_size: number;
  created_at: string;
}

const GRID_SIZE = 6;

const getPlantColor = (name: string): string => {
  const colors: Record<string, string> = {
    tomato: "bg-red-500",
    chili: "bg-orange-600",
    spinach: "bg-green-600",
    coriander: "bg-emerald-500",
    sunflower: "bg-yellow-500",
    marigold: "bg-amber-500",
    cucumber: "bg-green-400",
    brinjal: "bg-purple-600",
    mint: "bg-teal-500",
    basil: "bg-green-700",
    rose: "bg-pink-500",
    lavender: "bg-violet-400",
    zinnia: "bg-rose-500",
    strawberry: "bg-red-400",
    watermelon: "bg-green-500",
    lemon: "bg-yellow-400",
    oregano: "bg-lime-600",
    rosemary: "bg-cyan-600",
    carrot: "bg-orange-500",
    okra: "bg-green-600",
  };

  const lowerName = name.toLowerCase();
  for (const [key, value] of Object.entries(colors)) {
    if (lowerName.includes(key)) return value;
  }
  return "bg-primary";
};

const getPlantNameKey = (name: string): string => {
  return name.toLowerCase().replace(/ seeds?/gi, "").trim();
};

export default function SharedGarden() {
  const { token } = useParams<{ token: string }>();
  const [layout, setLayout] = useState<SharedLayout | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLayout = async () => {
      if (!token) {
        setError("Invalid share link");
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("garden_layouts")
        .select("id, name, planted_seeds, grid_size, created_at")
        .eq("share_token", token)
        .eq("is_public", true)
        .single();

      if (error || !data) {
        setError("This garden layout is not available or has been made private");
        setLoading(false);
        return;
      }

      setLayout({
        ...data,
        planted_seeds: (data.planted_seeds as unknown) as PlantedSeed[],
      });
      setLoading(false);
    };

    fetchLayout();
  }, [token]);

  const companionAnalysis = layout ? (() => {
    const plantedSeeds = layout.planted_seeds;
    const goodPairs: Array<{ plant1: string; plant2: string }> = [];
    const badPairs: Array<{ plant1: string; plant2: string }> = [];

    for (let i = 0; i < plantedSeeds.length; i++) {
      for (let j = i + 1; j < plantedSeeds.length; j++) {
        const plant1 = plantedSeeds[i];
        const plant2 = plantedSeeds[j];
        const distance = Math.abs(plant1.row - plant2.row) + Math.abs(plant1.col - plant2.col);

        if (distance <= 2) {
          const key1 = getPlantNameKey(plant1.name);
          const key2 = getPlantNameKey(plant2.name);

          const companion1 = companionPlantingData.find(
            (c) => c.name.toLowerCase().replace(/ seeds?/gi, "").trim() === key1
          );

          if (companion1) {
            if (companion1.companions.some((c) => c.toLowerCase().replace(/ seeds?/gi, "").trim() === key2)) {
              goodPairs.push({ plant1: plant1.name, plant2: plant2.name });
            }
            if (companion1.incompatible.some((c) => c.toLowerCase().replace(/ seeds?/gi, "").trim() === key2)) {
              badPairs.push({ plant1: plant1.name, plant2: plant2.name });
            }
          }
        }
      }
    }

    const score = plantedSeeds.length > 0
      ? Math.max(0, Math.min(100, 50 + goodPairs.length * 15 - badPairs.length * 20))
      : 0;

    return { goodPairs, badPairs, score };
  })() : { goodPairs: [], badPairs: [], score: 0 };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Leaf className="h-12 w-12 text-primary animate-pulse mx-auto mb-4" />
          <p className="text-muted-foreground">Loading garden layout...</p>
        </div>
      </div>
    );
  }

  if (error || !layout) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Garden Not Found</h2>
            <p className="text-muted-foreground mb-4">{error}</p>
            <Link to="/">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Go to Homepage
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getPlantAtCell = (row: number, col: number) => {
    return layout.planted_seeds.find((p) => p.row === row && p.col === col);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 print:hidden">
          <Link to="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          </Link>
          <Button variant="outline" size="sm" onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
        </div>

        {/* Garden Info */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Leaf className="h-5 w-5 text-primary" />
              {layout.name}
            </CardTitle>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              Created: {new Date(layout.created_at).toLocaleDateString()}
              <Badge variant="outline" className="ml-2">
                {layout.planted_seeds.length} plants
              </Badge>
            </div>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Garden Grid */}
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Grid3X3 className="h-4 w-4" />
                Garden Layout ({GRID_SIZE}x{GRID_SIZE})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div
                className="grid gap-1 bg-muted/30 p-2 rounded-lg"
                style={{
                  gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
                }}
              >
                {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, index) => {
                  const row = Math.floor(index / GRID_SIZE);
                  const col = index % GRID_SIZE;
                  const plant = getPlantAtCell(row, col);

                  return (
                    <div
                      key={`${row}-${col}`}
                      className={`
                        aspect-square border-2 border-dashed rounded-md flex items-center justify-center
                        ${plant ? "border-solid border-primary/50 bg-primary/10" : "border-muted-foreground/30"}
                      `}
                    >
                      {plant && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div
                                className={`
                                  w-8 h-8 rounded-full flex items-center justify-center shadow-sm
                                  ${getPlantColor(plant.name)}
                                `}
                              >
                                <Leaf className="h-4 w-4 text-white" />
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{plant.name.replace(" Seeds", "")}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="mt-4 flex flex-wrap gap-2">
                {[...new Set(layout.planted_seeds.map(p => p.name))].map(name => (
                  <div key={name} className="flex items-center gap-1 text-xs">
                    <div className={`w-3 h-3 rounded-full ${getPlantColor(name)}`} />
                    <span>{name.replace(" Seeds", "")}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Companion Analysis */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Companion Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Compatibility Score</span>
                <Badge
                  variant={
                    companionAnalysis.score >= 70
                      ? "default"
                      : companionAnalysis.score >= 40
                      ? "secondary"
                      : "destructive"
                  }
                  className={
                    companionAnalysis.score >= 70
                      ? "bg-green-600"
                      : companionAnalysis.score >= 40
                      ? "bg-amber-500"
                      : ""
                  }
                >
                  {companionAnalysis.score}%
                </Badge>
              </div>

              {companionAnalysis.goodPairs.length > 0 && (
                <div className="p-2 bg-green-500/10 rounded-md">
                  <div className="flex items-center gap-2 text-green-600 text-sm font-medium mb-1">
                    <CheckCircle2 className="h-4 w-4" />
                    Good Companions
                  </div>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    {companionAnalysis.goodPairs.map((pair, i) => (
                      <li key={i}>
                        {pair.plant1.replace(" Seeds", "")} +{" "}
                        {pair.plant2.replace(" Seeds", "")}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {companionAnalysis.badPairs.length > 0 && (
                <div className="p-2 bg-destructive/10 rounded-md">
                  <div className="flex items-center gap-2 text-destructive text-sm font-medium mb-1">
                    <AlertTriangle className="h-4 w-4" />
                    Incompatible
                  </div>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    {companionAnalysis.badPairs.map((pair, i) => (
                      <li key={i}>
                        {pair.plant1.replace(" Seeds", "")} ↔{" "}
                        {pair.plant2.replace(" Seeds", "")}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {companionAnalysis.goodPairs.length === 0 && companionAnalysis.badPairs.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No companion planting interactions detected
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-muted-foreground print:hidden">
          <p>Want to create your own garden layout?</p>
          <Link to="/inventory">
            <Button variant="link" className="text-primary">
              Start planning your garden →
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}