import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Move, 
  Grid3X3, 
  Settings2,
  Ruler
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PlantPalette } from "@/components/planning/PlantPalette";
import { PlanningCanvas, MapMode } from "@/components/planning/PlanningCanvas";
import { ProjectManager } from "@/components/planning/ProjectManager";
import { GrowthTracker } from "@/components/planning/GrowthTracker";
import { HarvestTimeline } from "@/components/planning/HarvestTimeline";
import { ShoppingList } from "@/components/planning/ShoppingList";
import { WeatherForecast } from "@/components/planning/WeatherForecast";
import { CompanionGuide } from "@/components/planning/CompanionGuide";
import { CropRotation } from "@/components/planning/CropRotation";
import { CostEstimation } from "@/components/planning/CostEstimation";
import { SunlightAnalysis } from "@/components/planning/SunlightAnalysis";
import { YieldPrediction } from "@/components/planning/YieldPrediction";
import { PestRiskAlerts } from "@/components/planning/PestRiskAlerts";
import { plantData } from "@/data/plantData";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface PlotConfig {
  width: number;
  height: number;
  unit: "meters" | "feet" | "yards";
  cellSize: number;
}

interface Project {
  id: string;
  name: string;
  plot_config: PlotConfig;
  grid_items: PlantItem[];
  created_at: string;
  updated_at: string;
}

const plantOptions = plantData.map(p => ({ type: p.type, name: p.name }));

const unitLabels = {
  meters: "m",
  feet: "ft",
  yards: "yd",
};

const getPlantColor = (type: string) => {
  switch (type) {
    case "vegetable": return "terracotta";
    case "herb": return "forest";
    case "leafy": return "forest-light";
    case "fruit": return "accent";
    default: return "forest";
  }
};

export default function Planning() {
  const [selectedTool, setSelectedTool] = useState("Pan");
  const [showGrid, setShowGrid] = useState(true);
  const [mapMode, setMapMode] = useState<MapMode>("building");
  const [timeOfDay, setTimeOfDay] = useState(12);
  const [selectedPlant, setSelectedPlant] = useState<typeof plantOptions[0] | null>(null);
  const [gridItems, setGridItems] = useState<PlantItem[]>([]);
  const [plotConfig, setPlotConfig] = useState<PlotConfig>({
    width: 10,
    height: 8,
    unit: "meters",
    cellSize: 40,
  });
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [tempConfig, setTempConfig] = useState<PlotConfig>(plotConfig);
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Define plantable zones based on map mode
  const isInPlantableZone = (x: number, y: number) => {
    if (mapMode === "building") {
      if (x >= 1 && x <= plotConfig.width - 2 && y >= 0 && y <= 1) return true;
      if (x === 0 && y >= 2 && y <= plotConfig.height - 2) return true;
      if (x === plotConfig.width - 1 && y >= 2 && y <= plotConfig.height - 2) return true;
      if (x >= 1 && x <= plotConfig.width - 2 && y === plotConfig.height - 1) return true;
      return false;
    } else if (mapMode === "balcony") {
      return x >= 1 && x <= plotConfig.width - 2 && y >= 1 && y <= plotConfig.height - 2;
    } else {
      const centerStart = Math.floor(plotConfig.width / 2) - 1;
      const centerEnd = Math.floor(plotConfig.width / 2) + 1;
      return x >= centerStart && x <= centerEnd;
    }
  };

  // Load projects
  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    const { data, error } = await supabase
      .from("projects")
      .select("*")
      .order("updated_at", { ascending: false });

    if (error) {
      toast.error("Failed to load projects");
      return;
    }

    setProjects((data || []) as unknown as Project[]);
  };

  const handleSaveProject = async (name: string) => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      toast.error("You must be logged in to save projects");
      setLoading(false);
      return;
    }

    const projectData = {
      user_id: user.id,
      name,
      plot_config: plotConfig as any,
      grid_items: gridItems as any,
    };

    if (currentProjectId) {
      // Update existing project
      const { error } = await supabase
        .from("projects")
        .update(projectData)
        .eq("id", currentProjectId);

      if (error) {
        toast.error("Failed to update project");
      } else {
        toast.success("Project updated!");
        loadProjects();
      }
    } else {
      // Create new project
      const { data, error } = await supabase
        .from("projects")
        .insert(projectData)
        .select()
        .single();

      if (error) {
        toast.error("Failed to save project");
      } else {
        setCurrentProjectId(data.id);
        toast.success("Project saved!");
        loadProjects();
      }
    }

    setLoading(false);
  };

  const handleLoadProject = async (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    if (!project) return;

    setPlotConfig(project.plot_config);
    setGridItems(project.grid_items);
    setCurrentProjectId(projectId);
    toast.success(`Loaded: ${project.name}`);
  };

  const handleDeleteProject = async (projectId: string) => {
    const { error } = await supabase
      .from("projects")
      .delete()
      .eq("id", projectId);

    if (error) {
      toast.error("Failed to delete project");
    } else {
      if (currentProjectId === projectId) {
        setCurrentProjectId(null);
        setGridItems([]);
      }
      toast.success("Project deleted");
      loadProjects();
    }
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!selectedPlant) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / plotConfig.cellSize);
    const y = Math.floor((e.clientY - rect.top) / plotConfig.cellSize);

    if (x < 0 || x >= plotConfig.width || y < 0 || y >= plotConfig.height) return;

    // Check if the cell is in a plantable zone
    if (!isInPlantableZone(x, y)) {
      toast.error("This area is not plantable! Use the designated green zones.");
      return;
    }

    const isOccupied = gridItems.some(item => item.x === x && item.y === y);
    if (isOccupied) {
      toast.error("This cell is already occupied!");
      return;
    }

    const newItem: PlantItem = {
      id: Date.now(),
      type: selectedPlant.type,
      name: selectedPlant.name,
      x,
      y,
      plantedAt: new Date().toISOString(),
    };

    setGridItems([...gridItems, newItem]);
    toast.success(`Added ${selectedPlant.name}`);
  };

  const handleMapModeChange = (mode: MapMode) => {
    setMapMode(mode);
    setGridItems(prev => prev.filter(item => {
      if (mode === "building") {
        if (item.x >= 1 && item.x <= plotConfig.width - 2 && item.y >= 0 && item.y <= 1) return true;
        if (item.x === 0 && item.y >= 2 && item.y <= plotConfig.height - 2) return true;
        if (item.x === plotConfig.width - 1 && item.y >= 2 && item.y <= plotConfig.height - 2) return true;
        if (item.x >= 1 && item.x <= plotConfig.width - 2 && item.y === plotConfig.height - 1) return true;
        return false;
      } else if (mode === "balcony") {
        return item.x >= 1 && item.x <= plotConfig.width - 2 && item.y >= 1 && item.y <= plotConfig.height - 2;
      } else {
        const centerStart = Math.floor(plotConfig.width / 2) - 1;
        const centerEnd = Math.floor(plotConfig.width / 2) + 1;
        return item.x >= centerStart && item.x <= centerEnd;
      }
    }));
    toast.success(`Switched to ${mode === "building" ? "Building Area" : mode === "balcony" ? "Balcony Garden" : "Street Divider"} mode`);
  };

  const handleRemovePlant = (id: number) => {
    setGridItems(gridItems.filter(item => item.id !== id));
    toast.success("Plant removed");
  };

  const handleDragPlant = (id: number, newX: number, newY: number) => {
    setGridItems(gridItems.map(item => 
      item.id === id ? { ...item, x: newX, y: newY } : item
    ));
    toast.success("Plant moved");
  };

  const applyPlotConfig = () => {
    setPlotConfig(tempConfig);
    setConfigDialogOpen(false);
    toast.success("Plot configuration updated");
  };

  const clearAllPlants = () => {
    setGridItems([]);
    toast.success("All plants cleared");
  };

  const handleNewProject = () => {
    setCurrentProjectId(null);
    setGridItems([]);
    setPlotConfig({
      width: 10,
      height: 8,
      unit: "meters",
      cellSize: 40,
    });
    toast.success("New project started");
  };

  const totalArea = plotConfig.width * plotConfig.height;
  const baseWaterEstimate = gridItems.reduce((sum, item) => {
    const plantInfo = plantData.find(p => p.name === item.name);
    return sum + (plantInfo?.waterPerWeek || 15);
  }, 0);
  const waterEstimate = baseWaterEstimate;

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex flex-col gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Farm Planning</h1>
            <p className="mt-1 text-muted-foreground">
              Design and layout your urban farming spaces
            </p>
          </div>
          {/* Action buttons - responsive grid */}
          <div className="grid grid-cols-4 gap-1.5 sm:flex sm:flex-wrap sm:gap-2">
            <ProjectManager
              projects={projects}
              currentProjectId={currentProjectId}
              onSave={handleSaveProject}
              onLoad={handleLoadProject}
              onDelete={handleDeleteProject}
              loading={loading}
            />
            <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-1.5 text-sm px-3" onClick={() => setTempConfig(plotConfig)}>
                  <Settings2 className="h-4 w-4 shrink-0" />
                  <span className="truncate">Settings</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Plot Configuration</DialogTitle>
                  <DialogDescription>
                    Set the dimensions and measurement unit for your farming plot.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="width">Width</Label>
                      <Input
                        id="width"
                        type="number"
                        min={1}
                        max={50}
                        value={tempConfig.width}
                        onChange={(e) => setTempConfig({ ...tempConfig, width: parseInt(e.target.value) || 1 })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="height">Height</Label>
                      <Input
                        id="height"
                        type="number"
                        min={1}
                        max={50}
                        value={tempConfig.height}
                        onChange={(e) => setTempConfig({ ...tempConfig, height: parseInt(e.target.value) || 1 })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Measurement Unit</Label>
                    <Select
                      value={tempConfig.unit}
                      onValueChange={(value: "meters" | "feet" | "yards") => 
                        setTempConfig({ ...tempConfig, unit: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="meters">Meters (m)</SelectItem>
                        <SelectItem value="feet">Feet (ft)</SelectItem>
                        <SelectItem value="yards">Yards (yd)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Grid Cell Size</Label>
                    <Select
                      value={tempConfig.cellSize.toString()}
                      onValueChange={(value) => 
                        setTempConfig({ ...tempConfig, cellSize: parseInt(value) })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">Small (30px)</SelectItem>
                        <SelectItem value="40">Medium (40px)</SelectItem>
                        <SelectItem value="50">Large (50px)</SelectItem>
                        <SelectItem value="60">Extra Large (60px)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="rounded-lg bg-muted p-3 text-sm">
                    <p className="font-medium">Plot Summary</p>
                    <p className="text-muted-foreground">
                      Total Area: {tempConfig.width * tempConfig.height} {unitLabels[tempConfig.unit]}²
                    </p>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setConfigDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={applyPlotConfig}>Apply Changes</Button>
                </div>
              </DialogContent>
            </Dialog>
            <Button className="gap-1.5 bg-primary hover:bg-primary/90 text-sm px-3" onClick={handleNewProject}>
              <Move className="h-4 w-4 shrink-0" />
              <span className="truncate">New</span>
            </Button>
          </div>
        </div>

        {/* Plant Palette - Always above canvas on all screens */}
        <PlantPalette
          plantOptions={plantOptions}
          selectedPlant={selectedPlant}
          onSelectPlant={(plant) => {
            setSelectedPlant(plant);
            setSelectedTool("Pan");
          }}
          gridItemsCount={gridItems.length}
          onClearAll={clearAllPlants}
          getPlantColor={getPlantColor}
        />

        {/* Planning Canvas */}
        <div className="grid gap-6 grid-cols-1 lg:grid-cols-4">
          {/* Toolbar - Horizontal on mobile/tablet, vertical on desktop */}
          <div className="space-y-4 lg:order-1 order-2">
            {/* Tools and Plant Palette - Horizontal scroll on mobile */}
            <div className="flex gap-4 overflow-x-auto pb-2 lg:flex-col lg:overflow-x-visible lg:pb-0">
              <div className="rounded-2xl bg-card p-4 shadow-card flex-shrink-0 min-w-[200px] lg:min-w-0">
                <h3 className="mb-3 text-sm font-semibold text-foreground">Tools</h3>
                <div className="flex gap-2 lg:flex-col lg:gap-1">
                  <button
                    onClick={() => {
                      setSelectedTool("Grid");
                      setShowGrid(!showGrid);
                      setSelectedPlant(null);
                    }}
                    className={`flex items-center gap-3 rounded-lg p-3 text-sm transition-all duration-200 ${
                      showGrid
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-secondary text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <Grid3X3 className="h-5 w-5" />
                    <span className="lg:inline">Grid</span>
                  </button>
                </div>
              </div>

              {/* Plot Info - Compact on mobile */}
              <div className="rounded-2xl bg-card p-4 shadow-card flex-shrink-0 min-w-[200px] lg:min-w-0">
                <div className="flex items-center gap-2 mb-3">
                  <Ruler className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-semibold text-foreground">Plot Info</h3>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm lg:grid-cols-1 lg:space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Dimensions</span>
                    <span className="font-medium">{plotConfig.width} × {plotConfig.height} {unitLabels[plotConfig.unit]}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Area</span>
                    <span className="font-medium">{totalArea} {unitLabels[plotConfig.unit]}²</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Plants</span>
                    <span className="font-medium">{gridItems.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Water/Week</span>
                    <span className="font-medium">{waterEstimate}L</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Plant Palette moved above the grid layout */}

            {/* Growth Tracker - Hidden on mobile, visible on tablet+ */}
            <div className="hidden md:block">
              <GrowthTracker 
                gridItems={gridItems} 
                getPlantColor={getPlantColor}
              />
            </div>

            {/* Companion Guide - Hidden on mobile, visible on tablet+ */}
            <div className="hidden md:block">
              <CompanionGuide 
                gridItems={gridItems}
                getPlantColor={getPlantColor}
              />
            </div>

            {/* Crop Rotation Guide - Hidden on mobile, visible on tablet+ */}
            <div className="hidden lg:block">
              <CropRotation 
                gridItems={gridItems}
                getPlantColor={getPlantColor}
              />
            </div>
          </div>

          {/* Canvas Area */}
          <div className="lg:col-span-3 space-y-6 order-1 lg:order-2">
            {/* Canvas with horizontal scroll on mobile */}
            <div className="overflow-x-auto -mx-4 px-4 sm:mx-0 sm:px-0">
              <PlanningCanvas
                plotConfig={plotConfig}
                gridItems={gridItems}
                selectedPlant={selectedPlant}
                showGrid={showGrid}
                mapMode={mapMode}
                timeOfDay={timeOfDay}
                onMapModeChange={handleMapModeChange}
                onCanvasClick={handleCanvasClick}
                onRemovePlant={handleRemovePlant}
                onDragPlant={handleDragPlant}
                onCancelPlacement={() => setSelectedPlant(null)}
                getPlantColor={getPlantColor}
                unitLabels={unitLabels}
              />
            </div>

            {/* Mobile-only sections */}
            <div className="md:hidden space-y-6">
              <GrowthTracker 
                gridItems={gridItems} 
                getPlantColor={getPlantColor}
              />
              <CompanionGuide 
                gridItems={gridItems}
                getPlantColor={getPlantColor}
              />
            </div>

            {/* Tablet-only Crop Rotation (already visible on desktop in sidebar) */}
            <div className="hidden md:block lg:hidden">
              <CropRotation 
                gridItems={gridItems}
                getPlantColor={getPlantColor}
              />
            </div>

            {/* Harvest Timeline */}
            <HarvestTimeline 
              gridItems={gridItems}
              getPlantColor={getPlantColor}
            />

            {/* Shopping List */}
            <ShoppingList gridItems={gridItems} />

            {/* Cost Estimation */}
            <CostEstimation gridItems={gridItems} />

            {/* Sunlight Analysis */}
            <SunlightAnalysis 
              gridItems={gridItems} 
              mapMode={mapMode} 
              timeOfDay={timeOfDay}
              onTimeChange={setTimeOfDay}
            />

            {/* Yield Prediction */}
            <YieldPrediction
              gridItems={gridItems}
              mapMode={mapMode}
              timeOfDay={timeOfDay}
              getPlantColor={getPlantColor}
            />

            {/* Pest & Disease Alerts */}
            <PestRiskAlerts
              gridItems={gridItems}
              getPlantColor={getPlantColor}
            />

            {/* Weather Forecast */}
            <WeatherForecast baseWaterPerWeek={baseWaterEstimate} />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}