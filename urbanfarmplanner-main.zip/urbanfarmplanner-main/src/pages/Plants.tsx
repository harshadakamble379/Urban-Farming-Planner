import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Sun, 
  Droplets, 
  Clock,
  ThermometerSun,
  Wind,
  Heart
} from "lucide-react";

const plants = [
  // Beautiful Flowering Plants
  {
    id: 1,
    name: "Peace Lily",
    scientific: "Spathiphyllum wallisii",
    category: "Flower",
    sunlight: "Low Light",
    water: "Moderate",
    growTime: "30-45 days",
    temperature: "18-24°C",
    oxygenOutput: "High",
    description: "Elegant white flowers with air-purifying qualities. Removes toxins like formaldehyde and benzene.",
    image: "🪻",
    airPurifying: true,
  },
  {
    id: 2,
    name: "Jasmine",
    scientific: "Jasminum officinale",
    category: "Flower",
    sunlight: "Full Sun",
    water: "Regular",
    growTime: "60-90 days",
    temperature: "15-25°C",
    oxygenOutput: "High",
    description: "Fragrant white flowers that bloom at night, releasing oxygen and calming scent for better sleep.",
    image: "🌸",
    airPurifying: true,
  },
  {
    id: 3,
    name: "Orchid",
    scientific: "Orchidaceae",
    category: "Flower",
    sunlight: "Indirect Light",
    water: "Low",
    growTime: "60-120 days",
    temperature: "18-27°C",
    oxygenOutput: "Medium",
    description: "Exotic blooms in various colors. Releases oxygen at night, perfect for bedrooms.",
    image: "🌺",
    airPurifying: true,
  },
  {
    id: 4,
    name: "Lavender",
    scientific: "Lavandula angustifolia",
    category: "Flower",
    sunlight: "Full Sun",
    water: "Low",
    growTime: "90-180 days",
    temperature: "15-21°C",
    oxygenOutput: "Medium",
    description: "Purple fragrant flowers with calming properties. Attracts pollinators and repels pests.",
    image: "💜",
    airPurifying: true,
  },
  {
    id: 5,
    name: "Gerbera Daisy",
    scientific: "Gerbera jamesonii",
    category: "Flower",
    sunlight: "Full Sun",
    water: "Moderate",
    growTime: "14-18 weeks",
    temperature: "18-24°C",
    oxygenOutput: "Very High",
    description: "Vibrant colorful blooms. NASA-approved air purifier that releases oxygen at night.",
    image: "🌼",
    airPurifying: true,
  },
  {
    id: 6,
    name: "Chrysanthemum",
    scientific: "Chrysanthemum morifolium",
    category: "Flower",
    sunlight: "Full Sun",
    water: "Regular",
    growTime: "10-12 weeks",
    temperature: "13-18°C",
    oxygenOutput: "High",
    description: "Colorful blooms that filter benzene, formaldehyde, and ammonia from the air.",
    image: "🏵️",
    airPurifying: true,
  },
  // High Oxygen-Producing Plants
  {
    id: 7,
    name: "Areca Palm",
    scientific: "Dypsis lutescens",
    category: "Oxygen Producer",
    sunlight: "Indirect Light",
    water: "Regular",
    growTime: "Slow grower",
    temperature: "18-24°C",
    oxygenOutput: "Very High",
    description: "Top oxygen producer! Releases ~1.8L of oxygen per day. Perfect natural humidifier.",
    image: "🌴",
    airPurifying: true,
  },
  {
    id: 8,
    name: "Snake Plant",
    scientific: "Sansevieria trifasciata",
    category: "Oxygen Producer",
    sunlight: "Any Light",
    water: "Low",
    growTime: "Slow grower",
    temperature: "15-27°C",
    oxygenOutput: "Very High",
    description: "Converts CO2 to oxygen at night. Nearly indestructible and removes toxic pollutants.",
    image: "🌿",
    airPurifying: true,
  },
  {
    id: 9,
    name: "Money Plant",
    scientific: "Epipremnum aureum",
    category: "Oxygen Producer",
    sunlight: "Indirect Light",
    water: "Moderate",
    growTime: "Fast grower",
    temperature: "15-30°C",
    oxygenOutput: "High",
    description: "Hardy vine that purifies air by removing formaldehyde, benzene, and xylene.",
    image: "💚",
    airPurifying: true,
  },
  {
    id: 10,
    name: "Aloe Vera",
    scientific: "Aloe barbadensis miller",
    category: "Oxygen Producer",
    sunlight: "Indirect Light",
    water: "Low",
    growTime: "Slow grower",
    temperature: "13-27°C",
    oxygenOutput: "High",
    description: "Releases oxygen at night. Medicinal gel for burns. Removes formaldehyde.",
    image: "🌵",
    airPurifying: true,
  },
  {
    id: 11,
    name: "Spider Plant",
    scientific: "Chlorophytum comosum",
    category: "Oxygen Producer",
    sunlight: "Indirect Light",
    water: "Moderate",
    growTime: "Fast grower",
    temperature: "13-24°C",
    oxygenOutput: "Very High",
    description: "NASA top air-purifying plant. Easy to grow with cascading baby plants.",
    image: "🌱",
    airPurifying: true,
  },
  {
    id: 12,
    name: "Boston Fern",
    scientific: "Nephrolepis exaltata",
    category: "Oxygen Producer",
    sunlight: "Indirect Light",
    water: "High",
    growTime: "Moderate",
    temperature: "16-24°C",
    oxygenOutput: "Very High",
    description: "Lush green fronds that excel at removing pollutants and adding humidity.",
    image: "🌿",
    airPurifying: true,
  },
  // Beautiful Ornamental Plants
  {
    id: 13,
    name: "Anthurium",
    scientific: "Anthurium andraeanum",
    category: "Flower",
    sunlight: "Indirect Light",
    water: "Regular",
    growTime: "Slow grower",
    temperature: "20-28°C",
    oxygenOutput: "Medium",
    description: "Heart-shaped red, pink, or white flowers. Long-lasting blooms for months.",
    image: "❤️",
    airPurifying: true,
  },
  {
    id: 14,
    name: "Bird of Paradise",
    scientific: "Strelitzia reginae",
    category: "Flower",
    sunlight: "Full Sun",
    water: "Moderate",
    growTime: "3-5 years to bloom",
    temperature: "18-24°C",
    oxygenOutput: "High",
    description: "Stunning orange and blue tropical flowers resembling exotic birds.",
    image: "🧡",
    airPurifying: false,
  },
  {
    id: 15,
    name: "Rubber Plant",
    scientific: "Ficus elastica",
    category: "Oxygen Producer",
    sunlight: "Indirect Light",
    water: "Moderate",
    growTime: "Moderate",
    temperature: "16-27°C",
    oxygenOutput: "Very High",
    description: "Large glossy leaves that powerfully remove toxins and produce abundant oxygen.",
    image: "🍃",
    airPurifying: true,
  },
  {
    id: 16,
    name: "Hibiscus",
    scientific: "Hibiscus rosa-sinensis",
    category: "Flower",
    sunlight: "Full Sun",
    water: "Regular",
    growTime: "60-90 days",
    temperature: "16-32°C",
    oxygenOutput: "Medium",
    description: "Large tropical blooms in red, pink, orange, yellow. Edible flowers for tea.",
    image: "🌺",
    airPurifying: false,
  },
];

const categories = ["All", "Flower", "Oxygen Producer"];

export default function Plants() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredPlants = plants.filter((plant) => {
    const matchesSearch = plant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      plant.scientific.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || plant.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getOxygenColor = (level: string) => {
    switch (level) {
      case "Very High": return "text-forest bg-forest/10";
      case "High": return "text-primary bg-primary/10";
      case "Medium": return "text-amber-500 bg-amber-500/10";
      default: return "text-muted-foreground bg-muted";
    }
  };

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Plant Library</h1>
            <p className="mt-1 text-muted-foreground">
              Beautiful flowers and high oxygen-producing plants for urban spaces
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground bg-forest/10 rounded-lg px-3 py-2">
            <Wind className="h-4 w-4 text-forest" />
            <span>All plants improve air quality</span>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search plants..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={selectedCategory === category ? "bg-primary" : ""}
              >
                {category === "Oxygen Producer" && <Wind className="h-3 w-3 mr-1" />}
                {category === "Flower" && <Heart className="h-3 w-3 mr-1" />}
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Plant Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredPlants.map((plant, index) => (
            <div
              key={plant.id}
              className="group cursor-pointer rounded-2xl bg-card p-5 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Plant Header */}
              <div className="flex items-start justify-between">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-forest/10 to-primary/10 text-3xl">
                  {plant.image}
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge variant="secondary" className="text-[10px]">
                    {plant.category}
                  </Badge>
                  {plant.airPurifying && (
                    <Badge className={`text-[10px] ${getOxygenColor(plant.oxygenOutput)}`}>
                      <Wind className="h-2.5 w-2.5 mr-1" />
                      {plant.oxygenOutput} O₂
                    </Badge>
                  )}
                </div>
              </div>

              {/* Plant Info */}
              <div className="mt-3">
                <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                  {plant.name}
                </h3>
                <p className="text-xs italic text-muted-foreground">{plant.scientific}</p>
                <p className="mt-2 text-xs text-muted-foreground line-clamp-2">
                  {plant.description}
                </p>
              </div>

              {/* Growing Conditions */}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Sun className="h-3.5 w-3.5 text-amber-500" />
                  <span className="truncate">{plant.sunlight}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Droplets className="h-3.5 w-3.5 text-blue-500" />
                  <span>{plant.water}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="h-3.5 w-3.5 text-forest" />
                  <span className="truncate">{plant.growTime}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <ThermometerSun className="h-3.5 w-3.5 text-destructive" />
                  <span>{plant.temperature}</span>
                </div>
              </div>

              {/* Action Button */}
              <Button 
                variant="outline" 
                size="sm"
                className="mt-4 w-full text-xs transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary"
              >
                Add to Garden Plan
              </Button>
            </div>
          ))}
        </div>

        {filteredPlants.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No plants found matching your search.</p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
