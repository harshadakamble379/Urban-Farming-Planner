import { useState, useRef } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Camera, Upload, Loader2, Leaf, Sparkles, 
  Droplets, Sun, TreePine, Info
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface PlantResult {
  commonName: string;
  scientificName: string;
  family: string;
  confidence: string;
  description: string;
  careInstructions: string;
  funFact: string;
}

export default function PlantIdentify() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [result, setResult] = useState<PlantResult | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Image must be under 10MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setImagePreview(dataUrl);
      setImageBase64(dataUrl.split(",")[1]);
      setResult(null);
    };
    reader.readAsDataURL(file);
  };

  const handleIdentify = async () => {
    if (!imageBase64) return;
    setLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke("identify-plant", {
        body: { imageBase64 },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setResult(data);
      toast.success("Plant identified!");
    } catch (err: any) {
      console.error("Identification error:", err);
      toast.error(err.message || "Failed to identify plant");
    } finally {
      setLoading(false);
    }
  };

  const confidenceColor = (c: string) => {
    switch (c) {
      case "high": return "bg-green-500/15 text-green-700 dark:text-green-400";
      case "medium": return "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400";
      default: return "bg-red-500/15 text-red-700 dark:text-red-400";
    }
  };

  return (
    <MainLayout>
      <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Sparkles className="h-8 w-8 text-primary" />
            Plant Identifier
          </h1>
          <p className="mt-1 text-muted-foreground">
            Upload a photo and our AI will identify the plant species
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Upload Area */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Camera className="h-5 w-5" /> Upload Photo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleFileSelect}
              />
              
              {imagePreview ? (
                <div className="space-y-3">
                  <div className="relative rounded-xl overflow-hidden border bg-muted aspect-square">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1 gap-2" onClick={() => fileInputRef.current?.click()}>
                      <Upload className="h-4 w-4" /> Change
                    </Button>
                    <Button className="flex-1 gap-2" onClick={handleIdentify} disabled={loading}>
                      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                      {loading ? "Identifying..." : "Identify"}
                    </Button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full aspect-square rounded-xl border-2 border-dashed border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors flex flex-col items-center justify-center gap-4 cursor-pointer"
                >
                  <div className="h-16 w-16 rounded-full bg-primary/15 flex items-center justify-center">
                    <Camera className="h-8 w-8 text-primary" />
                  </div>
                  <div className="text-center">
                    <p className="font-medium text-foreground">Take a photo or upload</p>
                    <p className="text-sm text-muted-foreground mt-1">JPG, PNG up to 10MB</p>
                  </div>
                </button>
              )}
            </CardContent>
          </Card>

          {/* Results */}
          <div className="space-y-4">
            {loading && (
              <Card>
                <CardContent className="py-12 flex flex-col items-center gap-4">
                  <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  <p className="text-muted-foreground">Analyzing your plant...</p>
                </CardContent>
              </Card>
            )}

            {result && !loading && (
              <>
                <Card className="border-primary/30">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-2xl flex items-center gap-2">
                          <Leaf className="h-6 w-6 text-primary" />
                          {result.commonName}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground italic mt-1">{result.scientificName}</p>
                      </div>
                      <Badge className={confidenceColor(result.confidence)}>
                        {result.confidence} confidence
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-2">
                      <TreePine className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm"><span className="font-medium">Family:</span> {result.family}</span>
                    </div>
                    <p className="text-sm text-foreground/80 leading-relaxed">{result.description}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Droplets className="h-4 w-4 text-blue-500" /> Care Instructions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-foreground/80 leading-relaxed">{result.careInstructions}</p>
                  </CardContent>
                </Card>

                <Card className="bg-primary/5 border-primary/20">
                  <CardContent className="py-4">
                    <div className="flex items-start gap-3">
                      <Info className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-primary">Fun Fact</p>
                        <p className="text-sm text-foreground/80 mt-1">{result.funFact}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {!result && !loading && (
              <Card>
                <CardContent className="py-12 text-center">
                  <Leaf className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-semibold">Upload a plant photo</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Our AI will identify the species and provide care tips
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
