import { useState, useEffect, useRef, lazy, Suspense, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence, useScroll, useTransform } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Leaf, Droplets, Sun, TreeDeciduous, Sprout, ArrowRight, Sparkles, Moon, CloudRain } from "lucide-react";

// Pre-generate stable random values for particles to avoid recalculation
// Mobile-optimized counts
const PARTICLE_COUNT_MOBILE = 6;
const PARTICLE_COUNT_DESKTOP = 12;
const STAR_COUNT_MOBILE = 10;
const STAR_COUNT_DESKTOP = 20;

const generateParticlePositions = (count: number) => 
  Array.from({ length: count }, (_, i) => ({
    id: i,
    left: `${(i * 37 + 13) % 100}%`,
    top: `${(i * 53 + 7) % 100}%`,
    duration: 5 + (i % 5),
    delay: (i % 3) * 0.5,
  }));

const generateStarPositions = (count: number) =>
  Array.from({ length: count }, (_, i) => ({
    id: i,
    left: `${(i * 41 + 11) % 100}%`,
    top: `${(i * 29 + 5) % 60}%`,
    size: 1 + (i % 2),
    duration: 2 + (i % 3),
    delay: (i % 4) * 0.5,
  }));

// Lazy load heavy animated components to reduce main-thread work
const InteractiveEcosystem = lazy(() => import("@/components/landing/InteractiveEcosystem").then(m => ({ default: m.InteractiveEcosystem })));
const ConfettiEffect = lazy(() => import("@/components/landing/ConfettiEffect").then(m => ({ default: m.ConfettiEffect })));
const WeatherEffects = lazy(() => import("@/components/landing/WeatherEffects").then(m => ({ default: m.WeatherEffects })));
const LightingEffects = lazy(() => import("@/components/landing/LightingEffects").then(m => ({ default: m.LightingEffects })));

type TimeOfDay = "dawn" | "day" | "dusk" | "night";

// Climate-based color palette with smooth transitions
const timeColors: Record<TimeOfDay, { 
  gradient: string;
  mesh1: string;
  mesh2: string;
  mesh3: string;
  textColor: string;
}> = {
  dawn: { 
    gradient: "from-indigo-900 via-rose-400 to-amber-300",
    mesh1: "bg-rose-500/30",
    mesh2: "bg-amber-400/25",
    mesh3: "bg-pink-300/20",
    textColor: "text-amber-100"
  },
  day: { 
    gradient: "from-sky-400 via-emerald-400 to-green-500",
    mesh1: "bg-emerald-500/30",
    mesh2: "bg-teal-400/25",
    mesh3: "bg-green-300/20",
    textColor: "text-white"
  },
  dusk: { 
    gradient: "from-violet-900 via-orange-500 to-rose-400",
    mesh1: "bg-orange-500/30",
    mesh2: "bg-purple-400/25",
    mesh3: "bg-rose-300/20",
    textColor: "text-rose-100"
  },
  night: { 
    gradient: "from-slate-950 via-indigo-950 to-slate-900",
    mesh1: "bg-indigo-500/20",
    mesh2: "bg-purple-500/15",
    mesh3: "bg-blue-400/10",
    textColor: "text-indigo-100"
  },
};

const timeOrder: TimeOfDay[] = ["dawn", "day", "dusk", "night"];

const Landing = () => {
  const navigate = useNavigate();
  const [showContent, setShowContent] = useState(true);
  const [currentFeature, setCurrentFeature] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [showConfetti, setShowConfetti] = useState(false);
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>("day");
  const [isRaining, setIsRaining] = useState(false);
  const [windIntensity, setWindIntensity] = useState(0);
  const [isHydrated, setIsHydrated] = useState(false);
  const [loadEffects, setLoadEffects] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Detect mobile for reduced animations
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Generate positions based on device
  const particlePositions = useMemo(() => 
    generateParticlePositions(isMobile ? PARTICLE_COUNT_MOBILE : PARTICLE_COUNT_DESKTOP), 
    [isMobile]
  );
  const starPositions = useMemo(() => 
    generateStarPositions(isMobile ? STAR_COUNT_MOBILE : STAR_COUNT_DESKTOP), 
    [isMobile]
  );

  const { scrollY } = useScroll();
  
  // Parallax transforms for different layers
  const bgY = useTransform(scrollY, [0, 500], [0, 150]);
  const meshY = useTransform(scrollY, [0, 500], [0, 100]);
  const particlesY = useTransform(scrollY, [0, 500], [0, 50]);
  const contentY = useTransform(scrollY, [0, 500], [0, -30]);

  const isNight = timeOfDay === "night";

  const features = [
    {
      icon: TreeDeciduous,
      title: "Plan Your Urban Farm",
      description: "Design custom garden layouts for any space, from balconies to rooftops",
      color: "from-emerald-400 to-green-500",
    },
    {
      icon: Leaf,
      title: "Smart Plant Selection",
      description: "Get recommendations based on your climate, space, and growing conditions",
      color: "from-green-400 to-teal-500",
    },
    {
      icon: Droplets,
      title: "Resource Management",
      description: "Track water usage, organic fertilizers, and optimize your resources",
      color: "from-cyan-400 to-blue-500",
    },
    {
      icon: Sun,
      title: "Grow Together",
      description: "Perfect for NGOs, contractors, and builders creating sustainable spaces",
      color: "from-amber-400 to-orange-500",
    },
  ];

  // Show loading screen briefly, then transition to content
  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      setIsLoading(false);
    }, 500); // Show loading for 0.5 seconds (faster transition)
    return () => clearTimeout(loadingTimer);
  }, []);

  // Defer simple animations until after loading screen
  useEffect(() => {
    if (!isLoading) {
      const timer = requestAnimationFrame(() => {
        setIsHydrated(true);
      });
      return () => cancelAnimationFrame(timer);
    }
  }, [isLoading]);

  // Defer heavy effect components loading until browser is idle
  useEffect(() => {
    if ('requestIdleCallback' in window) {
      const id = (window as any).requestIdleCallback(() => {
        setLoadEffects(true);
      }, { timeout: 2000 });
      return () => (window as any).cancelIdleCallback(id);
    } else {
      // Fallback for Safari
      const timer = setTimeout(() => setLoadEffects(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  // Feature carousel - starts immediately
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [features.length]);

// Day/Night cycle - changes every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeOfDay(prev => {
        const currentIndex = timeOrder.indexOf(prev);
        return timeOrder[(currentIndex + 1) % timeOrder.length];
      });
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleGetStarted = () => {
    setShowConfetti(true);
    setTimeout(() => {
      navigate("/auth");
    }, 800);
  };

  // Loading Screen
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-forest-dark via-forest to-forest-light overflow-hidden">
        {/* Background glow */}
        <motion.div
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl" />
        </motion.div>

        <div className="relative flex flex-col items-center">
          {/* Soil/Ground */}
          <motion.div
            className="absolute bottom-0 w-24 h-6 bg-gradient-to-t from-amber-900 to-amber-800 rounded-t-lg"
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: 1 }}
            transition={{ delay: 0.05, duration: 0.2 }}
          />

          {/* Growing sprout container */}
          <motion.div
            className="relative z-10"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.2 }}
          >
            {/* Sprout stem growing */}
            <motion.div
              className="absolute bottom-6 left-1/2 -translate-x-1/2 w-2 bg-gradient-to-t from-green-600 to-green-400 rounded-full origin-bottom"
              initial={{ height: 0 }}
              animate={{ height: 40 }}
              transition={{ delay: 0.15, duration: 0.3, ease: "easeOut" }}
            />

            {/* Sprout icon growing */}
            <motion.div
              className="relative"
              initial={{ scale: 0, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              transition={{ 
                delay: 0.2, 
                duration: 0.3, 
                type: "spring",
                stiffness: 200,
                damping: 10
              }}
            >
              <motion.div
                className="w-28 h-28 rounded-full bg-gradient-to-br from-emerald-400 via-green-500 to-teal-600 flex items-center justify-center shadow-2xl"
                animate={{ 
                  boxShadow: [
                    "0 0 30px rgba(16, 185, 129, 0.4)",
                    "0 0 80px rgba(16, 185, 129, 0.8)",
                    "0 0 30px rgba(16, 185, 129, 0.4)"
                  ]
                }}
                transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
              >
                <motion.div
                  initial={{ scale: 0, rotate: -45 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.35, duration: 0.3, type: "spring" }}
                >
                  <Sprout className="w-14 h-14 text-white drop-shadow-lg" />
                </motion.div>
              </motion.div>

              {/* Leaves sprouting */}
              <motion.div
                className="absolute -left-4 top-1/2 -translate-y-1/2"
                initial={{ scale: 0, rotate: 45, opacity: 0 }}
                animate={{ scale: 1, rotate: 0, opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.2, type: "spring" }}
              >
                <Leaf className="w-8 h-8 text-lime-400 transform -rotate-45" />
              </motion.div>
              <motion.div
                className="absolute -right-4 top-1/2 -translate-y-1/2"
                initial={{ scale: 0, rotate: -45, opacity: 0 }}
                animate={{ scale: 1, rotate: 0, opacity: 1 }}
                transition={{ delay: 0.45, duration: 0.2, type: "spring" }}
              >
                <Leaf className="w-8 h-8 text-lime-400 transform rotate-45 scale-x-[-1]" />
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Loading text */}
          <motion.p
            className="mt-12 text-emerald-200/80 text-lg font-medium tracking-wide"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.2 }}
          >
            Growing your experience...
          </motion.p>

          {/* Loading dots */}
          <motion.div
            className="flex gap-2 mt-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.55, duration: 0.15 }}
          >
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-2 h-2 bg-emerald-400 rounded-full"
                animate={{ 
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{ 
                  duration: 0.8, 
                  repeat: Infinity, 
                  delay: i * 0.1 
                }}
              />
            ))}
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="min-h-screen overflow-hidden relative bg-black">
      {/* Lazy loaded effects - only after browser idle for better FCP */}
      {loadEffects && (
        <Suspense fallback={null}>
          {/* Confetti Effect */}
          <ConfettiEffect trigger={showConfetti} onComplete={() => setShowConfetti(false)} />

          {/* Lighting Effects - sun rays, aurora */}
          <LightingEffects timeOfDay={timeOfDay} />

          {/* Interactive Ecosystem Layer */}
          <InteractiveEcosystem isNight={isNight} windIntensity={windIntensity} />

          {/* Weather Effects with time-aware clouds */}
          <WeatherEffects 
            isRaining={isRaining} 
            showClouds={true} 
            isNight={isNight} 
            timeOfDay={timeOfDay}
            onWindChange={setWindIntensity} 
          />
        </Suspense>
      )}

      {/* Day/Night toggle button */}
      <motion.button
        className="absolute top-4 right-4 z-50 p-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-colors"
        onClick={() => setTimeOfDay(prev => timeOrder[(timeOrder.indexOf(prev) + 1) % timeOrder.length])}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        title={`Current: ${timeOfDay} (click to change)`}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={timeOfDay}
            initial={{ rotate: -180, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            exit={{ rotate: 180, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {isNight ? (
              <Moon className="w-6 h-6 text-yellow-200" />
            ) : timeOfDay === "dawn" ? (
              <Sun className="w-6 h-6 text-orange-300" />
            ) : timeOfDay === "dusk" ? (
              <Sun className="w-6 h-6 text-pink-300" />
            ) : (
              <Sun className="w-6 h-6 text-yellow-300" />
            )}
          </motion.div>
        </AnimatePresence>
      </motion.button>

      {/* Rain toggle button */}
      <motion.button
        className={`absolute top-4 right-16 z-50 p-3 rounded-full backdrop-blur-sm border border-white/20 transition-colors ${isRaining ? 'bg-blue-500/30' : 'bg-white/10 hover:bg-white/20'}`}
        onClick={() => setIsRaining(prev => !prev)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        title={isRaining ? "Stop rain" : "Make it rain"}
      >
        <CloudRain className={`w-6 h-6 ${isRaining ? 'text-blue-300' : 'text-white/70'}`} />
      </motion.button>

      {/* Stars for night mode - Deferred for better FCP */}
      {isHydrated && (
        <AnimatePresence>
          {isNight && (
            <motion.div
              className="absolute inset-0 overflow-hidden pointer-events-none -z-5"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1 }}
            >
              {starPositions.map((star) => (
                <motion.div
                  key={`star-${star.id}`}
                  className="absolute rounded-full bg-white"
                  style={{
                    left: star.left,
                    top: star.top,
                    width: star.size,
                    height: star.size,
                  }}
                  animate={{
                    opacity: [0.3, 1, 0.3],
                  }}
                  transition={{
                    duration: star.duration,
                    repeat: Infinity,
                    delay: star.delay,
                  }}
                />
              ))}
              {/* Moon */}
              <motion.div
                className="absolute top-16 right-24 w-16 h-16 rounded-full bg-gradient-to-br from-yellow-100 to-yellow-200"
                style={{
                  boxShadow: "0 0 40px rgba(255, 255, 200, 0.5), 0 0 80px rgba(255, 255, 200, 0.3)",
                }}
                animate={{
                  boxShadow: [
                    "0 0 40px rgba(255, 255, 200, 0.5), 0 0 80px rgba(255, 255, 200, 0.3)",
                    "0 0 60px rgba(255, 255, 200, 0.7), 0 0 100px rgba(255, 255, 200, 0.4)",
                    "0 0 40px rgba(255, 255, 200, 0.5), 0 0 80px rgba(255, 255, 200, 0.3)",
                  ],
                }}
                transition={{ duration: 4, repeat: Infinity }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      )}

      {/* Animated gradient background - Base Layer */}
      <motion.div 
        className={`absolute inset-0 z-0 bg-gradient-to-br ${timeColors[timeOfDay].gradient} transition-all duration-[2000ms] ease-in-out`}
        style={{ y: bgY }}
      />
      
      {/* Mesh gradient overlay - Climate-aware colors */}
      <div 
        className="absolute inset-0 z-[1] opacity-70 pointer-events-none"
        style={{ contain: 'layout paint' }}
      >
        <div 
          className={`absolute rounded-full blur-3xl transition-all duration-[2000ms] ease-in-out ${timeColors[timeOfDay].mesh1}`} 
          style={{ top: '-10%', left: '15%', width: '500px', height: '500px' }}
        />
        <div 
          className={`absolute rounded-full blur-3xl transition-all duration-[2000ms] ease-in-out ${timeColors[timeOfDay].mesh2}`} 
          style={{ bottom: '-5%', right: '10%', width: '450px', height: '450px' }}
        />
        <div 
          className={`absolute rounded-full blur-3xl transition-all duration-[2000ms] ease-in-out ${timeColors[timeOfDay].mesh3}`} 
          style={{ top: '40%', left: '50%', transform: 'translate(-50%, -50%)', width: '400px', height: '400px' }}
        />
      </div>

      {/* Floating particles - Parallax Layer 3 - Deferred for better FCP */}
      {isHydrated && (
        <motion.div 
          className="absolute inset-0 overflow-hidden"
          style={{ y: particlesY }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {particlePositions.map((particle) => (
            <motion.div
              key={particle.id}
              className="absolute"
              style={{
                left: particle.left,
                top: particle.top,
              }}
              animate={{
                y: [-20, 20, -20],
                x: [-10, 10, -10],
                opacity: [0.2, 0.5, 0.2],
              }}
              transition={{
                duration: particle.duration,
                repeat: Infinity,
                delay: particle.delay,
              }}
            >
              <Sparkles className="w-3 h-3 text-emerald-300/40" />
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Grid pattern overlay */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }}
      />

      {/* Main content - Parallax Layer 4 (fastest, moves against scroll) */}
      <motion.div 
        className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-12"
        style={{ y: contentY }}
      >
        {/* Logo animation */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", duration: 1.2, bounce: 0.4 }}
          className="mb-10"
        >
          <div className="relative">
            {/* Outer glow ring */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
              className="absolute -inset-6"
            >
              <div className="w-full h-full rounded-full border-2 border-dashed border-emerald-400/30" />
            </motion.div>
            
            {/* Inner glow ring */}
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute -inset-3"
            >
              <div className="w-full h-full rounded-full border border-dotted border-green-300/40" />
            </motion.div>
            
            {/* Logo circle */}
            <motion.div
              animate={{ 
                boxShadow: [
                  "0 0 30px rgba(16, 185, 129, 0.4)",
                  "0 0 60px rgba(16, 185, 129, 0.6)",
                  "0 0 30px rgba(16, 185, 129, 0.4)"
                ]
              }}
              transition={{ duration: 3, repeat: Infinity }}
              className="w-32 h-32 rounded-full bg-gradient-to-br from-emerald-400 via-green-500 to-teal-600 flex items-center justify-center"
            >
              <Sprout className="w-16 h-16 text-white drop-shadow-lg" />
            </motion.div>
          </div>
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="text-center mb-6"
        >
          <h1 className="text-6xl md:text-8xl font-bold tracking-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
            <motion.span
              className="inline-block bg-gradient-to-r from-amber-200 via-yellow-100 to-lime-200 bg-clip-text text-transparent drop-shadow-lg"
              style={{ 
                textShadow: "2px 2px 8px rgba(139, 90, 43, 0.3)",
                filter: "drop-shadow(0 4px 6px rgba(34, 139, 34, 0.2))"
              }}
              animate={{
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              {"Urban Grow".split("").map((char, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 20, rotateX: -90 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0 }}
                  transition={{
                    delay: 0.4 + index * 0.08,
                    duration: 0.6,
                    type: "spring",
                    stiffness: 100,
                  }}
                  className="inline-block"
                  style={{ display: char === " " ? "inline" : "inline-block" }}
                >
                  {char === " " ? "\u00A0" : char}
                </motion.span>
              ))}
            </motion.span>
          </h1>
          {/* Decorative leaf accents */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1.2, duration: 0.5 }}
            className="flex items-center justify-center gap-4 mt-2"
          >
            <motion.div
              animate={{ rotate: [-5, 5, -5] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Leaf className="w-6 h-6 text-lime-300/60" />
            </motion.div>
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="h-1 w-32 bg-gradient-to-r from-transparent via-amber-400 to-transparent rounded-full"
            />
            <motion.div
              animate={{ rotate: [5, -5, 5] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Leaf className="w-6 h-6 text-lime-300/60 transform scale-x-[-1]" />
            </motion.div>
          </motion.div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-emerald-100/80 text-xl md:text-2xl text-center mb-14 max-w-2xl font-light"
        >
          Transform urban spaces into thriving, sustainable gardens
        </motion.p>

        {/* Feature carousel */}
        <AnimatePresence mode="wait">
          {showContent && (
            <motion.div
              key={currentFeature}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -30, scale: 0.95 }}
              transition={{ duration: 0.5 }}
              className="relative mb-14 max-w-lg w-full"
            >
              {/* Card glow effect */}
              <div className={`absolute inset-0 bg-gradient-to-r ${features[currentFeature].color} opacity-20 blur-2xl rounded-3xl`} />
              
              <div className="relative bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
                <div className="flex items-center gap-5 mb-5">
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.2 }}
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${features[currentFeature].color} flex items-center justify-center shadow-lg`}
                  >
                    {(() => {
                      const Icon = features[currentFeature].icon;
                      return <Icon className="w-8 h-8 text-white" />;
                    })()}
                  </motion.div>
                  <h2 className="text-2xl font-bold text-white">
                    {features[currentFeature].title}
                  </h2>
                </div>
                <p className="text-emerald-100/80 text-lg leading-relaxed">
                  {features[currentFeature].description}
                </p>
                
                {/* Feature indicators */}
                <div className="flex gap-3 mt-8 justify-center" role="tablist" aria-label="Feature carousel navigation">
                  {features.map((feature, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentFeature(i)}
                      aria-label={`Go to feature ${i + 1}: ${feature.title}`}
                      aria-selected={i === currentFeature}
                      role="tab"
                      className={`h-2 rounded-full transition-all duration-500 ${
                        i === currentFeature 
                          ? "bg-white w-8" 
                          : "bg-white/30 w-2 hover:bg-white/50"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Get Started Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.6 }}
        >
          <Button
            onClick={handleGetStarted}
            size="lg"
            className="relative overflow-hidden bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 hover:from-emerald-400 hover:via-green-400 hover:to-teal-400 text-white text-lg px-12 py-7 rounded-full shadow-2xl shadow-emerald-500/40 group transition-all duration-300 hover:scale-105 hover:shadow-emerald-500/60 border border-white/20"
          >
            <span className="relative z-10 flex items-center font-semibold">
              Get Started
              <ArrowRight className="ml-3 w-5 h-5 group-hover:translate-x-2 transition-transform duration-300" />
            </span>
            {/* Button shine effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -skew-x-12"
              animate={{ x: ["-200%", "200%"] }}
              transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
            />
          </Button>
        </motion.div>

        {/* Bottom info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.4, duration: 0.6 }}
          className="mt-8 text-center"
        >
          <p 
            className="text-sm font-medium tracking-wide bg-gradient-to-r from-amber-200 via-yellow-100 to-lime-200 bg-clip-text text-transparent"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Designed for NGOs, contractors, and urban planners
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Landing;
