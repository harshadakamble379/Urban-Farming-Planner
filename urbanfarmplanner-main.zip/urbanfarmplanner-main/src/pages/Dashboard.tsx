import React, { useState, useEffect } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { QuickActions } from "@/components/dashboard/QuickActions";
import { RecentProjects } from "@/components/dashboard/RecentProjects";
import { ResourceOverview } from "@/components/dashboard/ResourceOverview";
import { AirQualityMonitor } from "@/components/dashboard/AirQualityMonitor";
import { PlantCareReminders } from "@/components/dashboard/PlantCareReminders";
import { CareCalendar } from "@/components/dashboard/CareCalendar";
import { NotificationToggle } from "@/components/dashboard/NotificationToggle";
import { LocationDisplay } from "@/components/dashboard/LocationDisplay";
import { PlantHealthTracker } from "@/components/dashboard/PlantHealthTracker";
import { GrowthCharts } from "@/components/dashboard/GrowthCharts";
import { WeatherForecast } from "@/components/dashboard/WeatherForecast";
import { PageSkeleton } from "@/components/ui/page-skeleton";
import { useNotifications } from "@/hooks/useNotifications";
import { Leaf, Building2, Droplets, Wind } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Project {
  id: string;
  name: string;
  grid_items: any[];
  created_at: string;
  updated_at: string;
}

export default function Dashboard() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState("Urban Farmer");

  // Initialize notifications
  useNotifications();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    
    // Get user
    const { data: { user } } = await supabase.auth.getUser();
    if (user?.email) {
      setUserName(user.email.split('@')[0]);
    }

    // Get projects
    const { data: projectsData } = await supabase
      .from("projects")
      .select("*")
      .order("updated_at", { ascending: false });

    if (projectsData) {
      setProjects(projectsData as unknown as Project[]);
    }

    setLoading(false);
  };

  // Calculate stats from real data
  const totalPlants = projects.reduce((sum, p) => {
    const items = Array.isArray(p.grid_items) ? p.grid_items : [];
    return sum + items.length;
  }, 0);

  const uniqueSpecies = new Set(
    projects.flatMap(p => {
      const items = Array.isArray(p.grid_items) ? p.grid_items : [];
      return items.map((item: any) => item.name);
    })
  ).size;

  // Estimate water usage (15L per plant per week average)
  const weeklyWater = totalPlants * 15;

  // Estimate oxygen production (average plant produces ~5ml O2/hour, ~120ml/day)
  const dailyOxygen = totalPlants * 120; // ml per day

  if (loading) {
    return (
      <MainLayout>
        <PageSkeleton variant="dashboard" />
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-8 animate-fade-in">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              Welcome back, <span className="text-gradient-primary capitalize">{userName}</span>
            </h1>
            <p className="mt-2 text-muted-foreground">
              Here's an overview of your urban farming projects and resources.
            </p>
            <div className="mt-3">
              <LocationDisplay />
            </div>
          </div>
          <NotificationToggle />
        </div>

        {/* Stats Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Active Projects"
            value={loading ? "..." : projects.length}
            subtitle={`${projects.length > 0 ? "Managing your gardens" : "Start your first project"}`}
            icon={Building2}
            trend={projects.length > 0 ? { value: 8, isPositive: true } : undefined}
            variant="primary"
          />
          <StatsCard
            title="Plants Growing"
            value={loading ? "..." : totalPlants}
            subtitle={`${uniqueSpecies} different species`}
            icon={Leaf}
            trend={totalPlants > 0 ? { value: 12, isPositive: true } : undefined}
          />
          <StatsCard
            title="Water Usage"
            value={loading ? "..." : `${weeklyWater}L`}
            subtitle="Per week estimate"
            icon={Droplets}
            trend={weeklyWater > 0 ? { value: 5, isPositive: false } : undefined}
            variant="accent"
          />
          <StatsCard
            title="Oxygen Output"
            value={loading ? "..." : `${(dailyOxygen / 1000).toFixed(1)}L`}
            subtitle="Daily O₂ production"
            icon={Wind}
            trend={dailyOxygen > 0 ? { value: 15, isPositive: true } : undefined}
          />
        </div>

        {/* Weather Forecast */}
        <WeatherForecast />

        {/* Care Calendar - Full Width */}
        <CareCalendar />

        {/* Growth Charts - Full Width */}
        <GrowthCharts />

        {/* Main Content Grid */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <PlantHealthTracker />
            <RecentProjects projects={projects} loading={loading} />
            <AirQualityMonitor totalPlants={totalPlants} />
          </div>
          <div className="space-y-6">
            <PlantCareReminders />
            <QuickActions />
            <ResourceOverview totalPlants={totalPlants} weeklyWater={weeklyWater} />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}