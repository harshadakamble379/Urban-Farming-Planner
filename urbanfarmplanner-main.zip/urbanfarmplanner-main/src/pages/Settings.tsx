import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SecureAvatar } from "@/components/ui/secure-avatar";
import { 
  User, 
  Bell, 
  MapPin, 
  Palette,
  Loader2,
  Thermometer,
  LogOut,
  Moon,
  Sun,
  Monitor,
  Camera,
  Upload,
  ShoppingCart,
  FolderKanban,
  ChevronRight
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTheme } from "next-themes";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLocation, cityData, climateZones } from "@/contexts/LocationContext";

interface UserSettings {
  name: string;
  organization: string;
  city: string;
  climate_zone: string;
  watering_reminders: boolean;
  low_inventory_alerts: boolean;
  growth_milestones: boolean;
  weekly_reports: boolean;
  avatar_url: string | null;
}

export default function Settings() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [userId, setUserId] = useState<string | null>(null);
  const { updateCity, currentTemperature, humidity } = useLocation();
  const { theme, setTheme } = useTheme();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [settings, setSettings] = useState<UserSettings>({
    name: "Urban Farmer",
    organization: "",
    city: "New York",
    climate_zone: "Temperate (12°C avg)",
    watering_reminders: true,
    low_inventory_alerts: true,
    growth_milestones: false,
    weekly_reports: true,
    avatar_url: null,
  });

  const cities = Object.keys(cityData);

  useEffect(() => {
    loadSettings();
  }, []);

  const getClimateZoneForCity = (city: string) => {
    const info = cityData[city];
    if (!info) return "Temperate (15°C avg)";
    const zone = climateZones.find(z => z.id === info.climate);
    return zone ? `${zone.name} (${info.avgTemp}°C avg)` : "Temperate (15°C avg)";
  };

  const loadSettings = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setLoading(false);
      return;
    }

    setUserEmail(user.email || "");
    setUserId(user.id);

    const { data, error } = await supabase
      .from("user_settings")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle();

    if (error) {
      console.error("Error loading settings:", error);
    } else if (data) {
      const city = data.city || "New York";
      setSettings({
        name: data.name || "Urban Farmer",
        organization: data.organization || "",
        city: city,
        climate_zone: getClimateZoneForCity(city),
        watering_reminders: data.watering_reminders ?? true,
        low_inventory_alerts: data.low_inventory_alerts ?? true,
        growth_milestones: data.growth_milestones ?? false,
        weekly_reports: data.weekly_reports ?? true,
        avatar_url: (data as any).avatar_url || null,
      });
    }
    setLoading(false);
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !userId) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error("Please select an image file");
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Image must be less than 2MB");
      return;
    }

    setUploadingAvatar(true);

    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `${userId}/avatar.${fileExt}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      // Store just the file path - we'll generate signed URLs when displaying
      const avatarUrl = filePath;

      // Update settings in database
      const { error: updateError } = await supabase
        .from("user_settings")
        .upsert({
          user_id: userId,
          avatar_url: avatarUrl,
        }, { onConflict: "user_id" });

      if (updateError) throw updateError;

      setSettings(prev => ({ ...prev, avatar_url: avatarUrl }));
      toast.success("Avatar updated successfully!");
    } catch (error: any) {
      console.error("Avatar upload error:", error);
      toast.error("Failed to upload avatar");
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleCityChange = (city: string) => {
    const climateZone = getClimateZoneForCity(city);
    setSettings({ ...settings, city, climate_zone: climateZone });
    updateCity(city);
  };

  const saveSettings = async () => {
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please log in to save settings");
      setSaving(false);
      return;
    }

    const { error } = await supabase
      .from("user_settings")
      .upsert({
        user_id: user.id,
        name: settings.name,
        organization: settings.organization,
        city: settings.city,
        climate_zone: settings.climate_zone,
        watering_reminders: settings.watering_reminders,
        low_inventory_alerts: settings.low_inventory_alerts,
        growth_milestones: settings.growth_milestones,
        weekly_reports: settings.weekly_reports,
      }, { onConflict: "user_id" });

    if (error) {
      toast.error("Failed to save settings");
      console.error(error);
    } else {
      toast.success("Settings saved successfully!");
    }
    setSaving(false);
  };

  const handleLogout = async () => {
    setLoggingOut(true);
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error("Failed to log out");
      console.error(error);
    } else {
      toast.success("Logged out successfully");
      navigate("/");
    }
    setLoggingOut(false);
  };

  const exportData = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please log in to export data");
      return;
    }

    const { data: projects } = await supabase
      .from("projects")
      .select("*")
      .eq("user_id", user.id);

    const { data: reminders } = await supabase
      .from("plant_reminders")
      .select("*")
      .eq("user_id", user.id);

    const { data: healthLogs } = await supabase
      .from("plant_health_logs")
      .select("*")
      .eq("user_id", user.id);

    const exportData = {
      exportedAt: new Date().toISOString(),
      settings,
      projects: projects || [],
      reminders: reminders || [],
      healthLogs: healthLogs || [],
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `plant-care-export-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success("Data exported successfully!");
  };

  const deleteAllProjects = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please log in");
      return;
    }

    const { error } = await supabase
      .from("projects")
      .delete()
      .eq("user_id", user.id);

    if (error) {
      toast.error("Failed to delete projects");
    } else {
      toast.success("All projects deleted");
    }
  };

  const notificationSettings = [
    { 
      key: "watering_reminders" as const, 
      label: "Watering reminders", 
      description: "Get notified when plants need water" 
    },
    { 
      key: "low_inventory_alerts" as const, 
      label: "Low inventory alerts", 
      description: "Alert when supplies run low" 
    },
    { 
      key: "growth_milestones" as const, 
      label: "Growth milestones", 
      description: "Celebrate plant growth achievements" 
    },
    { 
      key: "weekly_reports" as const, 
      label: "Weekly reports", 
      description: "Receive weekly farm summary" 
    },
  ];

  const themeOptions = [
    { value: "light", label: "Light", icon: Sun },
    { value: "dark", label: "Dark", icon: Moon },
    { value: "system", label: "System", icon: Monitor },
  ];

  if (loading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-2xl space-y-8 animate-fade-in">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Settings</h1>
          <p className="mt-1 text-muted-foreground">
            Manage your account and application preferences
          </p>
        </div>

        {/* Profile Settings */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <User className="h-5 w-5 text-primary" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Profile</h2>
          </div>
          
          <div className="space-y-6">
            {/* Avatar Upload Section */}
            <div className="flex items-center gap-4">
              <div className="relative group">
                <SecureAvatar
                  bucket="avatars"
                  path={settings.avatar_url}
                  alt={settings.name}
                  fallbackText={settings.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                  className="h-20 w-20 border-2 border-border"
                  fallbackClassName="text-xl bg-primary/10 text-primary"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingAvatar}
                  className="absolute inset-0 flex items-center justify-center rounded-full bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  {uploadingAvatar ? (
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  ) : (
                    <Camera className="h-6 w-6 text-primary" />
                  )}
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
              </div>
              <div className="space-y-1">
                <p className="font-medium text-foreground">Profile Photo</p>
                <p className="text-xs text-muted-foreground">
                  Click to upload a new avatar (max 2MB)
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingAvatar}
                  className="gap-2"
                >
                  {uploadingAvatar ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Upload className="h-4 w-4" />
                  )}
                  Upload Photo
                </Button>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input 
                  id="name" 
                  placeholder="Your name" 
                  value={settings.name}
                  onChange={(e) => setSettings({ ...settings, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="org">Organization</Label>
                <Input 
                  id="org" 
                  placeholder="Organization name" 
                  value={settings.organization}
                  onChange={(e) => setSettings({ ...settings, organization: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email" 
                value={userEmail}
                disabled
                className="bg-muted"
              />
              <p className="text-xs text-muted-foreground">Email cannot be changed</p>
            </div>
          </div>
        </div>

        {/* Location Settings */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-terracotta/10">
              <MapPin className="h-5 w-5 text-terracotta" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Location & Climate</h2>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Select value={settings.city} onValueChange={handleCityChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your city" />
                </SelectTrigger>
                <SelectContent>
                  {cities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Climate Zone</Label>
              <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border">
                <Thermometer className="h-5 w-5 text-terracotta" />
                <span className="font-medium">{settings.climate_zone}</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Climate zone is automatically determined based on your city
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 p-4 rounded-lg bg-gradient-to-br from-water/10 to-terracotta/10 border border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1">Current Temperature</p>
                <p className="text-2xl font-bold text-foreground">{currentTemperature}°C</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1">Humidity</p>
                <p className="text-2xl font-bold text-foreground">{humidity}%</p>
              </div>
            </div>
          </div>
        </div>

        {/* Theme Settings */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <Palette className="h-5 w-5 text-accent" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Appearance</h2>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Theme</Label>
              <p className="text-sm text-muted-foreground mb-3">
                Choose your preferred color scheme
              </p>
              <div className="grid grid-cols-3 gap-3">
                {themeOptions.map((option) => {
                  const Icon = option.icon;
                  return (
                    <button
                      key={option.value}
                      onClick={() => setTheme(option.value)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-200 ${
                        theme === option.value
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50 hover:bg-muted/50"
                      }`}
                    >
                      <Icon className={`h-6 w-6 ${theme === option.value ? "text-primary" : "text-muted-foreground"}`} />
                      <span className={`text-sm font-medium ${theme === option.value ? "text-primary" : "text-foreground"}`}>
                        {option.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Notification Settings */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-forest/10">
              <Bell className="h-5 w-5 text-forest" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Notifications</h2>
          </div>
          
          <div className="space-y-4">
            {notificationSettings.map((setting) => (
              <div key={setting.key} className="flex items-center justify-between rounded-lg border border-border p-4">
                <div>
                  <p className="font-medium text-foreground">{setting.label}</p>
                  <p className="text-sm text-muted-foreground">{setting.description}</p>
                </div>
                <Switch 
                  checked={settings[setting.key]}
                  onCheckedChange={(checked) => 
                    setSettings({ ...settings, [setting.key]: checked })
                  }
                />
              </div>
            ))}
          </div>
        </div>

        {/* Order History */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-terracotta/10">
              <ShoppingCart className="h-5 w-5 text-terracotta" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Order History</h2>
          </div>
          
          <div className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full justify-between"
              onClick={() => navigate("/inventory?tab=orders")}
            >
              <span className="flex items-center gap-3">
                <ShoppingCart className="h-4 w-4" />
                View Order History
              </span>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <p className="text-sm text-muted-foreground">
              View all your past orders and track current deliveries
            </p>
          </div>
        </div>

        {/* Planning History */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-forest/10">
              <FolderKanban className="h-5 w-5 text-forest" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Planning History</h2>
          </div>
          
          <div className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full justify-between"
              onClick={() => navigate("/planning")}
            >
              <span className="flex items-center gap-3">
                <FolderKanban className="h-4 w-4" />
                View Planning Projects
              </span>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <p className="text-sm text-muted-foreground">
              Access and manage all your farm planning projects
            </p>
          </div>
        </div>

        {/* Account Actions */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
              <LogOut className="h-5 w-5 text-destructive" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Account</h2>
          </div>
          
          <div className="space-y-3">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3 text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <LogOut className="h-4 w-4" />
                  Log Out
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Log out?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to log out of your account?
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleLogout} 
                    className="bg-destructive hover:bg-destructive/90"
                    disabled={loggingOut}
                  >
                    {loggingOut && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    Log Out
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button 
            className="px-8 bg-primary hover:bg-primary/90"
            onClick={saveSettings}
            disabled={saving}
          >
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </div>
      </div>
    </MainLayout>
  );
}