import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Droplets, 
  Recycle, 
  Leaf, 
  AlertCircle,
  CheckCircle,
  ArrowRight,
  Lightbulb,
  Plus,
  Minus,
  X,
  Clock,
  Beaker
} from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface WaterStat {
  label: string;
  value: number;
  max: number;
  unit: string;
}

interface FertilizerRecipe {
  name: string;
  ingredients: string[];
  time: string;
  npk: string;
  description: string;
  instructions: string[];
}

const waterTips = [
  "Collect rainwater using rooftop catchment systems",
  "Use drip irrigation to reduce water waste by 50%",
  "Water plants during early morning to minimize evaporation",
  "Group plants with similar water needs together",
];

const fertilizerRecipes: FertilizerRecipe[] = [
  {
    name: "Kitchen Compost Mix",
    ingredients: ["Vegetable scraps", "Coffee grounds", "Eggshells", "Brown leaves"],
    time: "4-6 weeks",
    npk: "2-1-2",
    description: "Balanced general-purpose compost from household waste.",
    instructions: [
      "Collect vegetable scraps, coffee grounds, and crushed eggshells in a container",
      "Layer with brown leaves or cardboard for carbon balance",
      "Turn the pile every week to aerate",
      "Keep moist but not waterlogged",
      "Ready when dark, crumbly, and earthy-smelling"
    ]
  },
  {
    name: "Green Tea Fertilizer",
    ingredients: ["Used tea bags", "Banana peels", "Water"],
    time: "2 days",
    npk: "0.5-0.3-0.8",
    description: "Quick liquid fertilizer rich in potassium.",
    instructions: [
      "Collect 5-6 used tea bags and 2-3 banana peels",
      "Place in a bucket with 2 liters of water",
      "Let steep for 48 hours, stirring occasionally",
      "Strain the liquid and dilute 1:1 with water",
      "Apply directly to soil around plants"
    ]
  },
  {
    name: "Worm Castings Mix",
    ingredients: ["Worm castings", "Coconut coir", "Perlite"],
    time: "Ready to use",
    npk: "1-0-0",
    description: "Nutrient-rich soil amendment for seedlings.",
    instructions: [
      "Mix 2 parts worm castings with 1 part coconut coir",
      "Add 1 part perlite for drainage",
      "Blend thoroughly until uniform",
      "Use as top dressing or mix into potting soil",
      "Store in a cool, dry place"
    ]
  },
];

export default function Resources() {
  const [waterStats, setWaterStats] = useState<WaterStat[]>([
    { label: "Current Usage", value: 450, max: 600, unit: "L/week" },
    { label: "Rainwater Collected", value: 120, max: 200, unit: "L this month" },
    { label: "Irrigation Efficiency", value: 85, max: 100, unit: "%" },
  ]);

  const [selectedRecipe, setSelectedRecipe] = useState<FertilizerRecipe | null>(null);
  const [showTipsDialog, setShowTipsDialog] = useState(false);

  const updateWaterStat = (index: number, delta: number) => {
    setWaterStats(prev => {
      const newStats = [...prev];
      const newValue = Math.max(0, Math.min(newStats[index].max, newStats[index].value + delta));
      newStats[index] = { ...newStats[index], value: newValue };
      return newStats;
    });
    toast.success("Water usage updated!");
  };

  const resetWaterStats = () => {
    setWaterStats([
      { label: "Current Usage", value: 450, max: 600, unit: "L/week" },
      { label: "Rainwater Collected", value: 120, max: 200, unit: "L this month" },
      { label: "Irrigation Efficiency", value: 85, max: 100, unit: "%" },
    ]);
    toast.success("Stats reset to default!");
  };

  return (
    <MainLayout>
      <div className="space-y-8 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Resource Management</h1>
            <p className="mt-1 text-muted-foreground">
              Optimize water usage and create organic fertilizers for sustainable farming
            </p>
          </div>
          <Button variant="outline" onClick={resetWaterStats}>
            Reset Stats
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid gap-6 sm:grid-cols-3">
          {waterStats.map((stat, index) => {
            const percentage = (stat.value / stat.max) * 100;
            return (
              <div key={stat.label} className="rounded-2xl bg-card p-6 shadow-card">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Droplets className="h-4 w-4 text-water" />
                    {stat.label}
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => updateWaterStat(index, -10)}
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => updateWaterStat(index, 10)}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-foreground">{stat.value}</span>
                  <span className="text-sm text-muted-foreground">/ {stat.max} {stat.unit}</span>
                </div>
                <Progress value={percentage} className="mt-3 h-2" />
                <div className="mt-2 flex items-center gap-1 text-xs">
                  {percentage >= 80 ? (
                    <>
                      <AlertCircle className="h-3 w-3 text-destructive" />
                      <span className="text-destructive">Approaching limit</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-3 w-3 text-primary" />
                      <span className="text-primary">On track</span>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Water Management */}
          <div className="rounded-2xl bg-card p-6 shadow-card">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-water/10">
                <Droplets className="h-6 w-6 text-water" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Water Optimization</h2>
                <p className="text-sm text-muted-foreground">Tips to reduce water consumption</p>
              </div>
            </div>

            <div className="space-y-3">
              {waterTips.map((tip, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 rounded-xl border border-border p-4 transition-all hover:border-primary/30 hover:bg-secondary/50"
                >
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                    {index + 1}
                  </div>
                  <p className="text-sm text-foreground">{tip}</p>
                </div>
              ))}
            </div>

            <Button 
              className="mt-6 w-full gap-2" 
              variant="outline"
              onClick={() => setShowTipsDialog(true)}
            >
              <Lightbulb className="h-4 w-4" />
              Get Personalized Tips
            </Button>
          </div>

          {/* Organic Fertilizer */}
          <div className="rounded-2xl bg-card p-6 shadow-card">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Recycle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Organic Fertilizers</h2>
                <p className="text-sm text-muted-foreground">DIY recipes from household waste</p>
              </div>
            </div>

            <div className="space-y-4">
              {fertilizerRecipes.map((recipe) => (
                <div
                  key={recipe.name}
                  className="group cursor-pointer rounded-xl border border-border bg-secondary/30 p-4 transition-all hover:border-primary/30 hover:shadow-md"
                  onClick={() => setSelectedRecipe(recipe)}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                        {recipe.name}
                      </h3>
                      <p className="mt-1 text-xs text-muted-foreground">{recipe.description}</p>
                    </div>
                    <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">
                      NPK {recipe.npk}
                    </Badge>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {recipe.ingredients.map((ingredient) => (
                      <span
                        key={ingredient}
                        className="inline-flex items-center rounded-full bg-muted px-2 py-1 text-xs text-foreground border border-border"
                      >
                        <Leaf className="mr-1 h-3 w-3 text-primary" />
                        {ingredient}
                      </span>
                    ))}
                  </div>
                  <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Ready in: {recipe.time}
                    </span>
                    <button className="flex items-center gap-1 font-medium text-primary hover:underline">
                      View Recipe <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recipe Detail Dialog */}
      <Dialog open={!!selectedRecipe} onOpenChange={() => setSelectedRecipe(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Beaker className="h-5 w-5 text-primary" />
              {selectedRecipe?.name}
            </DialogTitle>
            <DialogDescription>{selectedRecipe?.description}</DialogDescription>
          </DialogHeader>
          
          {selectedRecipe && (
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-foreground mb-2">Ingredients</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedRecipe.ingredients.map((ingredient) => (
                    <Badge key={ingredient} variant="secondary" className="gap-1">
                      <Leaf className="h-3 w-3" />
                      {ingredient}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedRecipe.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">NPK:</span>
                  <Badge className="bg-primary/10 text-primary">{selectedRecipe.npk}</Badge>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-foreground mb-2">Instructions</h4>
                <ol className="space-y-2">
                  {selectedRecipe.instructions.map((step, index) => (
                    <li key={index} className="flex gap-3 text-sm">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                        {index + 1}
                      </span>
                      <span className="text-muted-foreground">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <Button 
                className="w-full mt-4" 
                onClick={() => {
                  toast.success(`${selectedRecipe.name} saved to your recipes!`);
                  setSelectedRecipe(null);
                }}
              >
                Save Recipe
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Personalized Tips Dialog */}
      <Dialog open={showTipsDialog} onOpenChange={setShowTipsDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-accent" />
              Personalized Water Tips
            </DialogTitle>
            <DialogDescription>
              Based on your current water usage patterns
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="rounded-lg bg-secondary/50 p-4">
              <h4 className="font-medium text-foreground mb-2">Your Water Score: Good</h4>
              <p className="text-sm text-muted-foreground">
                You're using {waterStats[0].value}L/week which is {Math.round((waterStats[0].value / waterStats[0].max) * 100)}% of your capacity.
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-foreground">Recommendations:</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  Install a timer on your irrigation system for consistent watering
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  Consider mulching to reduce evaporation by up to 25%
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  Check for leaks in your irrigation lines monthly
                </li>
              </ul>
            </div>

            <Button className="w-full" onClick={() => setShowTipsDialog(false)}>
              Got it!
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
