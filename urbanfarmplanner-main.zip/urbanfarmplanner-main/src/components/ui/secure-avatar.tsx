import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';

interface SecureAvatarProps {
  bucket: string;
  path: string | null | undefined;
  alt: string;
  fallbackText?: string;
  className?: string;
  fallbackClassName?: string;
  expiresIn?: number;
}

/**
 * Extract the file path from a full storage URL or return the path as-is
 */
function extractFilePath(bucket: string, path: string): string | null {
  if (!path) return null;

  // If it's already just a path (e.g., "userId/avatar.png"), return as-is
  if (!path.startsWith('http')) {
    return path;
  }

  // Extract path from full Supabase storage URL
  try {
    const url = new URL(path);
    const pathParts = url.pathname.split('/');
    
    // Find the bucket name in the path and get everything after it
    const bucketIndex = pathParts.findIndex(part => part === bucket);
    if (bucketIndex !== -1) {
      return pathParts.slice(bucketIndex + 1).join('/');
    }

    const storageIndex = pathParts.indexOf('storage');
    if (storageIndex !== -1 && pathParts.length > storageIndex + 4) {
      const possibleBucketIndex = storageIndex + 4;
      if (pathParts[possibleBucketIndex] === bucket) {
        return pathParts.slice(possibleBucketIndex + 1).join('/');
      }
    }

    return null;
  } catch {
    return null;
  }
}

/**
 * A secure avatar component that uses signed URLs for private storage buckets
 */
export function SecureAvatar({
  bucket,
  path,
  alt,
  fallbackText = '?',
  className = 'h-10 w-10',
  fallbackClassName = 'bg-primary/10 text-primary',
  expiresIn = 3600,
}: SecureAvatarProps) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!path) {
      setLoading(false);
      return;
    }

    const filePath = extractFilePath(bucket, path);
    if (!filePath) {
      setLoading(false);
      return;
    }

    const fetchSignedUrl = async () => {
      setLoading(true);

      try {
        const { data, error: signError } = await supabase.storage
          .from(bucket)
          .createSignedUrl(filePath, expiresIn);

        if (signError) throw signError;
        setSignedUrl(data?.signedUrl || null);
      } catch (err) {
        console.error('Error creating signed URL for avatar:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSignedUrl();
  }, [bucket, path, expiresIn]);

  if (loading) {
    return <Skeleton className={`${className} rounded-full`} />;
  }

  return (
    <Avatar className={className}>
      <AvatarImage src={signedUrl || undefined} alt={alt} />
      <AvatarFallback className={fallbackClassName}>
        {fallbackText}
      </AvatarFallback>
    </Avatar>
  );
}
