import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { Image as ImageIcon } from 'lucide-react';

interface SecureImageProps {
  bucket: string;
  path: string | null | undefined;
  alt: string;
  className?: string;
  fallbackClassName?: string;
  expiresIn?: number;
}

/**
 * Extract the file path from a full storage URL or return the path as-is
 */
function extractFilePath(bucket: string, path: string): string | null {
  if (!path) return null;

  // If it's already just a path (e.g., "userId/avatar.png"), return as-is
  if (!path.startsWith('http')) {
    return path;
  }

  // Extract path from full Supabase storage URL
  // Format: https://xxx.supabase.co/storage/v1/object/public/bucket-name/path
  try {
    const url = new URL(path);
    const pathParts = url.pathname.split('/');
    
    // Find the bucket name in the path and get everything after it
    const bucketIndex = pathParts.findIndex(part => part === bucket);
    if (bucketIndex !== -1) {
      return pathParts.slice(bucketIndex + 1).join('/');
    }

    // Try alternate format: /storage/v1/object/public/bucket/path
    const storageIndex = pathParts.indexOf('storage');
    if (storageIndex !== -1 && pathParts.length > storageIndex + 4) {
      // Skip: storage, v1, object, public/sign, bucket
      const possibleBucketIndex = storageIndex + 4;
      if (pathParts[possibleBucketIndex] === bucket) {
        return pathParts.slice(possibleBucketIndex + 1).join('/');
      }
    }

    return null;
  } catch {
    return null;
  }
}

/**
 * A component that displays images from private Supabase storage buckets
 * by generating signed URLs with automatic expiration handling
 */
export function SecureImage({
  bucket,
  path,
  alt,
  className = '',
  fallbackClassName = '',
  expiresIn = 3600,
}: SecureImageProps) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!path) {
      setLoading(false);
      setError(true);
      return;
    }

    const filePath = extractFilePath(bucket, path);
    if (!filePath) {
      setLoading(false);
      setError(true);
      return;
    }

    const fetchSignedUrl = async () => {
      setLoading(true);
      setError(false);

      try {
        const { data, error: signError } = await supabase.storage
          .from(bucket)
          .createSignedUrl(filePath, expiresIn);

        if (signError) throw signError;
        setSignedUrl(data?.signedUrl || null);
      } catch (err) {
        console.error('Error creating signed URL:', err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchSignedUrl();
  }, [bucket, path, expiresIn]);

  if (loading) {
    return <Skeleton className={className || 'h-16 w-16 rounded-lg'} />;
  }

  if (error || !signedUrl) {
    return (
      <div className={`${fallbackClassName || 'h-16 w-16 rounded-lg bg-muted'} flex items-center justify-center`}>
        <ImageIcon className="h-6 w-6 text-muted-foreground" />
      </div>
    );
  }

  return (
    <img
      src={signedUrl}
      alt={alt}
      className={className}
      onError={() => setError(true)}
    />
  );
}
