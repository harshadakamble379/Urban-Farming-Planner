import { useState, useMemo, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { 
  Grid3X3, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle,
  Leaf,
  Move,
  Info,
  Printer,
  Save,
  FolderOpen,
  Trash2,
  Calendar,
  Sun,
  Snowflake,
  Cloud,
  CloudRain,
  Share2,
  Copy,
  Link,
  Check
} from "lucide-react";
import { companionPlantingData } from "@/data/companionPlanting";
import { plantingCalendarData, monthNames } from "@/data/plantingCalendar";
import { useLocation } from "@/contexts/LocationContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

interface PlantedSeed {
  id: string;
  name: string;
  row: number;
  col: number;
}

interface SeedItem {
  id: string;
  name: string;
  category: string;
  image_url: string | null;
}

interface SavedLayout {
  id: string;
  name: string;
  planted_seeds: PlantedSeed[];
  grid_size: number;
  created_at: string;
  updated_at: string;
  share_token: string | null;
  is_public: boolean;
}

interface GardenPlannerProps {
  seeds: SeedItem[];
}

const GRID_SIZE = 6;

const getPlantColor = (name: string): string => {
  const colors: Record<string, string> = {
    tomato: "bg-red-500",
    chili: "bg-orange-600",
    spinach: "bg-green-600",
    coriander: "bg-emerald-500",
    sunflower: "bg-yellow-500",
    marigold: "bg-amber-500",
    cucumber: "bg-green-400",
    brinjal: "bg-purple-600",
    mint: "bg-teal-500",
    basil: "bg-green-700",
    rose: "bg-pink-500",
    lavender: "bg-violet-400",
    zinnia: "bg-rose-500",
    strawberry: "bg-red-400",
    watermelon: "bg-green-500",
    lemon: "bg-yellow-400",
    oregano: "bg-lime-600",
    rosemary: "bg-cyan-600",
    carrot: "bg-orange-500",
    okra: "bg-green-600",
    jasmine: "bg-white border border-gray-300",
    orchid: "bg-fuchsia-400",
    gerbera: "bg-pink-400",
    peace: "bg-gray-100 border border-gray-300",
    areca: "bg-green-500",
    snake: "bg-emerald-700",
    money: "bg-lime-500",
    aloe: "bg-teal-400",
    spider: "bg-green-300",
    boston: "bg-green-600",
    rubber: "bg-green-800",
  };

  const lowerName = name.toLowerCase();
  for (const [key, value] of Object.entries(colors)) {
    if (lowerName.includes(key)) return value;
  }
  return "bg-primary";
};

const getPlantNameKey = (name: string): string => {
  return name.toLowerCase().replace(/ seeds?/gi, "").trim();
};

const getSeasonIcon = (month: number) => {
  if (month >= 3 && month <= 5) return <Sun className="h-4 w-4 text-yellow-500" />;
  if (month >= 6 && month <= 8) return <Cloud className="h-4 w-4 text-blue-400" />;
  if (month >= 9 && month <= 11) return <CloudRain className="h-4 w-4 text-orange-400" />;
  return <Snowflake className="h-4 w-4 text-cyan-400" />;
};

const getSeasonName = (month: number) => {
  if (month >= 3 && month <= 5) return "Spring";
  if (month >= 6 && month <= 8) return "Summer";
  if (month >= 9 && month <= 11) return "Autumn";
  return "Winter";
};

export function GardenPlanner({ seeds }: GardenPlannerProps) {
  const [open, setOpen] = useState(false);
  const [plantedSeeds, setPlantedSeeds] = useState<PlantedSeed[]>([]);
  const [selectedSeed, setSelectedSeed] = useState<SeedItem | null>(null);
  const [draggedSeed, setDraggedSeed] = useState<PlantedSeed | null>(null);
  const [savedLayouts, setSavedLayouts] = useState<SavedLayout[]>([]);
  const [layoutName, setLayoutName] = useState("");
  const [selectedLayoutId, setSelectedLayoutId] = useState<string | null>(null);
  const [loadingLayouts, setLoadingLayouts] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);
  
  const { city, climateZone, currentTemperature } = useLocation();
  const currentMonth = new Date().getMonth() + 1;

  // Load saved layouts
  useEffect(() => {
    if (open) {
      loadSavedLayouts();
    }
  }, [open]);

  const loadSavedLayouts = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setLoadingLayouts(true);
    const { data, error } = await supabase
      .from("garden_layouts")
      .select("*")
      .eq("user_id", user.id)
      .order("updated_at", { ascending: false });

    if (error) {
      console.error("Error loading layouts:", error);
    } else {
      setSavedLayouts((data || []).map((layout: any) => ({
        ...layout,
        planted_seeds: layout.planted_seeds as PlantedSeed[],
      })));
    }
    setLoadingLayouts(false);
  };

  // Get seasonal recommendations
  const seasonalRecommendations = useMemo(() => {
    const currentMonthSeeds = plantingCalendarData.filter(p => 
      p.optimalMonths.includes(currentMonth)
    );
    
    const nextMonth = currentMonth === 12 ? 1 : currentMonth + 1;
    const upcomingSeeds = plantingCalendarData.filter(p => 
      p.optimalMonths.includes(nextMonth) && !p.optimalMonths.includes(currentMonth)
    );

    return { currentMonthSeeds, upcomingSeeds };
  }, [currentMonth]);

  // Calculate companion planting analysis
  const companionAnalysis = useMemo(() => {
    const goodPairs: Array<{ plant1: string; plant2: string }> = [];
    const badPairs: Array<{ plant1: string; plant2: string }> = [];

    for (let i = 0; i < plantedSeeds.length; i++) {
      for (let j = i + 1; j < plantedSeeds.length; j++) {
        const plant1 = plantedSeeds[i];
        const plant2 = plantedSeeds[j];
        const distance = Math.abs(plant1.row - plant2.row) + Math.abs(plant1.col - plant2.col);

        if (distance <= 2) {
          const key1 = getPlantNameKey(plant1.name);
          const key2 = getPlantNameKey(plant2.name);

          const companion1 = companionPlantingData.find(
            (c) => c.name.toLowerCase().replace(/ seeds?/gi, "").trim() === key1
          );
          const companion2 = companionPlantingData.find(
            (c) => c.name.toLowerCase().replace(/ seeds?/gi, "").trim() === key2
          );

          if (companion1) {
            if (companion1.companions.some((c) => c.toLowerCase().replace(/ seeds?/gi, "").trim() === key2)) {
              goodPairs.push({ plant1: plant1.name, plant2: plant2.name });
            }
            if (companion1.incompatible.some((c) => c.toLowerCase().replace(/ seeds?/gi, "").trim() === key2)) {
              badPairs.push({ plant1: plant1.name, plant2: plant2.name });
            }
          }

          if (companion2) {
            if (companion2.companions.some((c) => c.toLowerCase().replace(/ seeds?/gi, "").trim() === key1)) {
              if (!goodPairs.find((p) => p.plant1 === plant1.name && p.plant2 === plant2.name)) {
                goodPairs.push({ plant1: plant1.name, plant2: plant2.name });
              }
            }
            if (companion2.incompatible.some((c) => c.toLowerCase().replace(/ seeds?/gi, "").trim() === key1)) {
              if (!badPairs.find((p) => p.plant1 === plant1.name && p.plant2 === plant2.name)) {
                badPairs.push({ plant1: plant1.name, plant2: plant2.name });
              }
            }
          }
        }
      }
    }

    const score = plantedSeeds.length > 0
      ? Math.max(0, Math.min(100, 50 + goodPairs.length * 15 - badPairs.length * 20))
      : 0;

    return { goodPairs, badPairs, score };
  }, [plantedSeeds]);

  const handleCellClick = (row: number, col: number) => {
    if (!selectedSeed) return;

    const existingPlant = plantedSeeds.find((p) => p.row === row && p.col === col);
    if (existingPlant) return;

    setPlantedSeeds([
      ...plantedSeeds,
      {
        id: `${selectedSeed.id}-${Date.now()}`,
        name: selectedSeed.name,
        row,
        col,
      },
    ]);
  };

  const handleRemovePlant = (id: string) => {
    setPlantedSeeds(plantedSeeds.filter((p) => p.id !== id));
  };

  const handleDragStart = (e: React.DragEvent, plant: PlantedSeed) => {
    setDraggedSeed(plant);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, row: number, col: number) => {
    e.preventDefault();
    if (!draggedSeed) return;

    const existingPlant = plantedSeeds.find((p) => p.row === row && p.col === col);
    if (existingPlant && existingPlant.id !== draggedSeed.id) return;

    setPlantedSeeds(
      plantedSeeds.map((p) =>
        p.id === draggedSeed.id ? { ...p, row, col } : p
      )
    );
    setDraggedSeed(null);
  };

  const handleClearAll = () => {
    setPlantedSeeds([]);
    setSelectedSeed(null);
    setSelectedLayoutId(null);
    setLayoutName("");
  };

  const handleSaveLayout = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please login to save layouts");
      return;
    }

    if (!layoutName.trim()) {
      toast.error("Please enter a layout name");
      return;
    }

    if (plantedSeeds.length === 0) {
      toast.error("Please add some plants to the layout");
      return;
    }

    if (selectedLayoutId) {
      // Update existing layout
      const { error } = await supabase
        .from("garden_layouts")
        .update({
          name: layoutName,
          planted_seeds: JSON.parse(JSON.stringify(plantedSeeds)),
          grid_size: GRID_SIZE,
        })
        .eq("id", selectedLayoutId);

      if (error) {
        toast.error("Failed to update layout");
        console.error(error);
      } else {
        toast.success("Layout updated successfully");
        loadSavedLayouts();
      }
    } else {
      // Create new layout
      const { error } = await supabase
        .from("garden_layouts")
        .insert([{
          user_id: user.id,
          name: layoutName,
          planted_seeds: JSON.parse(JSON.stringify(plantedSeeds)),
          grid_size: GRID_SIZE,
        }]);

      if (error) {
        toast.error("Failed to save layout");
        console.error(error);
      } else {
        toast.success("Layout saved successfully");
        loadSavedLayouts();
      }
    }
  };

  const handleLoadLayout = (layout: SavedLayout) => {
    setPlantedSeeds(layout.planted_seeds);
    setLayoutName(layout.name);
    setSelectedLayoutId(layout.id);
    toast.success(`Loaded "${layout.name}"`);
  };

  const handleDeleteLayout = async (layoutId: string) => {
    const { error } = await supabase
      .from("garden_layouts")
      .delete()
      .eq("id", layoutId);

    if (error) {
      toast.error("Failed to delete layout");
      console.error(error);
    } else {
      toast.success("Layout deleted");
      if (selectedLayoutId === layoutId) {
        setSelectedLayoutId(null);
        setLayoutName("");
      }
      loadSavedLayouts();
    }
  };

  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  const generateShareToken = () => {
    return crypto.randomUUID();
  };

  const handleToggleShare = async (layoutId: string, currentlyPublic: boolean) => {
    const layout = savedLayouts.find(l => l.id === layoutId);
    if (!layout) return;

    if (currentlyPublic) {
      // Make private
      const { error } = await supabase
        .from("garden_layouts")
        .update({ is_public: false, share_token: null })
        .eq("id", layoutId);

      if (error) {
        toast.error("Failed to update sharing settings");
      } else {
        toast.success("Layout is now private");
        loadSavedLayouts();
      }
    } else {
      // Make public with share token
      const shareToken = layout.share_token || generateShareToken();
      const { error } = await supabase
        .from("garden_layouts")
        .update({ is_public: true, share_token: shareToken })
        .eq("id", layoutId);

      if (error) {
        toast.error("Failed to enable sharing");
      } else {
        toast.success("Layout is now shareable!");
        loadSavedLayouts();
      }
    }
  };

  const copyShareLink = (layout: SavedLayout) => {
    if (!layout.share_token) return;
    const shareUrl = `${window.location.origin}/shared-garden/${layout.share_token}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(layout.id);
    toast.success("Share link copied to clipboard!");
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const handlePrint = () => {
    const printContent = gridRef.current;
    if (!printContent) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      toast.error("Please allow popups to print");
      return;
    }

    const plantLegend = [...new Set(plantedSeeds.map(p => p.name))].map(name => {
      const colorClass = getPlantColor(name);
      const bgColor = colorClass.includes("bg-red") ? "#ef4444" :
                      colorClass.includes("bg-orange") ? "#f97316" :
                      colorClass.includes("bg-green") ? "#22c55e" :
                      colorClass.includes("bg-emerald") ? "#10b981" :
                      colorClass.includes("bg-yellow") ? "#eab308" :
                      colorClass.includes("bg-amber") ? "#f59e0b" :
                      colorClass.includes("bg-purple") ? "#9333ea" :
                      colorClass.includes("bg-teal") ? "#14b8a6" :
                      colorClass.includes("bg-pink") ? "#ec4899" :
                      colorClass.includes("bg-violet") ? "#8b5cf6" :
                      colorClass.includes("bg-rose") ? "#f43f5e" :
                      colorClass.includes("bg-lime") ? "#84cc16" :
                      colorClass.includes("bg-cyan") ? "#06b6d4" :
                      colorClass.includes("bg-fuchsia") ? "#d946ef" :
                      "#22c55e";
      return `<div style="display: flex; align-items: center; gap: 8px; margin: 4px 0;">
        <div style="width: 20px; height: 20px; border-radius: 50%; background: ${bgColor};"></div>
        <span>${escapeHtml(name.replace(" Seeds", ""))}</span>
      </div>`;
    }).join("");

    // HTML escape function to prevent XSS
    const escapeHtml = (str: string): string => str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');

    const safeLayoutName = escapeHtml(layoutName || "My Garden");
    const safeCity = escapeHtml(city || "Unknown");

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Garden Layout - ${safeLayoutName}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #166534; margin-bottom: 10px; }
            .info { color: #666; margin-bottom: 20px; }
            .grid { 
              display: grid; 
              grid-template-columns: repeat(${GRID_SIZE}, 60px);
              gap: 4px;
              margin: 20px 0;
            }
            .cell {
              width: 60px;
              height: 60px;
              border: 2px dashed #ccc;
              display: flex;
              align-items: center;
              justify-content: center;
              border-radius: 8px;
            }
            .cell.filled {
              border: 2px solid #22c55e;
              background: #f0fdf4;
            }
            .plant {
              width: 40px;
              height: 40px;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              color: white;
              font-size: 12px;
            }
            .legend { margin-top: 20px; }
            .legend h3 { margin-bottom: 10px; }
            .analysis { margin-top: 20px; padding: 15px; background: #f9fafb; border-radius: 8px; }
            .good { color: #166534; }
            .bad { color: #dc2626; }
            @media print {
              body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
            }
          </style>
        </head>
        <body>
          <h1>🌱 ${safeLayoutName}</h1>
          <div class="info">
            <p><strong>Location:</strong> ${safeCity} | <strong>Season:</strong> ${escapeHtml(getSeasonName(currentMonth))} (${escapeHtml(monthNames[currentMonth - 1])})</p>
            <p><strong>Grid Size:</strong> ${GRID_SIZE}x${GRID_SIZE} | <strong>Plants:</strong> ${plantedSeeds.length}</p>
          </div>
          <div class="grid">
            ${Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, index) => {
              const row = Math.floor(index / GRID_SIZE);
              const col = index % GRID_SIZE;
              const plant = plantedSeeds.find(p => p.row === row && p.col === col);
              const colorClass = plant ? getPlantColor(plant.name) : "";
              const bgColor = colorClass.includes("bg-red") ? "#ef4444" :
                              colorClass.includes("bg-orange") ? "#f97316" :
                              colorClass.includes("bg-green") ? "#22c55e" :
                              colorClass.includes("bg-emerald") ? "#10b981" :
                              colorClass.includes("bg-yellow") ? "#eab308" :
                              colorClass.includes("bg-amber") ? "#f59e0b" :
                              colorClass.includes("bg-purple") ? "#9333ea" :
                              colorClass.includes("bg-teal") ? "#14b8a6" :
                              colorClass.includes("bg-pink") ? "#ec4899" :
                              colorClass.includes("bg-violet") ? "#8b5cf6" :
                              colorClass.includes("bg-rose") ? "#f43f5e" :
                              colorClass.includes("bg-lime") ? "#84cc16" :
                              colorClass.includes("bg-cyan") ? "#06b6d4" :
                              colorClass.includes("bg-fuchsia") ? "#d946ef" :
                              "#22c55e";
              return `<div class="cell ${plant ? "filled" : ""}">
                ${plant ? `<div class="plant" style="background: ${bgColor};">🌿</div>` : ""}
              </div>`;
            }).join("")}
          </div>
          <div class="legend">
            <h3>Plant Legend</h3>
            ${plantLegend}
          </div>
          ${companionAnalysis.goodPairs.length > 0 || companionAnalysis.badPairs.length > 0 ? `
            <div class="analysis">
              <h3>Companion Analysis (Score: ${companionAnalysis.score}%)</h3>
              ${companionAnalysis.goodPairs.length > 0 ? `
                <p class="good"><strong>Good Companions:</strong> ${companionAnalysis.goodPairs.map(p => `${escapeHtml(p.plant1.replace(" Seeds", ""))} + ${escapeHtml(p.plant2.replace(" Seeds", ""))}`).join(", ")}</p>
              ` : ""}
              ${companionAnalysis.badPairs.length > 0 ? `
                <p class="bad"><strong>Incompatible:</strong> ${companionAnalysis.badPairs.map(p => `${escapeHtml(p.plant1.replace(" Seeds", ""))} ↔ ${escapeHtml(p.plant2.replace(" Seeds", ""))}`).join(", ")}</p>
              ` : ""}
            </div>
          ` : ""}
          <p style="margin-top: 30px; color: #999; font-size: 12px;">Generated on ${new Date().toLocaleDateString()}</p>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const getPlantAtCell = (row: number, col: number) => {
    return plantedSeeds.find((p) => p.row === row && p.col === col);
  };

  const seedItems = seeds.filter(
    (s) => s.category.toLowerCase().includes("seed")
  );

  // Filter seeds by seasonal recommendations
  const seasonalSeedItems = seedItems.filter(seed => {
    const plantInfo = plantingCalendarData.find(p => p.seedName === seed.name);
    return plantInfo?.optimalMonths.includes(currentMonth);
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Grid3X3 className="h-4 w-4" />
          Garden Planner
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Leaf className="h-5 w-5 text-primary" />
              Garden Layout Planner
            </span>
            <div className="flex items-center gap-2 text-sm font-normal">
              {getSeasonIcon(currentMonth)}
              <span className="text-muted-foreground">{city} • {getSeasonName(currentMonth)}</span>
            </div>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="planner" className="mt-2">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="planner">Planner</TabsTrigger>
            <TabsTrigger value="seasonal">Seasonal Tips</TabsTrigger>
            <TabsTrigger value="saved">Saved Layouts</TabsTrigger>
          </TabsList>

          <TabsContent value="planner" className="mt-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Seed Palette */}
              <Card className="lg:col-span-1">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center justify-between">
                    Seeds for {monthNames[currentMonth - 1]}
                    <Badge variant="secondary">{seasonalSeedItems.length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[180px] lg:h-[280px]">
                    <div className="grid grid-cols-2 gap-2">
                      {seasonalSeedItems.map((seed) => (
                        <TooltipProvider key={seed.id}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant={selectedSeed?.id === seed.id ? "default" : "outline"}
                                size="sm"
                                className="justify-start text-xs h-auto py-2 px-2"
                                onClick={() => setSelectedSeed(seed)}
                              >
                                <div
                                  className={`w-3 h-3 rounded-full mr-2 flex-shrink-0 ${getPlantColor(seed.name)}`}
                                />
                                <span className="truncate">{seed.name.replace(" Seeds", "")}</span>
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Optimal for planting now</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      ))}
                    </div>
                    {seasonalSeedItems.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No optimal seeds for this month
                      </p>
                    )}
                  </ScrollArea>
                  
                  {/* Save/Load Controls */}
                  <div className="mt-3 space-y-2">
                    <Input
                      placeholder="Layout name..."
                      value={layoutName}
                      onChange={(e) => setLayoutName(e.target.value)}
                      className="h-8 text-xs"
                    />
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleSaveLayout}
                        className="flex-1"
                      >
                        <Save className="h-3 w-3 mr-1" />
                        Save
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handlePrint}
                        className="flex-1"
                        disabled={plantedSeeds.length === 0}
                      >
                        <Printer className="h-3 w-3 mr-1" />
                        Print
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClearAll}
                      className="w-full"
                    >
                      <RotateCcw className="h-3 w-3 mr-1" />
                      Clear All
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Garden Grid */}
              <Card className="lg:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Move className="h-4 w-4" />
                      Garden Grid ({GRID_SIZE}x{GRID_SIZE})
                    </span>
                    {selectedSeed && (
                      <Badge variant="outline" className="text-xs">
                        Placing: {selectedSeed.name.replace(" Seeds", "")}
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div
                    ref={gridRef}
                    className="grid gap-1 bg-muted/30 p-2 rounded-lg"
                    style={{
                      gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
                    }}
                  >
                    {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, index) => {
                      const row = Math.floor(index / GRID_SIZE);
                      const col = index % GRID_SIZE;
                      const plant = getPlantAtCell(row, col);

                      return (
                        <div
                          key={`${row}-${col}`}
                          className={`
                            aspect-square border-2 border-dashed rounded-md flex items-center justify-center
                            transition-all duration-200 cursor-pointer
                            ${plant ? "border-solid border-primary/50 bg-primary/10" : "border-muted-foreground/30 hover:border-primary/50 hover:bg-primary/5"}
                            ${selectedSeed && !plant ? "ring-2 ring-primary/20" : ""}
                          `}
                          onClick={() => handleCellClick(row, col)}
                          onDragOver={handleDragOver}
                          onDrop={(e) => handleDrop(e, row, col)}
                        >
                          {plant && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <div
                                    draggable
                                    onDragStart={(e) => handleDragStart(e, plant)}
                                    className={`
                                      w-8 h-8 rounded-full flex items-center justify-center
                                      cursor-move shadow-sm
                                      ${getPlantColor(plant.name)}
                                    `}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleRemovePlant(plant.id);
                                    }}
                                  >
                                    <Leaf className="h-4 w-4 text-white" />
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{plant.name.replace(" Seeds", "")}</p>
                                  <p className="text-xs text-muted-foreground">
                                    Click to remove, drag to move
                                  </p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Companion Analysis */}
                  {plantedSeeds.length > 0 && (
                    <div className="mt-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Compatibility Score</span>
                        <Badge
                          variant={
                            companionAnalysis.score >= 70
                              ? "default"
                              : companionAnalysis.score >= 40
                              ? "secondary"
                              : "destructive"
                          }
                          className={
                            companionAnalysis.score >= 70
                              ? "bg-green-600"
                              : companionAnalysis.score >= 40
                              ? "bg-amber-500"
                              : ""
                          }
                        >
                          {companionAnalysis.score}%
                        </Badge>
                      </div>

                      {companionAnalysis.badPairs.length > 0 && (
                        <div className="p-2 bg-destructive/10 rounded-md">
                          <div className="flex items-center gap-2 text-destructive text-sm font-medium mb-1">
                            <AlertTriangle className="h-4 w-4" />
                            Incompatible Pairings
                          </div>
                          <ul className="text-xs text-muted-foreground space-y-1">
                            {companionAnalysis.badPairs.map((pair, i) => (
                              <li key={i}>
                                {pair.plant1.replace(" Seeds", "")} ↔{" "}
                                {pair.plant2.replace(" Seeds", "")}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {companionAnalysis.goodPairs.length > 0 && (
                        <div className="p-2 bg-green-500/10 rounded-md">
                          <div className="flex items-center gap-2 text-green-600 text-sm font-medium mb-1">
                            <CheckCircle2 className="h-4 w-4" />
                            Good Companions
                          </div>
                          <ul className="text-xs text-muted-foreground space-y-1">
                            {companionAnalysis.goodPairs.map((pair, i) => (
                              <li key={i}>
                                {pair.plant1.replace(" Seeds", "")} +{" "}
                                {pair.plant2.replace(" Seeds", "")}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="seasonal" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-primary" />
                    Plant Now ({monthNames[currentMonth - 1]})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[200px]">
                    <div className="space-y-2">
                      {seasonalRecommendations.currentMonthSeeds.map((plant) => (
                        <div
                          key={plant.seedName}
                          className="p-2 rounded-md bg-green-500/10 border border-green-500/20"
                        >
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${getPlantColor(plant.seedName)}`} />
                            <span className="text-sm font-medium">
                              {plant.seedName.replace(" Seeds", "")}
                            </span>
                            <Badge variant="outline" className="text-xs ml-auto">
                              {plant.sowingType}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{plant.notes}</p>
                        </div>
                      ))}
                      {seasonalRecommendations.currentMonthSeeds.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          No optimal seeds for this month in your location
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-amber-500" />
                    Coming Up Next Month
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[200px]">
                    <div className="space-y-2">
                      {seasonalRecommendations.upcomingSeeds.map((plant) => (
                        <div
                          key={plant.seedName}
                          className="p-2 rounded-md bg-amber-500/10 border border-amber-500/20"
                        >
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${getPlantColor(plant.seedName)}`} />
                            <span className="text-sm font-medium">
                              {plant.seedName.replace(" Seeds", "")}
                            </span>
                            <Badge variant="outline" className="text-xs ml-auto">
                              {plant.sowingType}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{plant.notes}</p>
                        </div>
                      ))}
                      {seasonalRecommendations.upcomingSeeds.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          No new seeds recommended for next month
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Info className="h-4 w-4 text-blue-500" />
                    Location-Based Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-3 rounded-md bg-blue-500/10 border border-blue-500/20">
                    <p className="text-sm">
                      <strong>Your Location:</strong> {city} ({climateZone})
                    </p>
                    <p className="text-sm mt-1">
                      <strong>Current Temperature:</strong> {currentTemperature}°C
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Based on your location, the seed recommendations above are filtered for optimal growing conditions.
                      Indoor plants can be grown year-round in your climate.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="saved" className="mt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <FolderOpen className="h-4 w-4" />
                  Your Saved Layouts ({savedLayouts.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingLayouts ? (
                  <p className="text-sm text-muted-foreground text-center py-8">Loading...</p>
                ) : savedLayouts.length === 0 ? (
                  <div className="text-center py-8">
                    <FolderOpen className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">No saved layouts yet</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Create a layout and save it to access it later
                    </p>
                  </div>
                ) : (
                  <ScrollArea className="h-[300px]">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {savedLayouts.map((layout) => (
                        <div
                          key={layout.id}
                          className={`p-3 rounded-md border transition-colors ${
                            selectedLayoutId === layout.id ? "border-primary bg-primary/5" : "border-border"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span 
                              className="font-medium text-sm cursor-pointer hover:text-primary"
                              onClick={() => handleLoadLayout(layout)}
                            >
                              {layout.name}
                            </span>
                            <div className="flex items-center gap-1">
                              {layout.is_public && (
                                <Badge variant="secondary" className="text-xs">
                                  <Share2 className="h-2 w-2 mr-1" />
                                  Shared
                                </Badge>
                              )}
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteLayout(layout.id);
                                }}
                              >
                                <Trash2 className="h-3 w-3 text-destructive" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {layout.planted_seeds.length} plants
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {new Date(layout.updated_at).toLocaleDateString()}
                            </span>
                          </div>
                          
                          {/* Sharing Controls */}
                          <div className="mt-3 pt-3 border-t border-border/50 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Switch
                                  id={`share-${layout.id}`}
                                  checked={layout.is_public}
                                  onCheckedChange={() => handleToggleShare(layout.id, layout.is_public)}
                                />
                                <Label htmlFor={`share-${layout.id}`} className="text-xs cursor-pointer">
                                  Public sharing
                                </Label>
                              </div>
                              {layout.is_public && layout.share_token && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="h-6 text-xs gap-1"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    copyShareLink(layout);
                                  }}
                                >
                                  {copiedLink === layout.id ? (
                                    <>
                                      <Check className="h-3 w-3" />
                                      Copied!
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="h-3 w-3" />
                                      Copy Link
                                    </>
                                  )}
                                </Button>
                              )}
                            </div>
                            {layout.is_public && layout.share_token && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground bg-muted/50 rounded px-2 py-1">
                                <Link className="h-3 w-3" />
                                <span className="truncate">
                                  {window.location.origin}/shared-garden/{layout.share_token}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
