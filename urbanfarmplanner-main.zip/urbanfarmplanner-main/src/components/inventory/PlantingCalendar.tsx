import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Thermometer, Sprout, Info } from "lucide-react";
import {
  getPlantingInfo,
  getSeedsForMonth,
  monthNames,
  PlantingWindow,
} from "@/data/plantingCalendar";

interface PlantingCalendarProps {
  seedName?: string;
  category?: string;
}

export function PlantingCalendar({ seedName, category }: PlantingCalendarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [seedsForMonth, setSeedsForMonth] = useState<PlantingWindow[]>([]);

  const specificSeedInfo = seedName ? getPlantingInfo(seedName) : undefined;

  useEffect(() => {
    setSeedsForMonth(getSeedsForMonth(selectedMonth));
  }, [selectedMonth]);

  // Only show for seeds category when seedName is provided
  if (seedName && category && !category.toLowerCase().includes('seed')) {
    return null;
  }

  const getSowingBadge = (sowingType: string) => {
    switch (sowingType) {
      case 'direct':
        return <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/30">Direct Sow</Badge>;
      case 'indoor':
        return <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/30">Start Indoors</Badge>;
      case 'both':
        return <Badge variant="outline" className="bg-purple-500/10 text-purple-600 border-purple-500/30">Direct or Indoor</Badge>;
      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5">
          <Calendar className="h-4 w-4" />
          {seedName ? "Planting Time" : "Planting Calendar"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            {seedName ? `${seedName} - Planting Calendar` : "Seed Planting Calendar"}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue={seedName ? "specific" : "monthly"} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            {seedName && specificSeedInfo && (
              <TabsTrigger value="specific">This Seed</TabsTrigger>
            )}
            <TabsTrigger value="monthly">By Month</TabsTrigger>
            {!seedName && <TabsTrigger value="all">All Seeds</TabsTrigger>}
          </TabsList>

          {/* Specific Seed Info */}
          {seedName && specificSeedInfo && (
            <TabsContent value="specific" className="mt-4">
              <div className="space-y-4">
                {/* Month Grid */}
                <div>
                  <h4 className="text-sm font-medium mb-3">Optimal Planting Months</h4>
                  <div className="grid grid-cols-6 gap-2">
                    {monthNames.map((month, index) => {
                      const isOptimal = specificSeedInfo.optimalMonths.includes(index + 1);
                      const isCurrent = new Date().getMonth() === index;
                      return (
                        <div
                          key={month}
                          className={`p-2 rounded-lg text-center text-sm transition-colors ${
                            isOptimal
                              ? "bg-green-500/20 text-green-600 font-medium"
                              : "bg-muted/50 text-muted-foreground"
                          } ${isCurrent ? "ring-2 ring-primary" : ""}`}
                        >
                          {month}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Details */}
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="rounded-lg bg-muted/50 p-4 space-y-2">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Sprout className="h-4 w-4" />
                      <span className="text-xs font-medium">Sowing Method</span>
                    </div>
                    {getSowingBadge(specificSeedInfo.sowingType)}
                  </div>
                  <div className="rounded-lg bg-muted/50 p-4 space-y-2">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Thermometer className="h-4 w-4" />
                      <span className="text-xs font-medium">Germination Temp</span>
                    </div>
                    <p className="text-sm font-medium">
                      {specificSeedInfo.germinationTemp.min}°C - {specificSeedInfo.germinationTemp.max}°C
                    </p>
                  </div>
                </div>

                {/* Notes */}
                <div className="rounded-lg bg-amber-500/10 p-4">
                  <div className="flex items-start gap-2">
                    <Info className="h-4 w-4 text-amber-600 mt-0.5" />
                    <p className="text-sm text-amber-700">{specificSeedInfo.notes}</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          )}

          {/* Monthly View */}
          <TabsContent value="monthly" className="mt-4">
            <div className="space-y-4">
              {/* Month Selector */}
              <div className="grid grid-cols-6 gap-2">
                {monthNames.map((month, index) => {
                  const isCurrent = new Date().getMonth() === index;
                  const isSelected = selectedMonth === index + 1;
                  return (
                    <Button
                      key={month}
                      variant={isSelected ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedMonth(index + 1)}
                      className={isCurrent && !isSelected ? "ring-2 ring-primary" : ""}
                    >
                      {month}
                    </Button>
                  );
                })}
              </div>

              {/* Seeds for Selected Month */}
              <ScrollArea className="h-[300px]">
                <div className="space-y-3">
                  <h4 className="font-medium sticky top-0 bg-background py-2">
                    Plant in {monthNames[selectedMonth - 1]} ({seedsForMonth.length} seeds)
                  </h4>
                  {seedsForMonth.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No seeds recommended for this month.</p>
                  ) : (
                    seedsForMonth.map((seed) => (
                      <div
                        key={seed.seedName}
                        className="rounded-lg border p-3 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-sm">{seed.seedName.replace(' Seeds', '')}</span>
                          {getSowingBadge(seed.sowingType)}
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Thermometer className="h-3 w-3" />
                            {seed.germinationTemp.min}-{seed.germinationTemp.max}°C
                          </span>
                          <Badge variant="secondary" className="text-xs">
                            {seed.category}
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          {/* All Seeds View */}
          {!seedName && (
            <TabsContent value="all" className="mt-4">
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {["Vegetable Seeds", "Herb Seeds", "Flower Seeds", "Fruit Seeds"].map((cat) => (
                    <div key={cat} className="space-y-2">
                      <h4 className="font-medium text-sm sticky top-0 bg-background py-1">
                        {cat}
                      </h4>
                      {getSeedsForMonth(new Date().getMonth() + 1)
                        .filter((s) => s.category === cat)
                        .map((seed) => (
                          <div
                            key={seed.seedName}
                            className="rounded-lg border p-3 flex items-center justify-between"
                          >
                            <span className="text-sm">{seed.seedName.replace(' Seeds', '')}</span>
                            <div className="flex items-center gap-2">
                              {getSowingBadge(seed.sowingType)}
                            </div>
                          </div>
                        ))}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>
          )}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
