import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ShoppingCart, 
  Plus, 
  Minus, 
  Star,
  Package,
  Wrench,
  Beaker,
  Shovel,
  Heart,
  Leaf
} from "lucide-react";
import { toast } from "sonner";
import { ProductReviews } from "./ProductReviews";
import { SeedGrowingGuide } from "./SeedGrowingGuide";
import { CompanionPlantingGuide } from "./CompanionPlantingGuide";
import { PlantingCalendar } from "./PlantingCalendar";

interface Review {
  id: string;
  rating: number;
  title: string | null;
  comment: string | null;
  created_at: string;
  user_id: string;
}

interface ProductCardProps {
  id: string;
  name: string;
  description: string | null;
  category: string;
  price: number;
  quantity: number;
  unit: string | null;
  image_url: string | null;
  condition: string | null;
  is_available: boolean;
  isWishlisted?: boolean;
  reviews?: Review[];
  averageRating?: number;
  onAddToCart: (id: string, qty: number) => void;
  onToggleWishlist?: (id: string) => void;
  onReviewAdded?: () => void;
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "Tools":
      return Wrench;
    case "Materials":
      return Package;
    case "Equipment":
      return Beaker;
    case "Vegetable Seeds":
    case "Flower Seeds":
    case "Herb Seeds":
    case "Fruit Seeds":
    case "Seeds":
    case "Indoor Plants":
      return Leaf;
    default:
      return Shovel;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case "Tools":
      return "bg-amber-500/10 text-amber-600";
    case "Materials":
      return "bg-emerald-500/10 text-emerald-600";
    case "Equipment":
      return "bg-blue-500/10 text-blue-600";
    case "Vegetable Seeds":
      return "bg-green-500/10 text-green-600";
    case "Flower Seeds":
      return "bg-pink-500/10 text-pink-600";
    case "Herb Seeds":
      return "bg-teal-500/10 text-teal-600";
    case "Fruit Seeds":
      return "bg-orange-500/10 text-orange-600";
    case "Seeds":
      return "bg-lime-500/10 text-lime-600";
    case "Indoor Plants":
      return "bg-cyan-500/10 text-cyan-600";
    default:
      return "bg-primary/10 text-primary";
  }
};

export function ProductCard({
  id,
  name,
  description,
  category,
  price,
  quantity,
  unit,
  image_url,
  condition,
  is_available,
  isWishlisted = false,
  reviews = [],
  averageRating = 0,
  onAddToCart,
  onToggleWishlist,
  onReviewAdded,
}: ProductCardProps) {
  const [selectedQty, setSelectedQty] = useState(1);
  const Icon = getCategoryIcon(category);

  const handleAddToCart = () => {
    if (selectedQty > quantity) {
      toast.error("Not enough stock available");
      return;
    }
    onAddToCart(id, selectedQty);
    toast.success(`Added ${selectedQty} ${name} to cart`);
  };

  const inStock = quantity > 0 && is_available;
  const lowStock = quantity > 0 && quantity <= 5;
  const displayRating = averageRating > 0 ? averageRating.toFixed(1) : "New";

  return (
    <Card className="group overflow-hidden border-border/50 hover:border-primary/30 transition-all duration-300 hover:shadow-lg">
      <div className="relative aspect-square bg-muted/30 flex items-center justify-center overflow-hidden">
        {image_url ? (
          <img
            src={image_url}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <Icon className="h-12 w-12" />
            <span className="text-xs">{category}</span>
          </div>
        )}
        
        {/* Wishlist Button */}
        {onToggleWishlist && (
          <button
            onClick={() => onToggleWishlist(id)}
            className="absolute top-3 right-3 p-2 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background transition-colors"
          >
            <Heart
              className={`h-4 w-4 ${isWishlisted ? "fill-red-500 text-red-500" : "text-muted-foreground"}`}
            />
          </button>
        )}

        {/* Stock Badge */}
        {!inStock && (
          <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
            <Badge variant="destructive">Out of Stock</Badge>
          </div>
        )}
        
        {lowStock && inStock && (
          <Badge className="absolute top-3 left-3 bg-amber-500">
            Only {quantity} left
          </Badge>
        )}
      </div>

      <CardContent className="p-4 space-y-3">
        {/* Category & Rating */}
        <div className="flex items-center justify-between">
          <Badge variant="secondary" className={getCategoryColor(category)}>
            {category}
          </Badge>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className={`h-3 w-3 ${averageRating > 0 ? "fill-amber-400 text-amber-400" : "text-muted-foreground/50"}`} />
            <span>{displayRating}</span>
            {reviews.length > 0 && (
              <span className="text-muted-foreground/70">({reviews.length})</span>
            )}
          </div>
        </div>

        {/* Name & Description */}
        <div>
          <h3 className="font-semibold text-foreground line-clamp-1">{name}</h3>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
            {description || `High quality ${category.toLowerCase()} for your urban farm`}
          </p>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-2">
          <span className="text-xl font-bold text-foreground">₹{price.toFixed(2)}</span>
          {condition && condition !== "Good" && (
            <Badge variant="outline" className="text-xs">
              {condition}
            </Badge>
          )}
        </div>

        {/* Reviews & Seed Guides */}
        <div className="flex flex-wrap gap-2">
          {onReviewAdded && (
            <ProductReviews
              itemId={id}
              itemName={name}
              reviews={reviews}
              averageRating={averageRating}
              onReviewAdded={onReviewAdded}
            />
          )}
          <SeedGrowingGuide seedName={name} category={category} />
          <CompanionPlantingGuide seedName={name} category={category} />
          <PlantingCalendar seedName={name} category={category} />
        </div>

        {/* Quantity Selector */}
        {inStock && (
          <div className="flex items-center gap-3">
            <div className="flex items-center border rounded-lg">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setSelectedQty(Math.max(1, selectedQty - 1))}
                disabled={selectedQty <= 1}
              >
                <Minus className="h-3 w-3" />
              </Button>
              <span className="w-8 text-center text-sm font-medium">{selectedQty}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setSelectedQty(Math.min(quantity, selectedQty + 1))}
                disabled={selectedQty >= quantity}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <span className="text-xs text-muted-foreground">
              {quantity} {unit || "pcs"} available
            </span>
          </div>
        )}

        {/* Add to Cart Button */}
        <Button
          className="w-full gap-2 hover:bg-accent hover:text-accent-foreground transition-colors"
          onClick={handleAddToCart}
          disabled={!inStock}
        >
          <ShoppingCart className="h-4 w-4" />
          {inStock ? "Add to Cart" : "Out of Stock"}
        </Button>
      </CardContent>
    </Card>
  );
}
