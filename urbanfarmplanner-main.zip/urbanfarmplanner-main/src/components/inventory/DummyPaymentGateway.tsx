import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { CreditCard, Lock, CheckCircle, Loader2 } from "lucide-react";

interface DummyPaymentGatewayProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  totalAmount: number;
  onPaymentSuccess: () => void;
}

export function DummyPaymentGateway({
  open,
  onOpenChange,
  totalAmount,
  onPaymentSuccess,
}: DummyPaymentGatewayProps) {
  const [step, setStep] = useState<"form" | "processing" | "success">("form");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [name, setName] = useState("");

  const formatCardNumber = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 16);
    return digits.replace(/(.{4})/g, "$1 ").trim();
  };

  const formatExpiry = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 4);
    if (digits.length >= 3) return digits.slice(0, 2) + "/" + digits.slice(2);
    return digits;
  };

  const handlePay = () => {
    setStep("processing");
    setTimeout(() => {
      setStep("success");
      setTimeout(() => {
        onPaymentSuccess();
        resetForm();
      }, 2000);
    }, 2500);
  };

  const resetForm = () => {
    setStep("form");
    setCardNumber("");
    setExpiry("");
    setCvv("");
    setName("");
  };

  const isFormValid = cardNumber.replace(/\s/g, "").length === 16 && expiry.length === 5 && cvv.length === 3 && name.length > 0;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (step === "form") { onOpenChange(v); resetForm(); } }}>
      <DialogContent className="sm:max-w-md">
        {step === "form" && (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                Payment Gateway
              </DialogTitle>
            </DialogHeader>

            <div className="rounded-lg bg-muted/50 p-3 text-center">
              <p className="text-sm text-muted-foreground">Amount to Pay</p>
              <p className="text-2xl font-bold text-primary">₹{totalAmount.toFixed(2)}</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="card-name">Cardholder Name</Label>
                <Input id="card-name" placeholder="John Doe" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="card-number">Card Number</Label>
                <Input id="card-number" placeholder="1234 5678 9012 3456" value={cardNumber} onChange={(e) => setCardNumber(formatCardNumber(e.target.value))} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiry">Expiry</Label>
                  <Input id="expiry" placeholder="MM/YY" value={expiry} onChange={(e) => setExpiry(formatExpiry(e.target.value))} />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input id="cvv" placeholder="123" type="password" maxLength={3} value={cvv} onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))} />
                </div>
              </div>
            </div>

            <Separator />

            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Lock className="h-3 w-3" />
              <span>This is a demo payment gateway. No real charges will be made.</span>
            </div>

            <Button className="w-full gap-2" size="lg" onClick={handlePay} disabled={!isFormValid}>
              <Lock className="h-4 w-4" />
              Pay ₹{totalAmount.toFixed(2)}
            </Button>
          </>
        )}

        {step === "processing" && (
          <div className="flex flex-col items-center justify-center py-12 space-y-4">
            <Loader2 className="h-12 w-12 text-primary animate-spin" />
            <h3 className="text-lg font-semibold">Processing Payment...</h3>
            <p className="text-sm text-muted-foreground">Please wait while we verify your payment</p>
          </div>
        )}

        {step === "success" && (
          <div className="flex flex-col items-center justify-center py-12 space-y-4">
            <CheckCircle className="h-16 w-16 text-green-500" />
            <h3 className="text-lg font-semibold text-green-600">Payment Successful!</h3>
            <p className="text-sm text-muted-foreground">Your order has been placed successfully</p>
            <p className="text-xs text-muted-foreground">Transaction ID: TXN{Date.now()}</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
