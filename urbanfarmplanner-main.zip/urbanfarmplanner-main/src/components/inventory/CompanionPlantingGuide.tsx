import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Users, ThumbsUp, ThumbsDown, Sparkles } from "lucide-react";
import { getCompanionInfo, CompanionInfo } from "@/data/companionPlanting";

interface CompanionPlantingGuideProps {
  seedName: string;
  category: string;
}

export function CompanionPlantingGuide({ seedName, category }: CompanionPlantingGuideProps) {
  const [isOpen, setIsOpen] = useState(false);
  const info = getCompanionInfo(seedName);

  // Only show for seeds category
  if (!category.toLowerCase().includes('seed')) {
    return null;
  }

  if (!info) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5">
          <Users className="h-4 w-4" />
          Companions
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Companion Planting - {info.name}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-5">
            {/* Good Companions */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <ThumbsUp className="h-4 w-4 text-green-500" />
                <h4 className="font-semibold text-green-600">Good Companions</h4>
              </div>
              <div className="flex flex-wrap gap-2">
                {info.companions.length > 0 ? (
                  info.companions.map((companion) => (
                    <Badge
                      key={companion}
                      variant="outline"
                      className="bg-green-500/10 text-green-600 border-green-500/30"
                    >
                      {companion.replace(' Seeds', '')}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No specific companions listed</p>
                )}
              </div>
            </div>

            {/* Bad Companions */}
            {info.incompatible.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <ThumbsDown className="h-4 w-4 text-red-500" />
                  <h4 className="font-semibold text-red-600">Avoid Planting With</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {info.incompatible.map((plant) => (
                    <Badge
                      key={plant}
                      variant="outline"
                      className="bg-red-500/10 text-red-600 border-red-500/30"
                    >
                      {plant.replace(' Seeds', '')}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <Separator />

            {/* Benefits */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="h-4 w-4 text-amber-500" />
                <h4 className="font-semibold">Benefits of Companion Planting</h4>
              </div>
              <ul className="space-y-2">
                {info.benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-500 mt-2 flex-shrink-0" />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
