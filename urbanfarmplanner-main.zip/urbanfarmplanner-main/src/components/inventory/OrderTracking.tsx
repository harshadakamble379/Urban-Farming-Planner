import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Package,
  Truck,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  ChevronRight,
} from "lucide-react";
import { format } from "date-fns";

interface Order {
  id: string;
  status: string;
  total_amount: number;
  created_at: string;
  tracking_number?: string | null;
  carrier?: string | null;
  estimated_delivery?: string | null;
  shipping_address?: string | null;
}

interface OrderTrackingProps {
  orders: Order[];
  onRefresh?: () => void;
}

const statusConfig: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  pending: { label: "Order Placed", color: "bg-amber-500", icon: Clock },
  confirmed: { label: "Confirmed", color: "bg-blue-500", icon: CheckCircle2 },
  processing: { label: "Processing", color: "bg-purple-500", icon: Package },
  shipped: { label: "Shipped", color: "bg-indigo-500", icon: Truck },
  out_for_delivery: { label: "Out for Delivery", color: "bg-cyan-500", icon: MapPin },
  delivered: { label: "Delivered", color: "bg-emerald-500", icon: CheckCircle2 },
  cancelled: { label: "Cancelled", color: "bg-destructive", icon: Clock },
};

const trackingSteps = ["pending", "confirmed", "processing", "shipped", "out_for_delivery", "delivered"];

export function OrderTracking({ orders, onRefresh }: OrderTrackingProps) {
  const [open, setOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const getStatusIndex = (status: string) => {
    return trackingSteps.indexOf(status);
  };

  const StatusIcon = ({ status }: { status: string }) => {
    const config = statusConfig[status] || statusConfig.pending;
    const Icon = config.icon;
    return <Icon className="h-4 w-4" />;
  };

  return (
    <Sheet open={open} onOpenChange={(v) => { setOpen(v); if (v && onRefresh) onRefresh(); }}>
      <SheetTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Truck className="h-4 w-4" />
          Track Orders
          {orders.length > 0 && (
            <Badge variant="secondary" className="ml-1">
              {orders.length}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-lg flex flex-col">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            {selectedOrder ? "Order Details" : "My Orders"}
          </SheetTitle>
        </SheetHeader>

        {selectedOrder ? (
          <div className="flex-1 space-y-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedOrder(null)}
              className="mb-2"
            >
              ← Back to orders
            </Button>

            {/* Order Summary */}
            <div className="p-4 bg-muted/30 rounded-lg space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Order ID</span>
                <span className="font-mono text-sm">{selectedOrder.id.slice(0, 8)}...</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Order Date</span>
                <span className="text-sm">
                  {format(new Date(selectedOrder.created_at), "MMM d, yyyy")}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Total Amount</span>
                <span className="font-bold">₹{selectedOrder.total_amount.toFixed(2)}</span>
              </div>
              {selectedOrder.tracking_number && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Tracking #</span>
                  <span className="font-mono text-sm">{selectedOrder.tracking_number}</span>
                </div>
              )}
              {selectedOrder.carrier && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Carrier</span>
                  <span className="text-sm">{selectedOrder.carrier}</span>
                </div>
              )}
            </div>

            {/* Tracking Timeline */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Tracking Progress
              </h3>
              
              <div className="relative">
                {trackingSteps.map((step, index) => {
                  const config = statusConfig[step];
                  const currentIndex = getStatusIndex(selectedOrder.status);
                  const isCompleted = index <= currentIndex;
                  const isCurrent = step === selectedOrder.status;
                  const Icon = config.icon;

                  return (
                    <div key={step} className="flex gap-4 pb-6 last:pb-0">
                      {/* Timeline connector */}
                      <div className="flex flex-col items-center">
                        <div
                          className={`h-8 w-8 rounded-full flex items-center justify-center transition-all ${
                            isCompleted
                              ? `${config.color} text-white`
                              : "bg-muted text-muted-foreground"
                          } ${isCurrent ? "ring-4 ring-primary/20" : ""}`}
                        >
                          <Icon className="h-4 w-4" />
                        </div>
                        {index < trackingSteps.length - 1 && (
                          <div
                            className={`w-0.5 flex-1 mt-2 ${
                              index < currentIndex ? config.color : "bg-muted"
                            }`}
                          />
                        )}
                      </div>

                      {/* Step content */}
                      <div className="flex-1 pt-1">
                        <p
                          className={`font-medium text-sm ${
                            isCompleted ? "text-foreground" : "text-muted-foreground"
                          }`}
                        >
                          {config.label}
                        </p>
                        {isCurrent && (
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Current status
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Estimated Delivery */}
            {selectedOrder.estimated_delivery && (
              <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <div className="flex items-center gap-2 text-primary">
                  <Calendar className="h-4 w-4" />
                  <span className="font-medium text-sm">Estimated Delivery</span>
                </div>
                <p className="text-lg font-bold mt-1">
                  {format(new Date(selectedOrder.estimated_delivery), "EEEE, MMM d, yyyy")}
                </p>
              </div>
            )}

            {/* Shipping Address */}
            {selectedOrder.shipping_address && (
              <div className="p-4 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-2 text-muted-foreground mb-2">
                  <MapPin className="h-4 w-4" />
                  <span className="text-sm font-medium">Delivery Address</span>
                </div>
                <p className="text-sm">{selectedOrder.shipping_address}</p>
              </div>
            )}
          </div>
        ) : (
          <ScrollArea className="flex-1">
            {orders.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center py-12">
                <Package className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="font-semibold text-lg">No orders yet</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Your orders will appear here
                </p>
              </div>
            ) : (
              <div className="space-y-3 py-4">
                {orders.map((order) => {
                  const config = statusConfig[order.status] || statusConfig.pending;

                  return (
                    <button
                      key={order.id}
                      onClick={() => setSelectedOrder(order)}
                      className="w-full p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors text-left"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`h-10 w-10 rounded-full ${config.color} flex items-center justify-center text-white`}>
                            <StatusIcon status={order.status} />
                          </div>
                          <div>
                            <p className="font-medium text-sm">
                              Order #{order.id.slice(0, 8)}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(order.created_at), "MMM d, yyyy")}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <Badge variant="secondary" className="text-xs">
                              {config.label}
                            </Badge>
                            <p className="font-bold text-sm mt-1">
                              ₹{order.total_amount.toFixed(2)}
                            </p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        )}
      </SheetContent>
    </Sheet>
  );
}
