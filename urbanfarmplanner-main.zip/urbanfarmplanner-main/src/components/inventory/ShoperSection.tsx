import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Lock,
  Unlock,
  Package,
  ShoppingBag,
  Edit,
  Check,
  X,
  Eye,
  IndianRupee,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";



interface InventoryItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
  is_available: boolean;
}

interface OrderWithItems {
  id: string;
  status: string;
  total_amount: number;
  created_at: string;
  shipping_address: string | null;
  notes: string | null;
  user_id: string;
  user_name?: string;
  items: { name: string; quantity: number; price: number }[];
}

export function ShoperSection() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [codeError, setCodeError] = useState(false);
  const [products, setProducts] = useState<InventoryItem[]>([]);
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState("");
  const [editQuantity, setEditQuantity] = useState("");
  const [orderDetailId, setOrderDetailId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"products" | "orders">("products");

  useEffect(() => {
    if (isUnlocked) {
      loadProducts();
      loadOrders();
    }
  }, [isUnlocked]);

  const handleUnlock = async () => {
    // Must be signed in to check admin role
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setCodeError(true);
      toast.error("Please sign in to access the Shoper panel");
      return;
    }

    // Server-side check: the current user must already hold the admin role.
    // The 'admin' role can only be granted by another admin via the
    // user_roles table's RLS policies — there is no shared-code path.
    const { data: isAdmin, error } = await supabase.rpc("has_role", {
      _user_id: user.id,
      _role: "admin",
    });

    if (error || !isAdmin) {
      setCodeError(true);
      toast.error("Your account does not have admin access");
      return;
    }

    setIsUnlocked(true);
    setCodeError(false);
    toast.success("Shoper section unlocked!");
  };

  const loadProducts = async () => {
    const { data } = await supabase
      .from("inventory_items")
      .select("id, name, price, quantity, category, is_available")
      .order("name");
    setProducts(data || []);
  };

  const loadOrders = async () => {
    const { data: ordersData } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });

    if (!ordersData) return;

    const enriched: OrderWithItems[] = [];
    for (const order of ordersData) {
      const { data: items } = await supabase
        .from("order_items")
        .select("quantity, price_at_purchase, inventory_items(name)")
        .eq("order_id", order.id);

      const { data: profile } = await supabase
        .rpc("get_public_profile", { _user_id: order.user_id });

      const settings = Array.isArray(profile) ? profile[0] : profile;

      enriched.push({
        ...order,
        user_name: settings?.name || "Unknown User",
        items: (items || []).map((i: any) => ({
          name: i.inventory_items?.name || "Unknown",
          quantity: i.quantity,
          price: i.price_at_purchase,
        })),
      });
    }
    setOrders(enriched);
  };

  const handleEditStart = (item: InventoryItem) => {
    setEditingId(item.id);
    setEditPrice(item.price.toString());
    setEditQuantity(item.quantity.toString());
  };

  const handleEditSave = async (id: string) => {
    const newQty = parseInt(editQuantity);
    const { error } = await supabase
      .from("inventory_items")
      .update({
        price: parseFloat(editPrice),
        quantity: newQty,
        is_available: newQty > 0,
      })
      .eq("id", id);

    if (error) {
      toast.error("Failed to update product");
      return;
    }
    toast.success("Product updated!");
    setEditingId(null);
    loadProducts();
  };

  const handleConfirmOrder = async (orderId: string) => {
    const { error } = await supabase
      .from("orders")
      .update({ status: "confirmed" })
      .eq("id", orderId);

    if (error) {
      toast.error("Failed to confirm order");
      return;
    }
    toast.success("Order confirmed!");
    loadOrders();
  };

  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    const { error } = await supabase
      .from("orders")
      .update({ status })
      .eq("id", orderId);

    if (error) {
      toast.error("Failed to update order status");
      return;
    }
    toast.success(`Order marked as ${status}`);
    loadOrders();
  };

  const selectedOrder = orders.find((o) => o.id === orderDetailId);

  const statusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "confirmed": return "bg-blue-100 text-blue-800";
      case "shipped": return "bg-purple-100 text-purple-800";
      case "delivered": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-muted text-muted-foreground";
    }
  };

  if (!isUnlocked) {
    return (
      <Card className="border-dashed border-2 border-muted-foreground/30">
        <CardHeader className="text-center">
          <Lock className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
          <CardTitle className="text-xl">Shoper Admin Panel</CardTitle>
          <p className="text-sm text-muted-foreground">
            Click below to verify your admin access and manage products & orders
          </p>
        </CardHeader>
        <CardContent className="max-w-sm mx-auto space-y-4">
          {codeError && (
            <p className="text-xs text-destructive text-center">
              Your account does not have admin access. Ask an existing admin to grant you the role.
            </p>
          )}
          <Button className="w-full gap-2" onClick={handleUnlock}>
            <Unlock className="h-4 w-4" />
            Unlock
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            Shoper Admin Panel
          </CardTitle>
          <div className="flex gap-2">
            <Button
              variant={activeTab === "products" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("products")}
              className="gap-1"
            >
              <Package className="h-4 w-4" />
              Products ({products.length})
            </Button>
            <Button
              variant={activeTab === "orders" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("orders")}
              className="gap-1"
            >
              <ShoppingBag className="h-4 w-4" />
              Orders ({orders.length})
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setIsUnlocked(false)}>
              <Lock className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {activeTab === "products" && (
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead className="text-right">Price (₹)</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.category}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {editingId === item.id ? (
                        <Input
                          type="number"
                          value={editPrice}
                          onChange={(e) => setEditPrice(e.target.value)}
                          className="w-24 ml-auto"
                        />
                      ) : (
                        `₹${item.price}`
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {editingId === item.id ? (
                        <Input
                          type="number"
                          value={editQuantity}
                          onChange={(e) => setEditQuantity(e.target.value)}
                          className="w-20 ml-auto"
                        />
                      ) : (
                        item.quantity
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={item.is_available ? "default" : "secondary"}>
                        {item.is_available ? "Available" : "Unavailable"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {editingId === item.id ? (
                        <div className="flex gap-1 justify-end">
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => handleEditSave(item.id)}>
                            <Check className="h-4 w-4 text-green-600" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditingId(null)}>
                            <X className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      ) : (
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => handleEditStart(item)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        )}

        {activeTab === "orders" && (
          <>
            <ScrollArea className="h-[500px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        No orders yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-mono text-xs">
                          {order.id.slice(0, 8)}...
                        </TableCell>
                        <TableCell>{order.user_name}</TableCell>
                        <TableCell className="text-right font-semibold">
                          ₹{order.total_amount}
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor(order.status)}`}>
                            {order.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(order.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-1 justify-end">
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setOrderDetailId(order.id)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            {order.status === "pending" && (
                              <Button size="sm" variant="default" className="h-7 text-xs" onClick={() => handleConfirmOrder(order.id)}>
                                Confirm
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </ScrollArea>

            {/* Order Detail Dialog */}
            <Dialog open={!!orderDetailId} onOpenChange={(v) => !v && setOrderDetailId(null)}>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle>Order Details</DialogTitle>
                </DialogHeader>
                {selectedOrder && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div><span className="text-muted-foreground">Order ID:</span> <span className="font-mono">{selectedOrder.id.slice(0, 12)}...</span></div>
                      <div><span className="text-muted-foreground">Customer:</span> {selectedOrder.user_name}</div>
                      <div><span className="text-muted-foreground">Date:</span> {new Date(selectedOrder.created_at).toLocaleString()}</div>
                      <div><span className="text-muted-foreground">Status:</span> <span className={`px-2 py-0.5 rounded-full text-xs ${statusColor(selectedOrder.status)}`}>{selectedOrder.status}</span></div>
                    </div>
                    <Separator />
                    <div>
                      <h4 className="font-medium mb-2">Items</h4>
                      {selectedOrder.items.map((item, i) => (
                        <div key={i} className="flex justify-between text-sm py-1">
                          <span>{item.name} × {item.quantity}</span>
                          <span className="font-medium">₹{(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                      <Separator className="my-2" />
                      <div className="flex justify-between font-semibold">
                        <span>Total</span>
                        <span>₹{selectedOrder.total_amount}</span>
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <Label>Update Status</Label>
                      <Select value={selectedOrder.status} onValueChange={(v) => handleUpdateOrderStatus(selectedOrder.id, v)}>
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="confirmed">Confirmed</SelectItem>
                          <SelectItem value="shipped">Shipped</SelectItem>
                          <SelectItem value="delivered">Delivered</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </>
        )}
      </CardContent>
    </Card>
  );
}
