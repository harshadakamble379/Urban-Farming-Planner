import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Star, MessageSquare, User, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { z } from "zod";

// Server-side validation schema for review submissions
const reviewSchema = z.object({
  rating: z.number().int().min(1, "Rating must be at least 1").max(5, "Rating cannot exceed 5"),
  title: z.string().max(100, "Title must be 100 characters or less").optional().nullable(),
  comment: z.string().max(1000, "Comment must be 1000 characters or less").optional().nullable(),
});

interface Review {
  id: string;
  rating: number;
  title: string | null;
  comment: string | null;
  created_at: string;
  user_id: string;
}

interface ProductReviewsProps {
  itemId: string;
  itemName: string;
  reviews: Review[];
  averageRating: number;
  onReviewAdded: () => void;
}

export function ProductReviews({
  itemId,
  itemName,
  reviews,
  averageRating,
  onReviewAdded,
}: ProductReviewsProps) {
  const [open, setOpen] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    rating: 5,
    title: "",
    comment: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please login to leave a review");
      setIsSubmitting(false);
      return;
    }

    // Validate input before database insertion
    const validationResult = reviewSchema.safeParse({
      rating: formData.rating,
      title: formData.title || null,
      comment: formData.comment || null,
    });

    if (!validationResult.success) {
      const firstError = validationResult.error.errors[0];
      toast.error(firstError?.message || "Invalid review data");
      setIsSubmitting(false);
      return;
    }

    const validatedData = validationResult.data;

    const { error } = await supabase.from("reviews").insert({
      user_id: user.id,
      item_id: itemId,
      rating: validatedData.rating,
      title: validatedData.title,
      comment: validatedData.comment,
    });

    if (error) {
      if (error.code === "23505") {
        toast.error("You have already reviewed this product");
      } else {
        toast.error("Failed to submit review");
      }
      setIsSubmitting(false);
      return;
    }

    toast.success("Review submitted successfully!");
    setFormData({ rating: 5, title: "", comment: "" });
    setShowForm(false);
    setIsSubmitting(false);
    onReviewAdded();
  };

  const renderStars = (rating: number, interactive = false, size = "h-4 w-4") => {
    return (
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type={interactive ? "button" : undefined}
            onClick={interactive ? () => setFormData({ ...formData, rating: star }) : undefined}
            className={interactive ? "cursor-pointer hover:scale-110 transition-transform" : "cursor-default"}
            disabled={!interactive}
          >
            <Star
              className={`${size} ${
                star <= rating
                  ? "fill-amber-400 text-amber-400"
                  : "text-muted-foreground/30"
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-1 text-xs">
          <MessageSquare className="h-3 w-3" />
          {reviews.length} Reviews
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Reviews for {itemName}
          </DialogTitle>
          <DialogDescription className="flex items-center gap-2">
            {renderStars(Math.round(averageRating))}
            <span className="font-medium">{averageRating.toFixed(1)}</span>
            <span className="text-muted-foreground">({reviews.length} reviews)</span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {!showForm ? (
            <Button onClick={() => setShowForm(true)} className="w-full">
              Write a Review
            </Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-muted/30 rounded-lg">
              <div className="space-y-2">
                <Label>Your Rating</Label>
                {renderStars(formData.rating, true, "h-6 w-6")}
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Review Title (optional)</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Summarize your experience"
                  maxLength={100}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="comment">Your Review (optional)</Label>
                <Textarea
                  id="comment"
                  value={formData.comment}
                  onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                  placeholder="Share your thoughts about this product..."
                  rows={3}
                  maxLength={1000}
                />
              </div>

              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Submit Review
                </Button>
              </div>
            </form>
          )}

          <ScrollArea className="h-[300px]">
            {reviews.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No reviews yet. Be the first to review!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {reviews.map((review) => (
                  <div key={review.id} className="p-4 bg-muted/20 rounded-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <User className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          {renderStars(review.rating)}
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(review.created_at), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                    </div>
                    {review.title && (
                      <h4 className="font-medium text-sm">{review.title}</h4>
                    )}
                    {review.comment && (
                      <p className="text-sm text-muted-foreground">{review.comment}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
