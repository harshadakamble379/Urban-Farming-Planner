import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Sprout,
  Sun,
  Droplets,
  Thermometer,
  Ruler,
  Calendar,
  Lightbulb,
  Leaf,
} from "lucide-react";
import { getGuideByName, GrowingGuide } from "@/data/seedGrowingGuides";

interface SeedGrowingGuideProps {
  seedName: string;
  category: string;
}

export function SeedGrowingGuide({ seedName, category }: SeedGrowingGuideProps) {
  const [isOpen, setIsOpen] = useState(false);
  const guide = getGuideByName(seedName);

  // Only show for seeds category
  if (!category.toLowerCase().includes('seed')) {
    return null;
  }

  if (!guide) {
    return null;
  }

  const difficultyColor = {
    Easy: 'bg-green-500/20 text-green-600 border-green-500/30',
    Medium: 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30',
    Hard: 'bg-red-500/20 text-red-600 border-red-500/30',
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5">
          <Sprout className="h-4 w-4" />
          Growing Guide
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Leaf className="h-5 w-5 text-primary" />
            {guide.seedName} - Growing Guide
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[70vh] pr-4">
          <div className="space-y-6">
            {/* Header Info */}
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="bg-primary/10">
                {guide.category}
              </Badge>
              <Badge variant="outline" className={difficultyColor[guide.difficulty]}>
                {guide.difficulty} Difficulty
              </Badge>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <InfoCard
                icon={<Sprout className="h-4 w-4" />}
                label="Germination"
                value={guide.germinationDays}
              />
              <InfoCard
                icon={<Calendar className="h-4 w-4" />}
                label="Harvest Time"
                value={guide.harvestTime}
              />
              <InfoCard
                icon={<Thermometer className="h-4 w-4" />}
                label="Temperature"
                value={guide.optimalTemperature}
              />
              <InfoCard
                icon={<Sun className="h-4 w-4" />}
                label="Sunlight"
                value={guide.sunlight}
              />
              <InfoCard
                icon={<Droplets className="h-4 w-4" />}
                label="Watering"
                value={guide.wateringFrequency}
              />
              <InfoCard
                icon={<Ruler className="h-4 w-4" />}
                label="Spacing"
                value={guide.spacing}
              />
            </div>

            <Separator />

            {/* Detailed Info */}
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm text-muted-foreground mb-1">
                  Soil Requirements
                </h4>
                <p className="text-sm">{guide.soilType}</p>
              </div>
              
              <div>
                <h4 className="font-semibold text-sm text-muted-foreground mb-1">
                  Planting Depth
                </h4>
                <p className="text-sm">{guide.plantingDepth}</p>
              </div>
            </div>

            <Separator />

            {/* Growing Tips */}
            <div>
              <h4 className="font-semibold flex items-center gap-2 mb-3">
                <Lightbulb className="h-4 w-4 text-yellow-500" />
                Growing Tips
              </h4>
              <ul className="space-y-2">
                {guide.tips.map((tip, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

function InfoCard({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg bg-muted/50 p-3 space-y-1">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        {icon}
        <span className="text-xs font-medium">{label}</span>
      </div>
      <p className="text-sm font-medium">{value}</p>
    </div>
  );
}
