import { useState, useEffect } from "react";
import { Calendar, ChevronLeft, ChevronRight, Droplets, Scissors, Flower2, Box } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { 
  format, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameDay, 
  addWeeks, 
  subWeeks,
  isToday,
  isPast 
} from "date-fns";

interface Reminder {
  id: string;
  plant_name: string;
  reminder_type: string;
  schedule_days: number;
  next_due_at: string;
  is_active: boolean;
}

const typeIcons: Record<string, any> = {
  watering: Droplets,
  fertilizing: Flower2,
  pruning: Scissors,
  repotting: Box,
};

const typeColors: Record<string, string> = {
  watering: "bg-blue-500/20 text-blue-600 border-blue-500/30",
  fertilizing: "bg-green-500/20 text-green-600 border-green-500/30",
  pruning: "bg-orange-500/20 text-orange-600 border-orange-500/30",
  repotting: "bg-purple-500/20 text-purple-600 border-purple-500/30",
};

export function CareCalendar() {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState(true);

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 });
  const daysOfWeek = eachDayOfInterval({ start: weekStart, end: weekEnd });

  useEffect(() => {
    loadReminders();
  }, []);

  const loadReminders = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from("plant_reminders")
      .select("*")
      .eq("user_id", user.id)
      .eq("is_active", true);

    if (!error && data) {
      setReminders(data);
    }
    setLoading(false);
  };

  const getRemindersForDay = (day: Date) => {
    return reminders.filter((r) => isSameDay(new Date(r.next_due_at), day));
  };

  const goToPreviousWeek = () => setCurrentWeek(subWeeks(currentWeek, 1));
  const goToNextWeek = () => setCurrentWeek(addWeeks(currentWeek, 1));
  const goToToday = () => setCurrentWeek(new Date());

  return (
    <div className="rounded-2xl bg-card p-6 shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Care Calendar</h3>
            <p className="text-sm text-muted-foreground">
              {format(weekStart, "MMM d")} - {format(weekEnd, "MMM d, yyyy")}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={goToToday}>
            Today
          </Button>
          <Button variant="ghost" size="icon" onClick={goToPreviousWeek}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={goToNextWeek}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="text-center text-muted-foreground py-8">Loading...</div>
      ) : (
        <div className="grid grid-cols-7 gap-2">
          {daysOfWeek.map((day) => {
            const dayReminders = getRemindersForDay(day);
            const isCurrentDay = isToday(day);
            const isPastDay = isPast(day) && !isCurrentDay;

            return (
              <div
                key={day.toISOString()}
                className={`rounded-lg border p-2 min-h-[120px] transition-colors ${
                  isCurrentDay
                    ? "border-primary bg-primary/5"
                    : isPastDay
                    ? "border-border/50 bg-muted/30"
                    : "border-border"
                }`}
              >
                <div className="text-center mb-2">
                  <p className="text-xs text-muted-foreground uppercase">
                    {format(day, "EEE")}
                  </p>
                  <p
                    className={`text-lg font-semibold ${
                      isCurrentDay ? "text-primary" : "text-foreground"
                    }`}
                  >
                    {format(day, "d")}
                  </p>
                </div>

                <ScrollArea className="h-[80px]">
                  <div className="space-y-1">
                    {dayReminders.map((reminder) => {
                      const Icon = typeIcons[reminder.reminder_type] || Droplets;
                      const colorClass = typeColors[reminder.reminder_type] || typeColors.watering;

                      return (
                        <div
                          key={reminder.id}
                          className={`flex items-center gap-1 rounded px-1.5 py-0.5 text-xs border ${colorClass}`}
                        >
                          <Icon className="h-3 w-3 flex-shrink-0" />
                          <span className="truncate">{reminder.plant_name}</span>
                        </div>
                      );
                    })}
                    {dayReminders.length === 0 && (
                      <p className="text-xs text-muted-foreground/50 text-center">
                        No tasks
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </div>
            );
          })}
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap gap-3 mt-4 pt-4 border-t border-border">
        {Object.entries(typeColors).map(([type, colorClass]) => {
          const Icon = typeIcons[type];
          return (
            <div key={type} className="flex items-center gap-1.5">
              <div className={`flex items-center gap-1 rounded px-2 py-0.5 text-xs border ${colorClass}`}>
                <Icon className="h-3 w-3" />
                <span className="capitalize">{type}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
