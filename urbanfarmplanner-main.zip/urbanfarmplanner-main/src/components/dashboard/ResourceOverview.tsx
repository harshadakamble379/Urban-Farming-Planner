import { Droplets, Wind, Sun } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface ResourceOverviewProps {
  totalPlants: number;
  weeklyWater: number;
}

export function ResourceOverview({ totalPlants, weeklyWater }: ResourceOverviewProps) {
  // Calculate resources based on actual plant data
  const maxWater = Math.max(weeklyWater, 500); // At least 500L scale
  const waterPercentage = weeklyWater > 0 ? (weeklyWater / maxWater) * 100 : 0;

  // Oxygen production estimate (plants produce ~5-10ml O2 per hour)
  const dailyOxygenMl = totalPlants * 120; // ~120ml per plant per day
  const maxOxygen = Math.max(dailyOxygenMl, 5000);
  const oxygenPercentage = dailyOxygenMl > 0 ? (dailyOxygenMl / maxOxygen) * 100 : 0;

  // Average sunlight (simulated based on typical urban conditions)
  const avgSunlight = totalPlants > 0 ? 6.5 : 0;
  const maxSunlight = 8;
  const sunlightPercentage = (avgSunlight / maxSunlight) * 100;

  const resources = [
    {
      icon: Droplets,
      label: "Water Usage",
      current: weeklyWater,
      max: maxWater,
      unit: "L/week",
      color: "bg-blue-500",
      textColor: "text-blue-500",
      percentage: waterPercentage,
    },
    {
      icon: Wind,
      label: "Oxygen Production",
      current: dailyOxygenMl,
      max: maxOxygen,
      unit: "ml/day",
      color: "bg-forest",
      textColor: "text-forest",
      percentage: oxygenPercentage,
    },
    {
      icon: Sun,
      label: "Avg Sunlight",
      current: avgSunlight,
      max: maxSunlight,
      unit: "hrs/day",
      color: "bg-amber-500",
      textColor: "text-amber-500",
      percentage: sunlightPercentage,
    },
  ];

  return (
    <div className="rounded-2xl bg-card p-6 shadow-card">
      <h3 className="mb-4 text-lg font-semibold text-foreground">Resource Overview</h3>
      <div className="space-y-5">
        {resources.map((resource) => (
          <div key={resource.label} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${resource.color}/10`}>
                  <resource.icon className={`h-4 w-4 ${resource.textColor}`} />
                </div>
                <span className="text-sm font-medium text-foreground">{resource.label}</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {resource.current.toLocaleString()} {resource.unit}
              </span>
            </div>
            <Progress value={resource.percentage} className="h-2" />
          </div>
        ))}
      </div>

      {totalPlants === 0 && (
        <p className="mt-4 text-xs text-muted-foreground text-center">
          Add plants to your projects to see resource usage
        </p>
      )}
    </div>
  );
}
