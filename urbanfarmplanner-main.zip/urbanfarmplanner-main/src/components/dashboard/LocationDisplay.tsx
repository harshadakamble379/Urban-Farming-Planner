import { MapPin, Thermometer, CloudRain, Wind, RefreshCw, Wifi, WifiOff } from "lucide-react";
import { useLocation } from "@/contexts/LocationContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

export function LocationDisplay() {
  const { 
    city, 
    currentTemperature, 
    humidity, 
    windSpeed,
    isLiveWeather, 
    loading, 
    lastUpdated,
    refreshWeather 
  } = useLocation();

  const handleRefresh = () => {
    refreshWeather();
    toast.success("Refreshing weather data...");
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <MapPin className="h-4 w-4" />
        <span>Loading weather...</span>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap items-center gap-3 text-sm">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <MapPin className="h-4 w-4" />
        <span className="font-medium">{city}</span>
      </div>
      <div className="flex items-center gap-1.5">
        <Thermometer className="h-4 w-4 text-orange-500" />
        <span className="font-semibold text-foreground">{currentTemperature}°C</span>
      </div>
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <CloudRain className="h-4 w-4 text-blue-500" />
        <span>{humidity}%</span>
      </div>
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Wind className="h-4 w-4 text-cyan-500" />
        <span>{windSpeed} km/h</span>
      </div>
      <div className="flex items-center gap-1.5">
        {isLiveWeather ? (
          <Wifi className="h-3.5 w-3.5 text-green-500" />
        ) : (
          <WifiOff className="h-3.5 w-3.5 text-muted-foreground" />
        )}
        <span className="text-xs text-muted-foreground">
          {isLiveWeather ? "Live" : "Simulated"}
        </span>
      </div>
      {lastUpdated && (
        <span className="text-xs text-muted-foreground">
          Updated {formatDistanceToNow(lastUpdated, { addSuffix: true })}
        </span>
      )}
      <Button 
        variant="ghost" 
        size="icon" 
        className="h-6 w-6" 
        onClick={handleRefresh}
        disabled={loading}
      >
        <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
      </Button>
    </div>
  );
}
