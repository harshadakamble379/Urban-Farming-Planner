import React, { useState, useEffect, useRef } from "react";
import { Camera, Plus, Trash2, Leaf, TrendingUp, Thermometer, Droplets, Image as ImageIcon } from "lucide-react";
import { SecureImage } from "@/components/ui/secure-image";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { useLocation } from "@/contexts/LocationContext";

interface HealthLog {
  id: string;
  plant_name: string;
  health_status: string;
  notes: string | null;
  photo_url: string | null;
  height_cm: number | null;
  leaves_count: number | null;
  temperature_celsius: number | null;
  humidity_percent: number | null;
  logged_at: string;
}

const healthStatuses = [
  { value: "thriving", label: "Thriving", color: "bg-green-500" },
  { value: "healthy", label: "Healthy", color: "bg-emerald-500" },
  { value: "moderate", label: "Moderate", color: "bg-yellow-500" },
  { value: "struggling", label: "Struggling", color: "bg-orange-500" },
  { value: "critical", label: "Critical", color: "bg-red-500" },
];

const plantOptions = [
  "Peace Lily", "Jasmine", "Orchid", "Lavender", "Gerbera Daisy",
  "Areca Palm", "Snake Plant", "Money Plant", "Aloe Vera",
  "Spider Plant", "Boston Fern", "Rubber Plant",
];

export function PlantHealthTracker() {
  const [logs, setLogs] = useState<HealthLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { currentTemperature, humidity } = useLocation();

  const [newLog, setNewLog] = useState({
    plant_name: "",
    health_status: "healthy",
    notes: "",
    height_cm: "",
    leaves_count: "",
  });

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from("plant_health_logs")
      .select("*")
      .eq("user_id", user.id)
      .order("logged_at", { ascending: false })
      .limit(20);

    if (!error && data) {
      setLogs(data);
    }
    setLoading(false);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image must be less than 5MB");
        return;
      }
      setSelectedImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const uploadImage = async (userId: string): Promise<string | null> => {
    if (!selectedImage) return null;

    const fileExt = selectedImage.name.split(".").pop();
    const fileName = `${userId}/${Date.now()}.${fileExt}`;

    const { error } = await supabase.storage
      .from("plant-photos")
      .upload(fileName, selectedImage);

    if (error) {
      console.error("Upload error:", error);
      return null;
    }

    // Return just the file path - we'll generate signed URLs when displaying
    return fileName;
  };

  const addLog = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please log in to add health logs");
      return;
    }

    if (!newLog.plant_name) {
      toast.error("Please select a plant");
      return;
    }

    setUploading(true);

    try {
      let photoUrl = null;
      if (selectedImage) {
        photoUrl = await uploadImage(user.id);
      }

      const { error } = await supabase.from("plant_health_logs").insert({
        user_id: user.id,
        plant_name: newLog.plant_name,
        health_status: newLog.health_status,
        notes: newLog.notes || null,
        photo_url: photoUrl,
        height_cm: newLog.height_cm ? parseFloat(newLog.height_cm) : null,
        leaves_count: newLog.leaves_count ? parseInt(newLog.leaves_count) : null,
        temperature_celsius: currentTemperature,
        humidity_percent: humidity,
      });

      if (error) throw error;

      toast.success("Health log added!");
      setDialogOpen(false);
      setNewLog({ plant_name: "", health_status: "healthy", notes: "", height_cm: "", leaves_count: "" });
      setSelectedImage(null);
      setImagePreview(null);
      loadLogs();
    } catch (error) {
      toast.error("Failed to add health log");
      console.error(error);
    } finally {
      setUploading(false);
    }
  };

  const deleteLog = async (id: string) => {
    const { error } = await supabase.from("plant_health_logs").delete().eq("id", id);
    if (error) {
      toast.error("Failed to delete log");
    } else {
      toast.success("Log deleted");
      loadLogs();
    }
  };

  const getStatusInfo = (status: string) => {
    return healthStatuses.find(s => s.value === status) || healthStatuses[1];
  };

  return (
    <div className="rounded-2xl bg-card p-6 shadow-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
            <Leaf className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Plant Health Tracker</h3>
            <p className="text-sm text-muted-foreground">Track growth & health over time</p>
          </div>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-2">
              <Plus className="h-4 w-4" />
              Log Health
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Log Plant Health</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Plant</Label>
                <Select
                  value={newLog.plant_name}
                  onValueChange={(v) => setNewLog({ ...newLog, plant_name: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a plant" />
                  </SelectTrigger>
                  <SelectContent>
                    {plantOptions.map((plant) => (
                      <SelectItem key={plant} value={plant}>{plant}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Health Status</Label>
                <Select
                  value={newLog.health_status}
                  onValueChange={(v) => setNewLog({ ...newLog, health_status: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {healthStatuses.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        <div className="flex items-center gap-2">
                          <div className={`h-2 w-2 rounded-full ${status.color}`} />
                          {status.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Height (cm)</Label>
                  <Input
                    type="number"
                    placeholder="e.g., 25"
                    value={newLog.height_cm}
                    onChange={(e) => setNewLog({ ...newLog, height_cm: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Leaves Count</Label>
                  <Input
                    type="number"
                    placeholder="e.g., 12"
                    value={newLog.leaves_count}
                    onChange={(e) => setNewLog({ ...newLog, leaves_count: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Photo</Label>
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  className="hidden"
                />
                {imagePreview ? (
                  <div className="relative">
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    <Button
                      size="icon"
                      variant="destructive"
                      className="absolute top-2 right-2 h-6 w-6"
                      onClick={() => {
                        setSelectedImage(null);
                        setImagePreview(null);
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    className="w-full h-24 border-dashed"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <div className="flex flex-col items-center gap-2">
                      <Camera className="h-6 w-6 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Add Photo</span>
                    </div>
                  </Button>
                )}
              </div>

              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea
                  placeholder="Any observations..."
                  value={newLog.notes}
                  onChange={(e) => setNewLog({ ...newLog, notes: e.target.value })}
                />
              </div>

              <div className="flex items-center gap-4 p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-2 text-sm">
                  <Thermometer className="h-4 w-4 text-orange-500" />
                  <span>{currentTemperature}°C</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Droplets className="h-4 w-4 text-blue-500" />
                  <span>{humidity}%</span>
                </div>
              </div>

              <Button onClick={addLog} className="w-full" disabled={uploading}>
                {uploading ? "Saving..." : "Save Health Log"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <ScrollArea className="h-[300px]">
        {loading ? (
          <div className="text-center text-muted-foreground py-8">Loading...</div>
        ) : logs.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <Leaf className="h-12 w-12 mx-auto mb-2 opacity-30" />
            <p>No health logs yet</p>
            <p className="text-sm">Start tracking your plants' health</p>
          </div>
        ) : (
          <div className="space-y-3">
            {logs.map((log) => {
              const statusInfo = getStatusInfo(log.health_status);
              return (
                <div key={log.id} className="flex gap-3 rounded-lg border border-border p-3">
                  {log.photo_url ? (
                    <SecureImage
                      bucket="plant-photos"
                      path={log.photo_url}
                      alt={log.plant_name}
                      className="h-16 w-16 rounded-lg object-cover flex-shrink-0"
                      fallbackClassName="h-16 w-16 rounded-lg bg-muted flex-shrink-0"
                    />
                  ) : (
                    <div className="h-16 w-16 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                      <ImageIcon className="h-6 w-6 text-muted-foreground" />
                    </div>
                  )}

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground truncate">{log.plant_name}</p>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6 text-muted-foreground hover:text-destructive"
                        onClick={() => deleteLog(log.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary" className="text-xs">
                        <div className={`h-1.5 w-1.5 rounded-full ${statusInfo.color} mr-1`} />
                        {statusInfo.label}
                      </Badge>
                      {log.height_cm && (
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <TrendingUp className="h-3 w-3" />
                          {log.height_cm}cm
                        </span>
                      )}
                      {log.temperature_celsius && (
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Thermometer className="h-3 w-3" />
                          {log.temperature_celsius}°C
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-muted-foreground mt-1">
                      {format(new Date(log.logged_at), "MMM d, yyyy h:mm a")}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
