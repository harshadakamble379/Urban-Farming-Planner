import { useState, useEffect, useCallback, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "@/contexts/LocationContext";
import { supabase } from "@/integrations/supabase/client";
import { cityData } from "@/contexts/LocationContext";
import {
  Sun,
  Cloud,
  CloudRain,
  CloudSnow,
  CloudDrizzle,
  CloudLightning,
  CloudFog,
  Droplets,
  RefreshCw,
  Thermometer,
  Sprout,
  Snowflake,
  Umbrella,
  SunDim,
} from "lucide-react";
import { format, parseISO } from "date-fns";

interface ForecastDay {
  date: string;
  tempMax: number;
  tempMin: number;
  weatherCode: number;
  precipitation: number;
  windSpeed: number;
}

const weatherIcons: Record<number, React.ElementType> = {
  0: Sun, 1: Sun, 2: Cloud, 3: Cloud,
  45: CloudFog, 48: CloudFog,
  51: CloudDrizzle, 53: CloudDrizzle, 55: CloudDrizzle,
  61: CloudRain, 63: CloudRain, 65: CloudRain,
  71: CloudSnow, 73: CloudSnow, 75: CloudSnow,
  80: CloudRain, 81: CloudRain, 82: CloudRain,
  85: CloudSnow, 86: CloudSnow,
  95: CloudLightning, 96: CloudLightning, 99: CloudLightning,
};

const weatherDescriptions: Record<number, string> = {
  0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
  45: "Foggy", 48: "Rime fog",
  51: "Light drizzle", 53: "Drizzle", 55: "Dense drizzle",
  61: "Light rain", 63: "Rain", 65: "Heavy rain",
  71: "Light snow", 73: "Snow", 75: "Heavy snow",
  80: "Rain showers", 81: "Moderate showers", 82: "Heavy showers",
  85: "Snow showers", 86: "Heavy snow showers",
  95: "Thunderstorm", 96: "Thunderstorm w/ hail", 99: "Severe thunderstorm",
};

function getWeatherIcon(code: number) {
  return weatherIcons[code] || Cloud;
}

function getWeatherDescription(code: number) {
  return weatherDescriptions[code] || "Unknown";
}

interface GardeningTip {
  icon: React.ElementType;
  title: string;
  description: string;
  color: string;
}

function getGardeningTips(forecast: ForecastDay[]): GardeningTip[] {
  if (forecast.length === 0) return [];

  const tips: GardeningTip[] = [];
  const rainyDays = forecast.filter(d => d.precipitation > 2).length;
  const snowyDays = forecast.filter(d => [71, 73, 75, 85, 86].includes(d.weatherCode)).length;
  const sunnyDays = forecast.filter(d => [0, 1].includes(d.weatherCode)).length;
  const avgMax = Math.round(forecast.reduce((s, d) => s + d.tempMax, 0) / forecast.length);
  const minTemp = Math.min(...forecast.map(d => d.tempMin));
  const totalPrecip = forecast.reduce((s, d) => s + d.precipitation, 0);

  if (rainyDays >= 3) {
    tips.push({
      icon: Umbrella,
      title: "Skip Watering",
      description: `${rainyDays} rainy days ahead (${totalPrecip.toFixed(1)}mm total). Hold off on watering — your plants will get plenty of moisture naturally.`,
      color: "text-blue-500",
    });
  } else if (rainyDays >= 1) {
    tips.push({
      icon: Droplets,
      title: "Reduce Watering",
      description: `Rain expected on ${rainyDays} day${rainyDays > 1 ? "s" : ""}. Water only drought-sensitive plants and check soil moisture before watering.`,
      color: "text-blue-500",
    });
  }

  if (sunnyDays >= 4 && avgMax > 25) {
    tips.push({
      icon: SunDim,
      title: "Heat Protection",
      description: `${sunnyDays} sunny days with highs around ${avgMax}°C. Water early morning or evening, and consider shade cloth for delicate seedlings.`,
      color: "text-amber-500",
    });
  } else if (sunnyDays >= 4) {
    tips.push({
      icon: Sun,
      title: "Great Growing Weather",
      description: `${sunnyDays} sunny days ahead! Perfect conditions for transplanting, sowing seeds, and general garden maintenance.`,
      color: "text-amber-500",
    });
  }

  if (snowyDays >= 1 || minTemp < 2) {
    tips.push({
      icon: Snowflake,
      title: "Frost Alert",
      description: `Lows dropping to ${minTemp}°C. Cover frost-sensitive plants, bring potted plants indoors, and avoid planting tender seedlings.`,
      color: "text-cyan-500",
    });
  }

  if (rainyDays === 0 && sunnyDays >= 5) {
    tips.push({
      icon: Droplets,
      title: "Increase Watering",
      description: "No rain expected this week. Water deeply every 1-2 days, mulch to retain moisture, and check containers twice daily.",
      color: "text-blue-500",
    });
  }

  if (avgMax >= 15 && avgMax <= 28 && rainyDays <= 2) {
    tips.push({
      icon: Sprout,
      title: "Ideal Planting Window",
      description: `Average highs of ${avgMax}°C with moderate conditions — great time to plant new seeds or transplant seedlings.`,
      color: "text-green-500",
    });
  }

  return tips.slice(0, 3);
}

export function WeatherForecast() {
  const { city } = useLocation();
  const [forecast, setForecast] = useState<ForecastDay[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchForecast = useCallback(async () => {
    const info = cityData[city];
    if (!info) return;

    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke("get-weather", {
        body: { lat: info.lat, lon: info.lon, forecast: true },
      });

      if (fnError) throw fnError;

      if (data?.forecast) {
        setForecast(data.forecast);
      }
    } catch (err) {
      console.error("Forecast fetch failed:", err);
      setError("Could not load forecast");
    } finally {
      setLoading(false);
    }
  }, [city]);

  useEffect(() => {
    fetchForecast();
  }, [fetchForecast]);

  const tips = useMemo(() => getGardeningTips(forecast), [forecast]);

  return (
    <div className="space-y-4">
      <Card className="border-border/50 bg-card/80 backdrop-blur-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Thermometer className="h-5 w-5 text-primary" />
            7-Day Forecast — {city}
          </CardTitle>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={fetchForecast}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-2">
              {Array.from({ length: 7 }).map((_, i) => (
                <div key={i} className="flex flex-col items-center gap-2 p-2">
                  <Skeleton className="h-4 w-10" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-4 w-12" />
                </div>
              ))}
            </div>
          ) : error ? (
            <p className="text-sm text-muted-foreground text-center py-4">{error}</p>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-1.5 sm:gap-3">
              {forecast.map((day) => {
                const Icon = getWeatherIcon(day.weatherCode);
                const desc = getWeatherDescription(day.weatherCode);
                const dateObj = parseISO(day.date);
                const isToday =
                  format(dateObj, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd");

                return (
                  <div
                    key={day.date}
                    className={`flex flex-col items-center gap-1.5 p-2.5 sm:p-2 rounded-xl transition-colors ${
                      isToday
                        ? "bg-primary/10 ring-1 ring-primary/30"
                        : "hover:bg-muted/50"
                    }`}
                  >
                    <span className="text-xs font-medium text-muted-foreground">
                      {isToday ? "Today" : format(dateObj, "EEE")}
                    </span>
                    <span className="text-[10px] text-muted-foreground sm:hidden">
                      {format(dateObj, "d MMM")}
                    </span>
                    <Icon
                      className={`h-7 w-7 sm:h-6 sm:w-6 ${
                        day.weatherCode === 0 || day.weatherCode === 1
                          ? "text-amber-500"
                          : day.weatherCode >= 61
                          ? "text-blue-500"
                          : "text-muted-foreground"
                      }`}
                    />
                    <div className="flex items-center gap-1 text-xs">
                      <span className="font-semibold text-foreground">{day.tempMax}°</span>
                      <span className="text-muted-foreground">{day.tempMin}°</span>
                    </div>
                    <span className="text-[10px] text-muted-foreground text-center leading-tight hidden sm:block">
                      {desc}
                    </span>
                    {day.precipitation > 0 && (
                      <div className="flex items-center gap-0.5 text-[10px] text-blue-500">
                        <Droplets className="h-3 w-3" />
                        {day.precipitation}mm
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Gardening Tips */}
      {!loading && tips.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {tips.map((tip, i) => {
            const TipIcon = tip.icon;
            return (
              <Card key={i} className="border-border/50 bg-card/80 backdrop-blur-sm">
                <CardContent className="p-4 flex gap-3">
                  <div className={`shrink-0 mt-0.5 ${tip.color}`}>
                    <TipIcon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-semibold text-foreground">{tip.title}</h4>
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                        Tip
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {tip.description}
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
