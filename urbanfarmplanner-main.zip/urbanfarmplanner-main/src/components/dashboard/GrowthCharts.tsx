import React, { useState, useEffect } from "react";
import { TrendingUp, Leaf, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { format, subDays } from "date-fns";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

interface HealthLog {
  id: string;
  plant_name: string;
  health_status: string;
  height_cm: number | null;
  leaves_count: number | null;
  temperature_celsius: number | null;
  humidity_percent: number | null;
  logged_at: string;
}

const healthStatusValues: Record<string, number> = {
  thriving: 5,
  healthy: 4,
  moderate: 3,
  struggling: 2,
  critical: 1,
};

const statusLabels: Record<number, string> = {
  5: "Thriving",
  4: "Healthy",
  3: "Moderate",
  2: "Struggling",
  1: "Critical",
};

export function GrowthCharts() {
  const [logs, setLogs] = useState<HealthLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlant, setSelectedPlant] = useState<string>("all");
  const [chartType, setChartType] = useState<"height" | "health">("height");

  const plants = [...new Set(logs.map((l) => l.plant_name))];

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setLoading(false);
      return;
    }

    const thirtyDaysAgo = subDays(new Date(), 30).toISOString();

    const { data, error } = await supabase
      .from("plant_health_logs")
      .select("*")
      .eq("user_id", user.id)
      .gte("logged_at", thirtyDaysAgo)
      .order("logged_at", { ascending: true });

    if (!error && data) {
      setLogs(data);
      if (data.length > 0 && selectedPlant === "all") {
        const uniquePlants = [...new Set(data.map((l) => l.plant_name))];
        if (uniquePlants.length > 0) {
          setSelectedPlant(uniquePlants[0]);
        }
      }
    }
    setLoading(false);
  };

  const filteredLogs = selectedPlant === "all" 
    ? logs 
    : logs.filter((l) => l.plant_name === selectedPlant);

  const heightData = filteredLogs
    .filter((l) => l.height_cm !== null)
    .map((l) => ({
      date: format(new Date(l.logged_at), "MMM d"),
      height: l.height_cm,
      leaves: l.leaves_count,
    }));

  const healthData = filteredLogs.map((l) => ({
    date: format(new Date(l.logged_at), "MMM d"),
    health: healthStatusValues[l.health_status] || 3,
    temperature: l.temperature_celsius,
    humidity: l.humidity_percent,
  }));

  if (loading) {
    return (
      <div className="rounded-2xl bg-card p-6 shadow-card">
        <div className="text-center text-muted-foreground py-8">Loading charts...</div>
      </div>
    );
  }

  if (logs.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-6 shadow-card">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <TrendingUp className="h-5 w-5 text-primary" />
          </div>
          <h3 className="text-lg font-semibold text-foreground">Growth Charts</h3>
        </div>
        <div className="text-center text-muted-foreground py-8">
          <TrendingUp className="h-12 w-12 mx-auto mb-2 opacity-30" />
          <p>No growth data yet</p>
          <p className="text-sm">Log plant health to see trends</p>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-card p-6 shadow-card">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <TrendingUp className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Growth Charts</h3>
            <p className="text-sm text-muted-foreground">Track progress over time</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Select value={selectedPlant} onValueChange={setSelectedPlant}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Select plant" />
            </SelectTrigger>
            <SelectContent>
              {plants.map((plant) => (
                <SelectItem key={plant} value={plant}>
                  {plant}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex rounded-lg border border-border overflow-hidden">
            <button
              onClick={() => setChartType("height")}
              className={`px-3 py-1.5 text-sm transition-colors ${
                chartType === "height"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background text-muted-foreground hover:bg-muted"
              }`}
            >
              Height
            </button>
            <button
              onClick={() => setChartType("health")}
              className={`px-3 py-1.5 text-sm transition-colors ${
                chartType === "health"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background text-muted-foreground hover:bg-muted"
              }`}
            >
              Health
            </button>
          </div>
        </div>
      </div>

      <div className="h-[250px]">
        {chartType === "height" ? (
          heightData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={heightData}>
                <defs>
                  <linearGradient id="heightGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis 
                  dataKey="date" 
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 12 }}
                />
                <YAxis 
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 12 }}
                  label={{ value: 'cm', angle: -90, position: 'insideLeft', className: 'fill-muted-foreground' }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                  formatter={(value: number) => [`${value} cm`, "Height"]}
                />
                <Area
                  type="monotone"
                  dataKey="height"
                  stroke="hsl(var(--primary))"
                  fill="url(#heightGradient)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              <p>No height data recorded for this plant</p>
            </div>
          )
        ) : (
          healthData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={healthData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis 
                  dataKey="date" 
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 12 }}
                />
                <YAxis 
                  domain={[1, 5]}
                  ticks={[1, 2, 3, 4, 5]}
                  tickFormatter={(value) => statusLabels[value] || ""}
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 10 }}
                  width={70}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                  formatter={(value: number) => [statusLabels[value] || value, "Health Status"]}
                />
                <Line
                  type="monotone"
                  dataKey="health"
                  stroke="hsl(142, 76%, 36%)"
                  strokeWidth={2}
                  dot={{ fill: "hsl(142, 76%, 36%)", strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              <p>No health data recorded for this plant</p>
            </div>
          )
        )}
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-border">
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Total Logs</p>
          <p className="text-lg font-semibold text-foreground">{filteredLogs.length}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Latest Height</p>
          <p className="text-lg font-semibold text-foreground">
            {heightData.length > 0 ? `${heightData[heightData.length - 1].height}cm` : "-"}
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Current Health</p>
          <Badge variant="secondary" className="mt-1">
            {healthData.length > 0 
              ? statusLabels[healthData[healthData.length - 1].health] 
              : "-"}
          </Badge>
        </div>
      </div>
    </div>
  );
}
