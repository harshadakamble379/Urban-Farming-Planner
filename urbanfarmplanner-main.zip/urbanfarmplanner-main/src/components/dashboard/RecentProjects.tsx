import { Building2, MapPin, Calendar, Leaf, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";

interface Project {
  id: string;
  name: string;
  grid_items: any[];
  created_at: string;
  updated_at: string;
}

interface RecentProjectsProps {
  projects: Project[];
  loading: boolean;
}

export function RecentProjects({ projects, loading }: RecentProjectsProps) {
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="rounded-2xl bg-card p-6 shadow-card">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Recent Projects</h3>
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse rounded-xl border border-border p-4">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-lg bg-muted" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 w-32 rounded bg-muted" />
                  <div className="h-3 w-24 rounded bg-muted" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (projects.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-6 shadow-card">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Recent Projects</h3>
        </div>
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-4">
            <Leaf className="h-8 w-8 text-primary" />
          </div>
          <h4 className="text-lg font-medium text-foreground mb-2">No projects yet</h4>
          <p className="text-sm text-muted-foreground mb-4 max-w-sm">
            Start planning your urban garden by creating your first project.
          </p>
          <Button onClick={() => navigate("/planning")} className="gap-2">
            <Plus className="h-4 w-4" />
            Create First Project
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-card p-6 shadow-card">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Recent Projects</h3>
        <button 
          onClick={() => navigate("/planning")}
          className="text-sm font-medium text-primary hover:underline"
        >
          View All
        </button>
      </div>
      <div className="space-y-4">
        {projects.slice(0, 5).map((project) => {
          const plantCount = Array.isArray(project.grid_items) ? project.grid_items.length : 0;
          const uniquePlants = new Set(
            Array.isArray(project.grid_items) 
              ? project.grid_items.map((item: any) => item.name) 
              : []
          ).size;

          return (
            <div
              key={project.id}
              onClick={() => navigate("/planning")}
              className="group cursor-pointer rounded-xl border border-border p-4 transition-all duration-200 hover:border-primary/30 hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-forest/10">
                    <Building2 className="h-5 w-5 text-forest" />
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground group-hover:text-primary transition-colors">
                      {project.name}
                    </h4>
                    <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                      <Leaf className="h-3 w-3" />
                      {plantCount} plants • {uniquePlants} species
                    </div>
                  </div>
                </div>
                <Badge
                  variant={plantCount > 0 ? "default" : "secondary"}
                  className={plantCount > 0 ? "bg-primary" : ""}
                >
                  {plantCount > 0 ? "active" : "empty"}
                </Badge>
              </div>
              <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                <span>Urban Garden Project</span>
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {formatDistanceToNow(new Date(project.updated_at), { addSuffix: true })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
