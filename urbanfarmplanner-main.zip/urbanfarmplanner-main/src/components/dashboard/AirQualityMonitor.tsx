import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Wind, 
  Droplets, 
  Thermometer, 
  Leaf,
  TrendingUp,
  TrendingDown,
  Activity,
  AlertTriangle,
  CheckCircle2
} from "lucide-react";

interface AirQualityMonitorProps {
  totalPlants: number;
}

interface AirQualityData {
  co2: number;
  humidity: number;
  temperature: number;
  airQualityIndex: number;
  oxygenLevel: number;
}

// Simulate real-time air quality based on plant count
const calculateAirQuality = (plantCount: number): AirQualityData => {
  // Base CO2 level (outdoor ~400ppm, indoor typically 600-1000ppm)
  // Each plant reduces CO2 by ~10-20ppm
  const baseCO2 = 800;
  const co2Reduction = plantCount * 15;
  const co2 = Math.max(350, baseCO2 - co2Reduction);

  // Humidity is slightly increased by plants (transpiration)
  const baseHumidity = 45;
  const humidityIncrease = Math.min(20, plantCount * 2);
  const humidity = baseHumidity + humidityIncrease;

  // Temperature simulation (plants have minimal impact)
  const temperature = 22 + Math.random() * 3;

  // Air Quality Index (0-100, higher is better)
  // Based on CO2, humidity, and plant presence
  let aqi = 50;
  if (co2 < 600) aqi += 25;
  else if (co2 < 800) aqi += 15;
  else if (co2 > 1000) aqi -= 20;
  
  if (humidity >= 40 && humidity <= 60) aqi += 15;
  else if (humidity < 30 || humidity > 70) aqi -= 10;
  
  aqi += Math.min(25, plantCount * 2);
  aqi = Math.max(0, Math.min(100, aqi));

  // Oxygen level (normal is ~21%, plants increase slightly)
  const oxygenLevel = 20.9 + (plantCount * 0.01);

  return { co2, humidity, temperature, airQualityIndex: Math.round(aqi), oxygenLevel };
};

const getAQIStatus = (aqi: number) => {
  if (aqi >= 80) return { label: "Excellent", color: "text-forest", bg: "bg-forest/10", icon: CheckCircle2 };
  if (aqi >= 60) return { label: "Good", color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 };
  if (aqi >= 40) return { label: "Moderate", color: "text-amber-500", bg: "bg-amber-500/10", icon: Activity };
  return { label: "Poor", color: "text-destructive", bg: "bg-destructive/10", icon: AlertTriangle };
};

const getCO2Status = (co2: number) => {
  if (co2 < 600) return { label: "Excellent", color: "text-forest" };
  if (co2 < 800) return { label: "Good", color: "text-primary" };
  if (co2 < 1000) return { label: "Moderate", color: "text-amber-500" };
  return { label: "High", color: "text-destructive" };
};

const getHumidityStatus = (humidity: number) => {
  if (humidity >= 40 && humidity <= 60) return { label: "Optimal", color: "text-forest" };
  if (humidity >= 30 && humidity <= 70) return { label: "Acceptable", color: "text-amber-500" };
  return { label: "Adjust", color: "text-destructive" };
};

export function AirQualityMonitor({ totalPlants }: AirQualityMonitorProps) {
  const [data, setData] = useState<AirQualityData>(calculateAirQuality(totalPlants));
  const [trend, setTrend] = useState<"up" | "down" | "stable">("stable");

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newData = calculateAirQuality(totalPlants);
      setData(prev => {
        if (newData.airQualityIndex > prev.airQualityIndex) setTrend("up");
        else if (newData.airQualityIndex < prev.airQualityIndex) setTrend("down");
        else setTrend("stable");
        return newData;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [totalPlants]);

  // Update immediately when plant count changes
  useEffect(() => {
    setData(calculateAirQuality(totalPlants));
  }, [totalPlants]);

  const aqiStatus = getAQIStatus(data.airQualityIndex);
  const co2Status = getCO2Status(data.co2);
  const humidityStatus = getHumidityStatus(data.humidity);
  const StatusIcon = aqiStatus.icon;

  return (
    <Card className="shadow-card overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Activity className="h-5 w-5 text-primary" />
            Air Quality Monitor
          </CardTitle>
          <Badge className={`${aqiStatus.bg} ${aqiStatus.color} border-0`}>
            <StatusIcon className="h-3 w-3 mr-1" />
            {aqiStatus.label}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Main AQI Display */}
        <div className={`rounded-xl ${aqiStatus.bg} p-4 text-center`}>
          <div className="flex items-center justify-center gap-2">
            <span className={`text-4xl font-bold ${aqiStatus.color}`}>
              {data.airQualityIndex}
            </span>
            {trend === "up" && <TrendingUp className="h-5 w-5 text-forest" />}
            {trend === "down" && <TrendingDown className="h-5 w-5 text-destructive" />}
          </div>
          <p className="text-sm text-muted-foreground mt-1">Air Quality Index</p>
          <div className="mt-3">
            <Progress value={data.airQualityIndex} className="h-2" />
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 gap-3">
          {/* CO2 Level */}
          <div className="rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted">
                  <Wind className="h-4 w-4 text-muted-foreground" />
                </div>
                <span className="text-xs font-medium text-muted-foreground">CO₂</span>
              </div>
              <Badge variant="outline" className={`text-[10px] ${co2Status.color}`}>
                {co2Status.label}
              </Badge>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-bold">{data.co2}</span>
              <span className="text-xs text-muted-foreground">ppm</span>
            </div>
            <Progress 
              value={Math.max(0, 100 - ((data.co2 - 400) / 6))} 
              className="h-1.5" 
            />
          </div>

          {/* Humidity */}
          <div className="rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/10">
                  <Droplets className="h-4 w-4 text-blue-500" />
                </div>
                <span className="text-xs font-medium text-muted-foreground">Humidity</span>
              </div>
              <Badge variant="outline" className={`text-[10px] ${humidityStatus.color}`}>
                {humidityStatus.label}
              </Badge>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-bold">{data.humidity}</span>
              <span className="text-xs text-muted-foreground">%</span>
            </div>
            <Progress value={data.humidity} className="h-1.5" />
          </div>

          {/* Temperature */}
          <div className="rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/10">
                <Thermometer className="h-4 w-4 text-amber-500" />
              </div>
              <span className="text-xs font-medium text-muted-foreground">Temperature</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-bold">{data.temperature.toFixed(1)}</span>
              <span className="text-xs text-muted-foreground">°C</span>
            </div>
          </div>

          {/* Oxygen Level */}
          <div className="rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-forest/10">
                <Leaf className="h-4 w-4 text-forest" />
              </div>
              <span className="text-xs font-medium text-muted-foreground">Oxygen</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-bold">{data.oxygenLevel.toFixed(2)}</span>
              <span className="text-xs text-muted-foreground">%</span>
            </div>
          </div>
        </div>

        {/* Plant Impact */}
        <div className="rounded-lg bg-muted/50 p-3">
          <div className="flex items-center gap-2 text-sm">
            <Leaf className="h-4 w-4 text-forest" />
            <span className="font-medium">Plant Impact</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {totalPlants === 0 
              ? "Add plants to improve indoor air quality and reduce CO₂ levels."
              : `Your ${totalPlants} plant${totalPlants > 1 ? 's are' : ' is'} reducing CO₂ by ~${totalPlants * 15}ppm and improving air quality.`
            }
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-2 text-[10px] text-muted-foreground">
          <div className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-full bg-forest" />
            <span>Excellent (80-100)</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-full bg-primary" />
            <span>Good (60-79)</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-full bg-amber-500" />
            <span>Moderate (40-59)</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-full bg-destructive" />
            <span>Poor (&lt;40)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
