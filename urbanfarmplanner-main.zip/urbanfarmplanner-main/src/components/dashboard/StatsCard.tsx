import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: "default" | "primary" | "accent";
}

export function StatsCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  trend,
  variant = "default" 
}: StatsCardProps) {
  return (
    <div className={cn(
      "group relative overflow-hidden rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 shadow-card",
      variant === "default" && "bg-card",
      variant === "primary" && "bg-gradient-primary text-primary-foreground",
      variant === "accent" && "bg-gradient-accent text-accent-foreground"
    )}>
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <p className={cn(
            "text-sm font-medium",
            variant === "default" ? "text-muted-foreground" : "opacity-80"
          )}>
            {title}
          </p>
          <p className="text-3xl font-bold tracking-tight">{value}</p>
          {subtitle && (
            <p className={cn(
              "text-xs",
              variant === "default" ? "text-muted-foreground" : "opacity-70"
            )}>
              {subtitle}
            </p>
          )}
          {trend && (
            <div className={cn(
              "flex items-center gap-1 text-xs font-medium",
              trend.isPositive ? "text-forest-light" : "text-destructive"
            )}>
              <span>{trend.isPositive ? "↑" : "↓"} {Math.abs(trend.value)}%</span>
              <span className="opacity-70">vs last month</span>
            </div>
          )}
        </div>
        <div className={cn(
          "flex h-12 w-12 items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-110",
          variant === "default" && "bg-primary/10",
          variant === "primary" && "bg-primary-foreground/20",
          variant === "accent" && "bg-accent-foreground/20"
        )}>
          <Icon className={cn(
            "h-6 w-6",
            variant === "default" && "text-primary"
          )} />
        </div>
      </div>
    </div>
  );
}
