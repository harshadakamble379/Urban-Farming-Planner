import { useState, useEffect } from "react";
import { Bell, BellOff, BellRing } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useNotifications } from "@/hooks/useNotifications";

export function NotificationToggle() {
  const { requestPermission, isSupported, permission, checkOverdueReminders } = useNotifications();
  const [currentPermission, setCurrentPermission] = useState(permission);

  useEffect(() => {
    setCurrentPermission(permission);
  }, [permission]);

  const handleEnableNotifications = async () => {
    if (!isSupported) {
      toast.error("Your browser doesn't support notifications");
      return;
    }

    const granted = await requestPermission();
    if (granted) {
      setCurrentPermission("granted");
      toast.success("Notifications enabled! You'll be notified about overdue plant care.");
      // Check immediately for any overdue reminders
      checkOverdueReminders();
    } else {
      toast.error("Notification permission denied. Please enable in browser settings.");
    }
  };

  if (!isSupported) {
    return null;
  }

  if (currentPermission === "granted") {
    return (
      <Button
        variant="ghost"
        size="sm"
        className="gap-2 text-primary"
        onClick={() => toast.info("Notifications are enabled")}
      >
        <BellRing className="h-4 w-4" />
        <span className="hidden sm:inline">Notifications On</span>
      </Button>
    );
  }

  return (
    <Button
      variant="outline"
      size="sm"
      className="gap-2"
      onClick={handleEnableNotifications}
    >
      <Bell className="h-4 w-4" />
      <span className="hidden sm:inline">Enable Notifications</span>
    </Button>
  );
}
