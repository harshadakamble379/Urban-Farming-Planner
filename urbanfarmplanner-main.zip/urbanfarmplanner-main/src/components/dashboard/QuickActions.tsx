import { useNavigate } from "react-router-dom";
import { Plus, FileText, Calculator, Leaf, Bell, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function QuickActions() {
  const navigate = useNavigate();

  const createNewProject = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please log in to create a project");
      return;
    }

    const { data, error } = await supabase
      .from("projects")
      .insert({
        user_id: user.id,
        name: `New Garden ${new Date().toLocaleDateString()}`,
        grid_items: [],
        plot_config: { unit: "meters", width: 10, height: 8, cellSize: 40 },
      })
      .select()
      .single();

    if (error) {
      toast.error("Failed to create project");
      console.error(error);
    } else {
      toast.success("Project created!");
      navigate(`/planning?project=${data.id}`);
    }
  };

  const generateReport = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please log in to generate a report");
      return;
    }

    const { data: projects } = await supabase
      .from("projects")
      .select("*")
      .eq("user_id", user.id);

    const { data: reminders } = await supabase
      .from("plant_reminders")
      .select("*")
      .eq("user_id", user.id);

    const totalPlants = (projects || []).reduce((sum, p) => {
      const items = Array.isArray(p.grid_items) ? p.grid_items : [];
      return sum + items.length;
    }, 0);

    const report = {
      generatedAt: new Date().toISOString(),
      summary: {
        totalProjects: projects?.length || 0,
        totalPlants,
        activeReminders: reminders?.filter((r: any) => r.is_active).length || 0,
      },
      projects: projects || [],
      reminders: reminders || [],
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `garden-report-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success("Report generated and downloaded!");
  };

  const actions = [
    { 
      icon: Plus, 
      label: "New Project", 
      description: "Start a new garden plan",
      onClick: createNewProject,
    },
    { 
      icon: FileText, 
      label: "Generate Report", 
      description: "Export project data",
      onClick: generateReport,
    },
    { 
      icon: Leaf, 
      label: "Browse Plants", 
      description: "Explore plant database",
      onClick: () => navigate("/plants"),
    },
    { 
      icon: Bell, 
      label: "Manage Reminders", 
      description: "Set care schedules",
      onClick: () => navigate("/planning"),
    },
    { 
      icon: Settings, 
      label: "Settings", 
      description: "Manage preferences",
      onClick: () => navigate("/settings"),
    },
  ];

  return (
    <div className="rounded-2xl bg-card p-6 shadow-card">
      <h3 className="mb-4 text-lg font-semibold text-foreground">Quick Actions</h3>
      <div className="grid gap-3">
        {actions.map((action) => (
          <Button
            key={action.label}
            variant="ghost"
            className="h-auto justify-start gap-4 p-4 hover:bg-secondary"
            onClick={action.onClick}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <action.icon className="h-5 w-5 text-primary" />
            </div>
            <div className="text-left">
              <p className="font-medium text-foreground">{action.label}</p>
              <p className="text-xs text-muted-foreground">{action.description}</p>
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
}
