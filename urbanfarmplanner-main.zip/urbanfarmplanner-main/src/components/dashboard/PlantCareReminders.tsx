import { useState, useEffect } from "react";
import { Droplets, Bell, Check, Plus, Trash2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDistanceToNow, isPast, addDays } from "date-fns";

interface Reminder {
  id: string;
  plant_name: string;
  reminder_type: string;
  schedule_days: number;
  last_completed_at: string | null;
  next_due_at: string;
  is_active: boolean;
  notes: string | null;
}

const reminderTypes = [
  { value: "watering", label: "Watering", icon: Droplets },
  { value: "fertilizing", label: "Fertilizing", icon: Bell },
  { value: "pruning", label: "Pruning", icon: Bell },
  { value: "repotting", label: "Repotting", icon: Bell },
];

const plantOptions = [
  "Peace Lily",
  "Jasmine",
  "Orchid",
  "Lavender",
  "Gerbera Daisy",
  "Areca Palm",
  "Snake Plant",
  "Money Plant",
  "Aloe Vera",
  "Spider Plant",
  "Boston Fern",
  "Rubber Plant",
];

export function PlantCareReminders() {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newReminder, setNewReminder] = useState({
    plant_name: "",
    reminder_type: "watering",
    schedule_days: 3,
    notes: "",
  });

  useEffect(() => {
    loadReminders();
  }, []);

  const loadReminders = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from("plant_reminders")
      .select("*")
      .eq("user_id", user.id)
      .order("next_due_at", { ascending: true });

    if (error) {
      console.error("Error loading reminders:", error);
    } else {
      setReminders(data || []);
    }
    setLoading(false);
  };

  const addReminder = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Please log in to add reminders");
      return;
    }

    if (!newReminder.plant_name) {
      toast.error("Please select a plant");
      return;
    }

    const nextDue = addDays(new Date(), newReminder.schedule_days);

    const { error } = await supabase.from("plant_reminders").insert({
      user_id: user.id,
      plant_name: newReminder.plant_name,
      reminder_type: newReminder.reminder_type,
      schedule_days: newReminder.schedule_days,
      next_due_at: nextDue.toISOString(),
      notes: newReminder.notes || null,
    });

    if (error) {
      toast.error("Failed to add reminder");
      console.error(error);
    } else {
      toast.success("Reminder added!");
      setDialogOpen(false);
      setNewReminder({ plant_name: "", reminder_type: "watering", schedule_days: 3, notes: "" });
      loadReminders();
    }
  };

  const completeReminder = async (reminder: Reminder) => {
    const nextDue = addDays(new Date(), reminder.schedule_days);

    const { error } = await supabase
      .from("plant_reminders")
      .update({
        last_completed_at: new Date().toISOString(),
        next_due_at: nextDue.toISOString(),
      })
      .eq("id", reminder.id);

    if (error) {
      toast.error("Failed to update reminder");
    } else {
      toast.success(`${reminder.plant_name} ${reminder.reminder_type} completed!`);
      loadReminders();
    }
  };

  const deleteReminder = async (id: string) => {
    const { error } = await supabase.from("plant_reminders").delete().eq("id", id);

    if (error) {
      toast.error("Failed to delete reminder");
    } else {
      toast.success("Reminder deleted");
      loadReminders();
    }
  };

  const overdueReminders = reminders.filter((r) => isPast(new Date(r.next_due_at)));
  const upcomingReminders = reminders.filter((r) => !isPast(new Date(r.next_due_at)));

  return (
    <div className="rounded-2xl bg-card p-6 shadow-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Bell className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Plant Care Reminders</h3>
            {overdueReminders.length > 0 && (
              <p className="text-sm text-destructive">{overdueReminders.length} overdue</p>
            )}
          </div>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline" className="gap-2">
              <Plus className="h-4 w-4" />
              Add
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Care Reminder</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Plant</Label>
                <Select
                  value={newReminder.plant_name}
                  onValueChange={(v) => setNewReminder({ ...newReminder, plant_name: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a plant" />
                  </SelectTrigger>
                  <SelectContent>
                    {plantOptions.map((plant) => (
                      <SelectItem key={plant} value={plant}>
                        {plant}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Reminder Type</Label>
                <Select
                  value={newReminder.reminder_type}
                  onValueChange={(v) => setNewReminder({ ...newReminder, reminder_type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {reminderTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Repeat Every (days)</Label>
                <Input
                  type="number"
                  min={1}
                  value={newReminder.schedule_days}
                  onChange={(e) =>
                    setNewReminder({ ...newReminder, schedule_days: parseInt(e.target.value) || 1 })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Notes (optional)</Label>
                <Input
                  value={newReminder.notes}
                  onChange={(e) => setNewReminder({ ...newReminder, notes: e.target.value })}
                  placeholder="e.g., Use filtered water"
                />
              </div>

              <Button onClick={addReminder} className="w-full">
                Add Reminder
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <ScrollArea className="h-[280px]">
        {loading ? (
          <div className="text-center text-muted-foreground py-8">Loading...</div>
        ) : reminders.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <Bell className="h-12 w-12 mx-auto mb-2 opacity-30" />
            <p>No reminders yet</p>
            <p className="text-sm">Add a reminder to track plant care</p>
          </div>
        ) : (
          <div className="space-y-3">
            {overdueReminders.map((reminder) => (
              <ReminderCard
                key={reminder.id}
                reminder={reminder}
                isOverdue
                onComplete={() => completeReminder(reminder)}
                onDelete={() => deleteReminder(reminder.id)}
              />
            ))}
            {upcomingReminders.map((reminder) => (
              <ReminderCard
                key={reminder.id}
                reminder={reminder}
                isOverdue={false}
                onComplete={() => completeReminder(reminder)}
                onDelete={() => deleteReminder(reminder.id)}
              />
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

function ReminderCard({
  reminder,
  isOverdue,
  onComplete,
  onDelete,
}: {
  reminder: Reminder;
  isOverdue: boolean;
  onComplete: () => void;
  onDelete: () => void;
}) {
  const typeInfo = reminderTypes.find((t) => t.value === reminder.reminder_type);
  const Icon = typeInfo?.icon || Bell;

  return (
    <div
      className={`flex items-center gap-3 rounded-lg border p-3 ${
        isOverdue ? "border-destructive/50 bg-destructive/5" : "border-border"
      }`}
    >
      <div
        className={`flex h-9 w-9 items-center justify-center rounded-lg ${
          isOverdue ? "bg-destructive/10" : "bg-primary/10"
        }`}
      >
        <Icon className={`h-4 w-4 ${isOverdue ? "text-destructive" : "text-primary"}`} />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="font-medium text-foreground truncate">{reminder.plant_name}</p>
          <Badge variant={isOverdue ? "destructive" : "secondary"} className="text-xs">
            {typeInfo?.label}
          </Badge>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          {isOverdue
            ? `Overdue by ${formatDistanceToNow(new Date(reminder.next_due_at))}`
            : `Due ${formatDistanceToNow(new Date(reminder.next_due_at), { addSuffix: true })}`}
        </div>
      </div>

      <div className="flex gap-1">
        <Button
          size="icon"
          variant="ghost"
          className="h-8 w-8 text-primary hover:bg-primary/10"
          onClick={onComplete}
        >
          <Check className="h-4 w-4" />
        </Button>
        <Button
          size="icon"
          variant="ghost"
          className="h-8 w-8 text-destructive hover:bg-destructive/10"
          onClick={onDelete}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
