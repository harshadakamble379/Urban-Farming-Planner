import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { CalendarDays, Leaf } from "lucide-react";
import { format, addDays, startOfDay, differenceInDays } from "date-fns";
import { getPlantInfo, getHarvestDate } from "@/data/plantData";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface HarvestTimelineProps {
  gridItems: PlantItem[];
  getPlantColor: (type: string) => string;
}

export const HarvestTimeline = ({ gridItems, getPlantColor }: HarvestTimelineProps) => {
  const today = startOfDay(new Date());
  
  // Get harvest events
  const harvestEvents = gridItems
    .filter(item => item.plantedAt)
    .map(item => {
      const plantInfo = getPlantInfo(item.name);
      if (!plantInfo) return null;
      
      const harvestDate = getHarvestDate(item.plantedAt!, plantInfo.daysToHarvest);
      const daysFromNow = differenceInDays(harvestDate, today);
      
      return {
        ...item,
        plantInfo,
        harvestDate,
        daysFromNow,
      };
    })
    .filter(Boolean)
    .filter(event => event!.daysFromNow >= 0 && event!.daysFromNow <= 90)
    .sort((a, b) => a!.daysFromNow - b!.daysFromNow);

  // Group by week
  const weeks: { weekStart: Date; events: typeof harvestEvents }[] = [];
  for (let i = 0; i < 13; i++) {
    const weekStart = addDays(today, i * 7);
    const weekEnd = addDays(weekStart, 6);
    const weekEvents = harvestEvents.filter(event => {
      if (!event) return false;
      const harvestDay = startOfDay(event.harvestDate);
      return harvestDay >= weekStart && harvestDay <= weekEnd;
    });
    weeks.push({ weekStart, events: weekEvents });
  }

  if (harvestEvents.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <CalendarDays className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Harvest Timeline</h3>
        </div>
        <p className="text-xs text-muted-foreground text-center py-4">
          Plant crops to see your harvest schedule!
        </p>
      </div>
    );
  }

  // Find upcoming harvests (next 7 days)
  const upcomingHarvests = harvestEvents.filter(e => e && e.daysFromNow <= 7);

  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <div className="flex items-center gap-2 mb-3">
        <CalendarDays className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Harvest Timeline</h3>
      </div>

      {/* Upcoming alerts */}
      {upcomingHarvests.length > 0 && (
        <div className="mb-4 p-3 rounded-lg bg-primary/10 border border-primary/20">
          <p className="text-xs font-medium text-primary mb-2">Ready Soon!</p>
          <div className="flex flex-wrap gap-2">
            {upcomingHarvests.map(event => event && (
              <Badge 
                key={event.id}
                variant="secondary"
                className="text-xs"
              >
                {event.name} - {event.daysFromNow === 0 ? "Today!" : `${event.daysFromNow}d`}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Timeline scroll */}
      <ScrollArea className="w-full">
        <div className="flex gap-2 pb-4">
          {weeks.map((week, index) => {
            const isThisWeek = index === 0;
            const hasEvents = week.events.length > 0;
            
            return (
              <div 
                key={index}
                className={`flex-shrink-0 w-24 rounded-lg border p-2 transition-all ${
                  isThisWeek 
                    ? "border-primary bg-primary/5" 
                    : hasEvents 
                      ? "border-border bg-secondary/30" 
                      : "border-border/50 bg-transparent"
                }`}
              >
                <p className="text-xs font-medium text-center mb-1">
                  {isThisWeek ? "This Week" : format(week.weekStart, "MMM d")}
                </p>
                
                {hasEvents ? (
                  <div className="space-y-1">
                    {week.events.slice(0, 3).map(event => event && (
                      <div 
                        key={event.id}
                        className="flex items-center gap-1 p-1 rounded bg-background/50"
                      >
                        <div 
                          className="h-2 w-2 rounded-full"
                          style={{ 
                            backgroundColor: `hsl(var(--${getPlantColor(event.type)}))`
                          }}
                        />
                        <span className="text-xs truncate">{event.name}</span>
                      </div>
                    ))}
                    {week.events.length > 3 && (
                      <p className="text-xs text-muted-foreground text-center">
                        +{week.events.length - 3} more
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground text-center py-2">—</p>
                )}
              </div>
            );
          })}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>

      {/* Summary */}
      <div className="mt-3 pt-3 border-t border-border">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Total harvests in 90 days:</span>
          <span className="font-medium">{harvestEvents.length} crops</span>
        </div>
      </div>
    </div>
  );
};
