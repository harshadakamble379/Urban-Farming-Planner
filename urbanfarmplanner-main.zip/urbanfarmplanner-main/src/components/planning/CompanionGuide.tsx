import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  HeartOff, 
  Lightbulb,
  AlertTriangle,
  CheckCircle2
} from "lucide-react";
import { getPlantInfo } from "@/data/plantData";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface CompanionPair {
  plant1: string;
  plant2: string;
  type: "good" | "bad";
  distance: number;
}

interface CompanionGuideProps {
  gridItems: PlantItem[];
  getPlantColor: (type: string) => string;
}

export function CompanionGuide({ gridItems, getPlantColor }: CompanionGuideProps) {
  const analysis = useMemo(() => {
    const goodPairs: CompanionPair[] = [];
    const badPairs: CompanionPair[] = [];
    const suggestions: string[] = [];
    const plantedNames = [...new Set(gridItems.map(item => item.name))];

    // Check all planted pairs for compatibility
    for (let i = 0; i < gridItems.length; i++) {
      for (let j = i + 1; j < gridItems.length; j++) {
        const plant1 = gridItems[i];
        const plant2 = gridItems[j];
        
        if (plant1.name === plant2.name) continue;

        const info1 = getPlantInfo(plant1.name);
        const info2 = getPlantInfo(plant2.name);
        
        if (!info1 || !info2) continue;

        // Calculate distance between plants
        const distance = Math.sqrt(
          Math.pow(plant1.x - plant2.x, 2) + Math.pow(plant1.y - plant2.y, 2)
        );

        // Check if they're companions (within 3 cells)
        if (distance <= 3) {
          if (info1.companions.includes(plant2.name)) {
            const existingGood = goodPairs.find(
              p => (p.plant1 === plant1.name && p.plant2 === plant2.name) ||
                   (p.plant1 === plant2.name && p.plant2 === plant1.name)
            );
            if (!existingGood) {
              goodPairs.push({ plant1: plant1.name, plant2: plant2.name, type: "good", distance });
            }
          }
          
          if (info1.incompatible.includes(plant2.name)) {
            const existingBad = badPairs.find(
              p => (p.plant1 === plant1.name && p.plant2 === plant2.name) ||
                   (p.plant1 === plant2.name && p.plant2 === plant1.name)
            );
            if (!existingBad) {
              badPairs.push({ plant1: plant1.name, plant2: plant2.name, type: "bad", distance });
            }
          }
        }
      }
    }

    // Generate suggestions for missing companions
    plantedNames.forEach(name => {
      const info = getPlantInfo(name);
      if (!info) return;

      info.companions.forEach(companion => {
        if (!plantedNames.includes(companion)) {
          const suggestionText = `${companion} grows well with ${name}`;
          if (!suggestions.includes(suggestionText)) {
            suggestions.push(suggestionText);
          }
        }
      });
    });

    return {
      goodPairs: goodPairs.slice(0, 5),
      badPairs,
      suggestions: suggestions.slice(0, 3),
      score: goodPairs.length > 0 || badPairs.length === 0 ? 
        Math.max(0, 100 - badPairs.length * 20 + goodPairs.length * 10) : 50
    };
  }, [gridItems]);

  if (gridItems.length === 0) {
    return (
      <Card className="border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Heart className="h-4 w-4 text-primary" />
            Companion Planting
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-4">
            Add plants to see companion recommendations
          </p>
        </CardContent>
      </Card>
    );
  }

  const scoreColor = analysis.score >= 80 ? "text-green-500" : 
                     analysis.score >= 50 ? "text-amber-500" : "text-red-500";

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Heart className="h-4 w-4 text-primary" />
            Companion Planting
          </CardTitle>
          <Badge variant="outline" className={scoreColor}>
            Score: {Math.min(100, analysis.score)}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Incompatible Warnings */}
        {analysis.badPairs.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-3.5 w-3.5 text-red-500" />
              <span className="text-xs font-medium text-red-500 uppercase tracking-wide">
                Incompatible Pairings
              </span>
            </div>
            <div className="space-y-1">
              {analysis.badPairs.map((pair, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 p-2 rounded-lg bg-red-500/10 text-sm"
                >
                  <HeartOff className="h-4 w-4 text-red-500 shrink-0" />
                  <span className="text-red-600 dark:text-red-400">
                    {pair.plant1} & {pair.plant2} don't grow well together
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Good Companions */}
        {analysis.goodPairs.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />
              <span className="text-xs font-medium text-green-600 dark:text-green-400 uppercase tracking-wide">
                Good Pairings
              </span>
            </div>
            <div className="space-y-1">
              {analysis.goodPairs.map((pair, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 p-2 rounded-lg bg-green-500/10 text-sm"
                >
                  <Heart className="h-4 w-4 text-green-500 shrink-0" />
                  <span className="text-green-600 dark:text-green-400">
                    {pair.plant1} & {pair.plant2} grow well together
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Suggestions */}
        {analysis.suggestions.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-border/50">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-3.5 w-3.5 text-amber-500" />
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Suggestions
              </span>
            </div>
            <div className="space-y-1">
              {analysis.suggestions.map((suggestion, idx) => (
                <p key={idx} className="text-sm text-muted-foreground pl-6">
                  • {suggestion}
                </p>
              ))}
            </div>
          </div>
        )}

        {analysis.goodPairs.length === 0 && analysis.badPairs.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-2">
            Add more plants to see companion recommendations
          </p>
        )}
      </CardContent>
    </Card>
  );
}