import { useMemo, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  IndianRupee, 
  Leaf, 
  Package, 
  Droplets,
  Shovel,
  Box,
  TrendingDown,
  Loader2,
  Target,
  AlertTriangle,
  CheckCircle2,
  Edit2,
  X
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface InventoryItem {
  id: string;
  name: string;
  price: number;
  category: string;
}

interface CostEstimationProps {
  gridItems: PlantItem[];
}

const categoryIcons: Record<string, typeof Leaf> = {
  seeds: Leaf,
  soil: Package,
  fertilizer: Droplets,
  tools: Shovel,
  containers: Box,
};

const categoryLabels: Record<string, string> = {
  seeds: "Seeds & Plants",
  soil: "Soil & Substrate",
  fertilizer: "Fertilizers",
  tools: "Tools",
  containers: "Containers",
};

// Map plant names to inventory item patterns
const plantToInventoryMap: Record<string, string[]> = {
  "Tomatoes": ["Tomato Seeds"],
  "Peppers": ["Chili Seeds"],
  "Carrots": ["Carrot Seeds"],
  "Basil": ["Basil Seeds"],
  "Mint": ["Mint Seeds"],
  "Rosemary": ["Rosemary Seeds"],
  "Lettuce": ["Lettuce Seeds"],
  "Spinach": ["Spinach Seeds"],
  "Strawberries": ["Strawberry Seeds"],
};

const formatINR = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export function CostEstimation({ gridItems }: CostEstimationProps) {
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [budget, setBudget] = useState<number>(() => {
    const saved = localStorage.getItem('garden-budget');
    return saved ? parseFloat(saved) : 0;
  });
  const [editingBudget, setEditingBudget] = useState(false);
  const [budgetInput, setBudgetInput] = useState('');

  useEffect(() => {
    const fetchInventory = async () => {
      // Explicitly select only needed columns to exclude user_id for privacy
      const { data, error } = await supabase
        .from("inventory_items")
        .select("id, name, price, category");

      if (!error && data) {
        setInventoryItems(data);
      }
      setLoading(false);
    };

    fetchInventory();
  }, []);

  const handleSetBudget = () => {
    const value = parseFloat(budgetInput);
    if (!isNaN(value) && value >= 0 && value <= 10000000) {
      setBudget(value);
      localStorage.setItem('garden-budget', value.toString());
      setEditingBudget(false);
      setBudgetInput('');
    }
  };

  const handleClearBudget = () => {
    setBudget(0);
    localStorage.removeItem('garden-budget');
    setEditingBudget(false);
  };

  const costBreakdown = useMemo(() => {
    const costs: Record<string, number> = {
      seeds: 0,
      soil: 0,
      fertilizer: 0,
      tools: 0,
      containers: 0,
    };

    const plantCounts = new Map<string, number>();
    gridItems.forEach(item => {
      plantCounts.set(item.name, (plantCounts.get(item.name) || 0) + 1);
    });

    plantCounts.forEach((count, plantName) => {
      // Find matching inventory items
      const possibleNames = plantToInventoryMap[plantName] || [plantName, `${plantName} Seeds`];
      
      for (const itemName of possibleNames) {
        const inventoryItem = inventoryItems.find(
          inv => inv.name.toLowerCase().includes(itemName.toLowerCase()) ||
                 itemName.toLowerCase().includes(inv.name.toLowerCase().replace(' seeds', ''))
        );
        
        if (inventoryItem) {
          const category = inventoryItem.category.toLowerCase();
          if (category.includes('seed')) {
            costs.seeds += inventoryItem.price * count;
          } else if (category.includes('soil') || category.includes('compost')) {
            costs.soil += inventoryItem.price * count;
          } else if (category.includes('fertilizer')) {
            costs.fertilizer += inventoryItem.price * count;
          } else if (category.includes('tool')) {
            costs.tools += inventoryItem.price * count;
          } else if (category.includes('pot') || category.includes('container')) {
            costs.containers += inventoryItem.price * count;
          } else {
            costs.seeds += inventoryItem.price * count;
          }
          break;
        }
      }
    });

    // Add essential supplies from inventory if plants exist
    const totalPlants = gridItems.length;
    if (totalPlants > 0) {
      // Find soil/compost from inventory
      const soilItem = inventoryItems.find(inv => 
        inv.category.toLowerCase().includes('soil') || 
        inv.name.toLowerCase().includes('compost')
      );
      if (soilItem) {
        costs.soil += soilItem.price * Math.ceil(totalPlants / 5);
      }

      // Find fertilizer from inventory
      const fertilizerItem = inventoryItems.find(inv => 
        inv.category.toLowerCase().includes('fertilizer') ||
        inv.name.toLowerCase().includes('fertilizer')
      );
      if (fertilizerItem) {
        costs.fertilizer += fertilizerItem.price * Math.ceil(totalPlants / 10);
      }

      // Find tools from inventory
      const toolItems = inventoryItems.filter(inv => 
        inv.category.toLowerCase().includes('tool')
      );
      if (toolItems.length > 0) {
        // Add one-time tool costs
        toolItems.slice(0, 3).forEach(tool => {
          costs.tools += tool.price;
        });
      }
    }

    return costs;
  }, [gridItems, inventoryItems]);

  const totalCost = Object.values(costBreakdown).reduce((sum, cost) => sum + cost, 0);
  const maxCategoryCost = Math.max(...Object.values(costBreakdown), 1);

  const costPerPlant = gridItems.length > 0 ? totalCost / gridItems.length : 0;

  const sortedCategories = Object.entries(costBreakdown)
    .filter(([_, cost]) => cost > 0)
    .sort((a, b) => b[1] - a[1]);

  if (loading) {
    return (
      <Card className="shadow-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <IndianRupee className="h-5 w-5 text-primary" />
            Cost Estimation
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (gridItems.length === 0) {
    return (
      <Card className="shadow-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <IndianRupee className="h-5 w-5 text-primary" />
            Cost Estimation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-4">
            Add plants to see cost breakdown
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <IndianRupee className="h-5 w-5 text-primary" />
          Cost Estimation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Budget Tracker */}
        <div className={`rounded-xl p-4 border ${
          budget > 0 
            ? totalCost > budget 
              ? 'bg-destructive/10 border-destructive/30' 
              : totalCost >= budget * 0.8 
                ? 'bg-amber-500/10 border-amber-500/30'
                : 'bg-emerald-500/10 border-emerald-500/30'
            : 'bg-muted/50 border-border'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">Budget Tracker</span>
            </div>
            {!editingBudget && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 text-xs"
                onClick={() => {
                  setEditingBudget(true);
                  setBudgetInput(budget > 0 ? budget.toString() : '');
                }}
              >
                <Edit2 className="h-3 w-3 mr-1" />
                {budget > 0 ? 'Edit' : 'Set Budget'}
              </Button>
            )}
          </div>

          {editingBudget ? (
            <div className="flex gap-2">
              <div className="relative flex-1">
                <IndianRupee className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="number"
                  placeholder="Enter budget..."
                  value={budgetInput}
                  onChange={(e) => setBudgetInput(e.target.value)}
                  className="h-8 pl-7 text-sm"
                  min={0}
                  max={10000000}
                  onKeyDown={(e) => e.key === 'Enter' && handleSetBudget()}
                />
              </div>
              <Button size="sm" className="h-8" onClick={handleSetBudget}>
                Save
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-8"
                onClick={() => setEditingBudget(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : budget > 0 ? (
            <>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-muted-foreground">
                  {formatINR(totalCost)} of {formatINR(budget)}
                </span>
                <div className="flex items-center gap-1">
                  {totalCost > budget ? (
                    <>
                      <AlertTriangle className="h-4 w-4 text-destructive" />
                      <span className="text-destructive font-medium">
                        Over by {formatINR(totalCost - budget)}
                      </span>
                    </>
                  ) : totalCost >= budget * 0.8 ? (
                    <>
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                      <span className="text-amber-600 font-medium">
                        {formatINR(budget - totalCost)} left
                      </span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      <span className="text-emerald-600 font-medium">
                        {formatINR(budget - totalCost)} left
                      </span>
                    </>
                  )}
                </div>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-300 ${
                    totalCost > budget 
                      ? 'bg-destructive' 
                      : totalCost >= budget * 0.8 
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.min(100, (totalCost / budget) * 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>{Math.round((totalCost / budget) * 100)}% used</span>
                <button 
                  className="hover:text-destructive transition-colors"
                  onClick={handleClearBudget}
                >
                  Clear budget
                </button>
              </div>
            </>
          ) : (
            <p className="text-xs text-muted-foreground">
              Set a budget to track your garden spending
            </p>
          )}
        </div>

        {/* Total Cost */}
        <div className="rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 p-4 border border-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Estimated Total</p>
              <p className="text-3xl font-bold text-foreground">
                {formatINR(totalCost)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Per Plant</p>
              <p className="text-lg font-semibold text-primary">
                {formatINR(costPerPlant)}
              </p>
            </div>
          </div>
        </div>

        {/* Cost Breakdown by Category */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground">Cost Breakdown</h4>
          {sortedCategories.map(([category, cost]) => {
            const Icon = categoryIcons[category] || Package;
            const percentage = (cost / totalCost) * 100;
            const barWidth = (cost / maxCategoryCost) * 100;
            
            return (
              <div key={category} className="space-y-1.5">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                    <span>{categoryLabels[category] || category}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{formatINR(cost)}</span>
                    <Badge variant="outline" className="text-xs">
                      {percentage.toFixed(0)}%
                    </Badge>
                  </div>
                </div>
                <Progress value={barWidth} className="h-2" />
              </div>
            );
          })}
        </div>

        {/* Cost Tips */}
        <div className="rounded-lg bg-muted/50 p-3 space-y-2">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <TrendingDown className="h-4 w-4 text-forest" />
            Money-Saving Tips
          </h4>
          <ul className="text-xs text-muted-foreground space-y-1">
            {sortedCategories[0] && sortedCategories[0][0] === "containers" && (
              <li>• Consider reusing containers to reduce costs</li>
            )}
            {sortedCategories[0] && sortedCategories[0][0] === "soil" && (
              <li>• Buy soil in bulk for better prices</li>
            )}
            <li>• Save seeds from harvested plants for next season</li>
            <li>• Make compost to reduce fertilizer costs</li>
          </ul>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-3 pt-2 border-t border-border/50">
          <div className="text-center p-2 rounded-lg bg-secondary/30">
            <p className="text-2xl font-bold text-foreground">{gridItems.length}</p>
            <p className="text-xs text-muted-foreground">Plants</p>
          </div>
          <div className="text-center p-2 rounded-lg bg-secondary/30">
            <p className="text-2xl font-bold text-foreground">{sortedCategories.length}</p>
            <p className="text-xs text-muted-foreground">Categories</p>
          </div>
        </div>

        {/* Inventory Source Note */}
        <p className="text-xs text-muted-foreground text-center pt-2">
          Prices based on your inventory items
        </p>
      </CardContent>
    </Card>
  );
}