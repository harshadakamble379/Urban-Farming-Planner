import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Sun, 
  Leaf,
  Scale,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { plantData, PlantInfo } from "@/data/plantData";
import { MapMode } from "./PlanningCanvas";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface YieldPredictionProps {
  gridItems: PlantItem[];
  mapMode: MapMode;
  timeOfDay: number;
  getPlantColor: (type: string) => string;
}

interface YieldEstimate {
  plant: PlantInfo;
  quantity: number;
  yieldPerPlant: number;
  totalYield: number;
  unit: string;
  sunlightBonus: number;
  qualityRating: "excellent" | "good" | "fair" | "poor";
}

// Yield data per plant (oxygen output in ml/day, aesthetic value)
const yieldData: Record<string, { baseYield: number; unit: string }> = {
  "Peace Lily": { baseYield: 180, unit: "ml O₂/day" },
  "Jasmine": { baseYield: 150, unit: "ml O₂/day" },
  "Orchid": { baseYield: 100, unit: "ml O₂/day" },
  "Lavender": { baseYield: 120, unit: "ml O₂/day" },
  "Gerbera Daisy": { baseYield: 200, unit: "ml O₂/day" },
  "Areca Palm": { baseYield: 1800, unit: "ml O₂/day" },
  "Snake Plant": { baseYield: 250, unit: "ml O₂/day" },
  "Money Plant": { baseYield: 150, unit: "ml O₂/day" },
  "Aloe Vera": { baseYield: 180, unit: "ml O₂/day" },
  "Spider Plant": { baseYield: 200, unit: "ml O₂/day" },
  "Boston Fern": { baseYield: 220, unit: "ml O₂/day" },
  "Rubber Plant": { baseYield: 300, unit: "ml O₂/day" },
};

export const YieldPrediction = ({
  gridItems,
  mapMode,
  timeOfDay,
  getPlantColor,
}: YieldPredictionProps) => {
  const [isExpanded, setIsExpanded] = useState(true);

  // Calculate sunlight exposure factor based on map mode and time
  const getSunlightFactor = (plantName: string) => {
    const plant = plantData.find(p => p.name === plantName);
    if (!plant) return 1;

    // Calculate average daily sunlight hours based on map mode
    let sunlightHours = 8; // Default
    
    if (mapMode === "building") {
      // Building mode: rooftop gets most sun, balconies get less
      sunlightHours = 6;
    } else {
      // Street divider: depends on surrounding buildings
      sunlightHours = 5;
    }

    // Match with plant requirements
    if (plant.sunRequirement === "full" && sunlightHours >= 6) {
      return 1.0;
    } else if (plant.sunRequirement === "full" && sunlightHours < 6) {
      return 0.7;
    } else if (plant.sunRequirement === "partial") {
      return sunlightHours >= 4 ? 1.0 : 0.8;
    } else {
      return 1.0;
    }
  };

  const getQualityRating = (sunlightFactor: number): "excellent" | "good" | "fair" | "poor" => {
    if (sunlightFactor >= 0.95) return "excellent";
    if (sunlightFactor >= 0.8) return "good";
    if (sunlightFactor >= 0.6) return "fair";
    return "poor";
  };

  // Aggregate yields by plant type
  const yieldEstimates: YieldEstimate[] = [];
  const plantCounts: Record<string, number> = {};

  gridItems.forEach(item => {
    plantCounts[item.name] = (plantCounts[item.name] || 0) + 1;
  });

  Object.entries(plantCounts).forEach(([plantName, quantity]) => {
    const plant = plantData.find(p => p.name === plantName);
    const yieldInfo = yieldData[plantName];
    
    if (plant && yieldInfo) {
      const sunlightFactor = getSunlightFactor(plantName);
      const yieldPerPlant = yieldInfo.baseYield * sunlightFactor;
      const totalYield = yieldPerPlant * quantity;

      yieldEstimates.push({
        plant,
        quantity,
        yieldPerPlant,
        totalYield,
        unit: yieldInfo.unit,
        sunlightBonus: Math.round((sunlightFactor - 1) * 100),
        qualityRating: getQualityRating(sunlightFactor),
      });
    }
  });

  // Sort by total yield
  yieldEstimates.sort((a, b) => b.totalYield - a.totalYield);

  // Calculate total oxygen output
  const totalOxygen = yieldEstimates.reduce((sum, est) => sum + est.totalYield, 0);

  // Convert to liters for display
  const totalOxygenLiters = totalOxygen / 1000;

  const getQualityColor = (rating: string) => {
    switch (rating) {
      case "excellent": return "text-forest";
      case "good": return "text-primary";
      case "fair": return "text-amber-500";
      case "poor": return "text-destructive";
      default: return "text-muted-foreground";
    }
  };

  const getQualityBg = (rating: string) => {
    switch (rating) {
      case "excellent": return "bg-forest/10";
      case "good": return "bg-primary/10";
      case "fair": return "bg-amber-500/10";
      case "poor": return "bg-destructive/10";
      default: return "bg-muted";
    }
  };

  if (gridItems.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="font-semibold text-foreground">Yield Prediction</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          Add plants to see estimated harvest yields based on sunlight exposure.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <div 
        className="flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="font-semibold text-foreground">Yield Prediction</h3>
          <Badge variant="secondary" className="text-xs">
            {yieldEstimates.length} crops
          </Badge>
        </div>
        {isExpanded ? (
          <ChevronUp className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        )}
      </div>

      {isExpanded && (
        <div className="mt-4 space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-lg bg-forest/10 p-3">
              <div className="flex items-center gap-2 text-forest">
                <Scale className="h-4 w-4" />
                <span className="text-xs font-medium">Daily O₂ Output</span>
              </div>
              <p className="mt-1 text-lg font-bold text-foreground">
                {totalOxygenLiters.toFixed(1)} L/day
              </p>
            </div>
            <div className="rounded-lg bg-primary/10 p-3">
              <div className="flex items-center gap-2 text-primary">
                <TrendingUp className="h-4 w-4" />
                <span className="text-xs font-medium">Air Quality</span>
              </div>
              <p className="mt-1 text-lg font-bold text-foreground">
                {totalOxygenLiters > 2 ? "Excellent" : totalOxygenLiters > 1 ? "Good" : "Fair"}
              </p>
            </div>
          </div>

          {/* Individual Crop Yields */}
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Per Crop Breakdown
            </p>
            {yieldEstimates.map((estimate) => (
              <div 
                key={estimate.plant.name}
                className="rounded-lg border border-border p-3 transition-colors hover:bg-secondary/30"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div 
                      className="h-3 w-3 rounded-full"
                      style={{ backgroundColor: `hsl(var(--${getPlantColor(estimate.plant.type)}))` }}
                    />
                    <span className="font-medium text-sm">{estimate.plant.name}</span>
                    <span className="text-xs text-muted-foreground">
                      ×{estimate.quantity}
                    </span>
                  </div>
                  <Badge className={`${getQualityBg(estimate.qualityRating)} ${getQualityColor(estimate.qualityRating)} border-0`}>
                    {estimate.qualityRating}
                  </Badge>
                </div>
                
                <div className="mt-2 flex items-center justify-between text-sm">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Leaf className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">
                        {estimate.yieldPerPlant.toFixed(1)} {estimate.unit}/plant
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Sun className="h-3 w-3 text-amber-500" />
                      <span className={estimate.sunlightBonus >= 0 ? "text-forest" : "text-destructive"}>
                        {estimate.sunlightBonus >= 0 ? "" : ""}{estimate.sunlightBonus}%
                      </span>
                    </div>
                  </div>
                  <span className="font-semibold">
                    {estimate.totalYield.toFixed(1)} {estimate.unit}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Sunlight Tips */}
          <div className="rounded-lg bg-amber-500/10 p-3">
            <div className="flex items-start gap-2">
              <Sun className="h-4 w-4 text-amber-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">Sunlight Impact</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {mapMode === "building" 
                    ? "Rooftop areas receive optimal sunlight. Balconies get ~70% exposure."
                    : "Street dividers may be shaded by surrounding buildings. Consider shade-tolerant varieties."}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
