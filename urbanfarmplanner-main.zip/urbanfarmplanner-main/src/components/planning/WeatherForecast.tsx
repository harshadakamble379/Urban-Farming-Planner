import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Cloud, 
  Sun, 
  CloudRain, 
  CloudSnow, 
  Wind,
  Droplets,
  MapPin,
  RefreshCw,
  Thermometer,
  AlertTriangle
} from "lucide-react";
import { toast } from "sonner";

interface WeatherDay {
  date: string;
  tempMax: number;
  tempMin: number;
  precipitation: number;
  weatherCode: number;
  windSpeed: number;
}

interface WeatherData {
  location: string;
  current: {
    temp: number;
    humidity: number;
    weatherCode: number;
  };
  forecast: WeatherDay[];
}

interface WateringAdjustment {
  factor: number;
  reason: string;
  alert?: string;
}

interface WeatherForecastProps {
  baseWaterPerWeek: number;
}

const weatherCodeToIcon = (code: number) => {
  if (code === 0) return <Sun className="h-5 w-5 text-yellow-500" />;
  if (code <= 3) return <Cloud className="h-5 w-5 text-muted-foreground" />;
  if (code <= 67 || (code >= 80 && code <= 82)) return <CloudRain className="h-5 w-5 text-blue-500" />;
  if (code >= 71 && code <= 77) return <CloudSnow className="h-5 w-5 text-blue-200" />;
  return <Cloud className="h-5 w-5 text-muted-foreground" />;
};

const weatherCodeToDescription = (code: number) => {
  if (code === 0) return "Clear sky";
  if (code <= 3) return "Partly cloudy";
  if (code <= 48) return "Foggy";
  if (code <= 57) return "Drizzle";
  if (code <= 67) return "Rain";
  if (code <= 77) return "Snow";
  if (code <= 82) return "Rain showers";
  if (code <= 86) return "Snow showers";
  return "Thunderstorm";
};

export function WeatherForecast({ baseWaterPerWeek }: WeatherForecastProps) {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  const fetchWeather = async (lat: number, lon: number) => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&timezone=auto&forecast_days=7`
      );
      
      if (!response.ok) throw new Error("Failed to fetch weather");
      
      const data = await response.json();
      
      const forecast: WeatherDay[] = data.daily.time.map((date: string, i: number) => ({
        date,
        tempMax: Math.round(data.daily.temperature_2m_max[i]),
        tempMin: Math.round(data.daily.temperature_2m_min[i]),
        precipitation: data.daily.precipitation_sum[i],
        weatherCode: data.daily.weather_code[i],
        windSpeed: Math.round(data.daily.wind_speed_10m_max[i]),
      }));

      setWeather({
        location: `${lat.toFixed(2)}°, ${lon.toFixed(2)}°`,
        current: {
          temp: Math.round(data.current.temperature_2m),
          humidity: data.current.relative_humidity_2m,
          weatherCode: data.current.weather_code,
        },
        forecast,
      });
      
      setLocationError(null);
    } catch (error) {
      console.error("Weather fetch error:", error);
      toast.error("Failed to fetch weather data");
    } finally {
      setLoading(false);
    }
  };

  const getLocation = () => {
    setLoading(true);
    setLocationError(null);
    
    if (!navigator.geolocation) {
      setLocationError("Geolocation not supported");
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        fetchWeather(position.coords.latitude, position.coords.longitude);
      },
      (error) => {
        console.error("Geolocation error:", error);
        setLocationError("Location access denied. Using default location.");
        // Default to a common location (New York)
        fetchWeather(40.7128, -74.006);
      }
    );
  };

  useEffect(() => {
    getLocation();
  }, []);

  const calculateWateringAdjustment = (): WateringAdjustment => {
    if (!weather) return { factor: 1, reason: "Loading weather data..." };

    const next3Days = weather.forecast.slice(0, 3);
    const totalPrecip = next3Days.reduce((sum, day) => sum + day.precipitation, 0);
    const avgTemp = next3Days.reduce((sum, day) => sum + (day.tempMax + day.tempMin) / 2, 0) / 3;
    const hasRain = next3Days.some(day => day.precipitation > 2);

    let factor = 1;
    let reasons: string[] = [];
    let alert: string | undefined;

    // Adjust for precipitation
    if (totalPrecip > 20) {
      factor -= 0.5;
      reasons.push("heavy rain expected");
    } else if (totalPrecip > 10) {
      factor -= 0.3;
      reasons.push("moderate rain expected");
    } else if (totalPrecip > 5) {
      factor -= 0.15;
      reasons.push("light rain expected");
    }

    // Adjust for temperature
    if (avgTemp > 30) {
      factor += 0.3;
      reasons.push("high temperatures");
      alert = "Heat wave conditions - consider shading sensitive plants";
    } else if (avgTemp > 25) {
      factor += 0.15;
      reasons.push("warm weather");
    } else if (avgTemp < 10) {
      factor -= 0.2;
      reasons.push("cool temperatures");
    }

    // Adjust for humidity
    if (weather.current.humidity < 40) {
      factor += 0.1;
      reasons.push("low humidity");
    } else if (weather.current.humidity > 80) {
      factor -= 0.1;
      reasons.push("high humidity");
    }

    factor = Math.max(0.3, Math.min(1.5, factor));

    return {
      factor,
      reason: reasons.length > 0 ? reasons.join(", ") : "normal conditions",
      alert,
    };
  };

  const adjustment = calculateWateringAdjustment();
  const adjustedWater = Math.round(baseWaterPerWeek * adjustment.factor);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) return "Today";
    if (date.toDateString() === tomorrow.toDateString()) return "Tomorrow";
    return date.toLocaleDateString("en-US", { weekday: "short" });
  };

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Cloud className="h-4 w-4 text-primary" />
            Weather & Watering
          </CardTitle>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={getLocation}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {locationError && (
          <p className="text-xs text-muted-foreground">{locationError}</p>
        )}

        {weather && (
          <>
            {/* Current Weather */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="flex items-center gap-3">
                {weatherCodeToIcon(weather.current.weatherCode)}
                <div>
                  <p className="text-2xl font-bold">{weather.current.temp}°C</p>
                  <p className="text-xs text-muted-foreground">
                    {weatherCodeToDescription(weather.current.weatherCode)}
                  </p>
                </div>
              </div>
              <div className="text-right text-sm">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Droplets className="h-3 w-3" />
                  {weather.current.humidity}%
                </div>
                <div className="flex items-center gap-1 text-muted-foreground mt-1">
                  <MapPin className="h-3 w-3" />
                  <span className="text-xs">{weather.location}</span>
                </div>
              </div>
            </div>

            {/* 7-Day Forecast */}
            <div className="space-y-2">
              <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                7-Day Forecast
              </h4>
              <div className="grid grid-cols-7 gap-1">
                {weather.forecast.map((day) => (
                  <div
                    key={day.date}
                    className="flex flex-col items-center p-2 rounded-lg bg-muted/30 text-center"
                  >
                    <span className="text-xs font-medium">{formatDate(day.date)}</span>
                    {weatherCodeToIcon(day.weatherCode)}
                    <span className="text-xs font-bold mt-1">{day.tempMax}°</span>
                    <span className="text-xs text-muted-foreground">{day.tempMin}°</span>
                    {day.precipitation > 0 && (
                      <span className="text-xs text-blue-500 mt-1">
                        {day.precipitation.toFixed(1)}mm
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Watering Adjustment */}
            <div className="space-y-2 pt-2 border-t border-border/50">
              <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Watering Recommendation
              </h4>
              
              {adjustment.alert && (
                <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-500/10 text-amber-600 text-xs">
                  <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                  {adjustment.alert}
                </div>
              )}

              <div className="flex items-center justify-between p-3 rounded-lg bg-primary/5">
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">{adjustedWater}L / week</p>
                    <p className="text-xs text-muted-foreground">
                      {adjustment.factor < 1 ? "Reduced" : adjustment.factor > 1 ? "Increased" : "Normal"} due to {adjustment.reason}
                    </p>
                  </div>
                </div>
                <Badge 
                  variant={adjustment.factor < 1 ? "secondary" : adjustment.factor > 1 ? "destructive" : "outline"}
                  className="text-xs"
                >
                  {adjustment.factor < 1 ? `-${Math.round((1 - adjustment.factor) * 100)}%` : 
                   adjustment.factor > 1 ? `+${Math.round((adjustment.factor - 1) * 100)}%` : "Normal"}
                </Badge>
              </div>

              <p className="text-xs text-muted-foreground">
                Base requirement: {baseWaterPerWeek}L/week • Adjusted for 3-day forecast
              </p>
            </div>
          </>
        )}

        {!weather && !loading && (
          <div className="text-center py-4">
            <Button variant="outline" size="sm" onClick={getLocation}>
              <MapPin className="h-4 w-4 mr-2" />
              Get Weather
            </Button>
          </div>
        )}

        {loading && !weather && (
          <div className="flex items-center justify-center py-8">
            <RefreshCw className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}