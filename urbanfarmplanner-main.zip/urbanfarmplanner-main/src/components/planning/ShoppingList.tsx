import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  ShoppingCart, 
  Leaf, 
  Package, 
  Droplets,
  Shovel,
  Box,
  Download,
  Printer,
  Loader2,
  Check,
  X
} from "lucide-react";
import { getPlantInfo, SupplyItem } from "@/data/plantData";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface InventoryMatch {
  id: string;
  name: string;
}

interface AggregatedSupply extends SupplyItem {
  id: string;
  checked: boolean;
  inventoryItemId?: string;
  inventoryMatch?: InventoryMatch | null;
}

interface ShoppingListProps {
  gridItems: PlantItem[];
}

const categoryIcons = {
  seeds: Leaf,
  soil: Package,
  fertilizer: Droplets,
  tools: Shovel,
  containers: Box,
};

const categoryColors = {
  seeds: "bg-forest/20 text-forest",
  soil: "bg-terracotta/20 text-terracotta",
  fertilizer: "bg-primary/20 text-primary",
  tools: "bg-muted text-muted-foreground",
  containers: "bg-accent/20 text-accent-foreground",
};

interface InventoryItem {
  id: string;
  name: string;
  category: string;
}

export function ShoppingList({ gridItems }: ShoppingListProps) {
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());
  const [addingAllToCart, setAddingAllToCart] = useState(false);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [loadingInventory, setLoadingInventory] = useState(true);

  // Fetch inventory items on mount
  useEffect(() => {
    const fetchInventory = async () => {
      try {
        const { data, error } = await supabase
          .from("inventory_items")
          .select("id, name, category")
          .eq("is_available", true);

        if (error) throw error;
        setInventoryItems(data || []);
      } catch (error) {
        console.error("Error fetching inventory:", error);
      } finally {
        setLoadingInventory(false);
      }
    };

    fetchInventory();
  }, []);

  // Helper to extract search terms from supply name
  const getSearchTerms = (supplyName: string): string[] => {
    // Remove common suffixes like "plant", "cutting", "seeds" to get core name
    const cleanName = supplyName
      .replace(/\s+(plant|cutting|cuttings|seeds|mix|pot|basket|trellis)s?$/i, '')
      .trim();
    
    // Split into words and get meaningful terms
    const words = cleanName.split(/\s+/).filter(w => w.length > 2);
    return words;
  };

  const addAllToCart = async (supplies: AggregatedSupply[]) => {
    try {
      setAddingAllToCart(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Please log in to add items to cart");
        return;
      }

      // First, fetch all available inventory items
      const { data: allInventory, error: inventoryError } = await supabase
        .from("inventory_items")
        .select("id, name, quantity, category")
        .eq("is_available", true);

      if (inventoryError) {
        throw inventoryError;
      }

      let addedCount = 0;
      let notFoundItems: string[] = [];

      for (const supply of supplies) {
        if (checkedItems.has(supply.id)) continue; // Skip already checked items

        // Find matching inventory item using fuzzy matching
        const searchTerms = getSearchTerms(supply.name);
        let matchedItem = allInventory?.find(item => {
          const itemNameLower = item.name.toLowerCase();
          // Check if all search terms are in the item name
          return searchTerms.every(term => 
            itemNameLower.includes(term.toLowerCase())
          );
        });

        // If no match, try matching by category for tools/containers
        if (!matchedItem && supply.category === "tools") {
          matchedItem = allInventory?.find(item => 
            item.category === "Tools" && 
            item.name.toLowerCase().includes(supply.name.split(' ')[0].toLowerCase())
          );
        }

        if (!matchedItem) {
          notFoundItems.push(supply.name);
          continue;
        }

        // Check if item already in cart
        const { data: existingCart } = await supabase
          .from("shopping_cart")
          .select("id, quantity")
          .eq("user_id", user.id)
          .eq("item_id", matchedItem.id)
          .maybeSingle();

        if (existingCart) {
          // Update quantity
          const newQuantity = existingCart.quantity + Math.ceil(supply.quantity);
          await supabase
            .from("shopping_cart")
            .update({ quantity: newQuantity })
            .eq("id", existingCart.id);
        } else {
          // Add new item
          await supabase
            .from("shopping_cart")
            .insert({
              user_id: user.id,
              item_id: matchedItem.id,
              quantity: Math.ceil(supply.quantity)
            });
        }
        addedCount++;
      }

      // Mark all as checked
      const newChecked = new Set(checkedItems);
      supplies.forEach(s => newChecked.add(s.id));
      setCheckedItems(newChecked);

      if (addedCount > 0) {
        toast.success(`Added ${addedCount} items to cart`);
      }
      if (notFoundItems.length > 0) {
        toast.info(`${notFoundItems.length} items not in inventory (soils, pots, etc.)`);
      }
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast.error("Failed to add items to cart");
    } finally {
      setAddingAllToCart(false);
    }
  };

  // Helper function to find matching inventory item
  const findInventoryMatch = (supplyName: string): InventoryMatch | null => {
    const searchTerms = getSearchTerms(supplyName);
    const matchedItem = inventoryItems.find(item => {
      const itemNameLower = item.name.toLowerCase();
      return searchTerms.every(term => 
        itemNameLower.includes(term.toLowerCase())
      );
    });
    return matchedItem ? { id: matchedItem.id, name: matchedItem.name } : null;
  };

  const aggregatedSupplies = useMemo(() => {
    const supplyMap = new Map<string, AggregatedSupply>();
    
    // Count plants by type
    const plantCounts = new Map<string, number>();
    gridItems.forEach(item => {
      plantCounts.set(item.name, (plantCounts.get(item.name) || 0) + 1);
    });

    // Aggregate supplies from all plants
    plantCounts.forEach((count, plantName) => {
      const plantInfo = getPlantInfo(plantName);
      if (!plantInfo) return;

      plantInfo.supplies.forEach(supply => {
        const key = `${supply.name}-${supply.unit}`;
        const existing = supplyMap.get(key);
        
        if (existing) {
          existing.quantity += supply.quantity * count;
        } else {
          supplyMap.set(key, {
            ...supply,
            id: key,
            quantity: supply.quantity * count,
            checked: false,
            inventoryMatch: findInventoryMatch(supply.name),
          });
        }
      });
    });

    // Add general supplies based on total plants
    const totalPlants = gridItems.length;
    if (totalPlants > 0) {
      const generalSupplies: SupplyItem[] = [
        { name: "Plant markers", quantity: totalPlants, unit: "pcs", category: "tools", pricePerUnit: 0.50 },
        { name: "Gardening gloves", quantity: 1, unit: "pair", category: "tools", pricePerUnit: 8.00 },
        { name: "Watering can", quantity: 1, unit: "pcs", category: "tools", pricePerUnit: 12.00 },
      ];

      generalSupplies.forEach(supply => {
        const key = `${supply.name}-${supply.unit}`;
        if (!supplyMap.has(key)) {
          supplyMap.set(key, {
            ...supply,
            id: key,
            checked: false,
            inventoryMatch: findInventoryMatch(supply.name),
          });
        }
      });
    }

    return Array.from(supplyMap.values()).sort((a, b) => {
      const categoryOrder = ["seeds", "soil", "fertilizer", "containers", "tools"];
      return categoryOrder.indexOf(a.category) - categoryOrder.indexOf(b.category);
    });
  }, [gridItems, inventoryItems]);

  const toggleItem = (id: string) => {
    const newChecked = new Set(checkedItems);
    if (newChecked.has(id)) {
      newChecked.delete(id);
    } else {
      newChecked.add(id);
    }
    setCheckedItems(newChecked);
  };

  const availableCount = aggregatedSupplies.filter(s => s.inventoryMatch).length;
  const unavailableCount = aggregatedSupplies.filter(s => !s.inventoryMatch).length;
  const uncheckedCount = aggregatedSupplies.filter(s => !checkedItems.has(s.id)).length;
  const checkedCount = aggregatedSupplies.filter(s => checkedItems.has(s.id)).length;

  const exportList = () => {
    const text = aggregatedSupplies
      .map(s => `${checkedItems.has(s.id) ? "✓" : "○"} ${s.name}: ${s.quantity} ${s.unit}`)
      .join("\n");
    
    const blob = new Blob([`Urban Farm Shopping List\n${"=".repeat(25)}\n\n${text}`], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "shopping-list.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  const printList = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;
    
    // HTML escape function to prevent XSS
    const escapeHtml = (str: string): string => str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
    
    const html = `
      <html>
        <head>
          <title>Shopping List</title>
          <style>
            body { font-family: system-ui, sans-serif; padding: 20px; }
            h1 { color: #2d5016; }
            .item { padding: 8px 0; border-bottom: 1px solid #eee; display: flex; gap: 12px; }
            .checkbox { width: 16px; height: 16px; border: 2px solid #ccc; }
            .category { font-size: 12px; color: #666; background: #f5f5f5; padding: 2px 8px; border-radius: 4px; }
          </style>
        </head>
        <body>
          <h1>🌱 Urban Farm Shopping List</h1>
          <p>${gridItems.length} plants planned</p>
          ${aggregatedSupplies.map(s => `
            <div class="item">
              <div class="checkbox"></div>
              <span><strong>${escapeHtml(s.name)}</strong>: ${escapeHtml(String(s.quantity))} ${escapeHtml(s.unit)}</span>
              <span class="category">${escapeHtml(s.category)}</span>
            </div>
          `).join("")}
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.print();
  };

  const groupedSupplies = useMemo(() => {
    const groups: Record<string, AggregatedSupply[]> = {};
    aggregatedSupplies.forEach(supply => {
      if (!groups[supply.category]) {
        groups[supply.category] = [];
      }
      groups[supply.category].push(supply);
    });
    return groups;
  }, [aggregatedSupplies]);

  if (gridItems.length === 0) {
    return (
      <Card className="border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <ShoppingCart className="h-4 w-4 text-primary" />
            Shopping List
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-4">
            Add plants to your garden to generate a shopping list
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <ShoppingCart className="h-4 w-4 text-primary" />
            Shopping List
          </CardTitle>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="default" className="text-xs bg-green-600">
              <Check className="h-3 w-3 mr-1" />
              {availableCount} in stock
            </Badge>
            {unavailableCount > 0 && (
              <Badge variant="outline" className="text-xs text-orange-600 border-orange-300">
                <X className="h-3 w-3 mr-1" />
                {unavailableCount} unavailable
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {Object.entries(groupedSupplies).map(([category, supplies]) => {
          const Icon = categoryIcons[category as keyof typeof categoryIcons];
          return (
            <div key={category} className="space-y-2">
              <div className="flex items-center gap-2">
                <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  {category}
                </span>
              </div>
              <div className="space-y-1">
                {supplies.map(supply => (
                  <div
                    key={supply.id}
                    className={`flex items-center gap-2 p-2 rounded-lg transition-colors ${
                      checkedItems.has(supply.id)
                        ? "bg-muted/50 opacity-60"
                        : supply.inventoryMatch
                        ? "hover:bg-muted/30"
                        : "hover:bg-muted/30 bg-orange-50/50 dark:bg-orange-950/20"
                    }`}
                  >
                    <Checkbox
                      checked={checkedItems.has(supply.id)}
                      onCheckedChange={() => toggleItem(supply.id)}
                    />
                    {supply.inventoryMatch ? (
                      <Check className="h-3.5 w-3.5 text-green-600 flex-shrink-0" />
                    ) : (
                      <X className="h-3.5 w-3.5 text-orange-500 flex-shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <span
                        className={`text-sm block truncate ${
                          checkedItems.has(supply.id) ? "line-through text-muted-foreground" : ""
                        }`}
                      >
                        {supply.name}
                      </span>
                      {supply.inventoryMatch && (
                        <span className="text-xs text-muted-foreground truncate block">
                          → {supply.inventoryMatch.name}
                        </span>
                      )}
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`text-xs flex-shrink-0 ${categoryColors[supply.category]}`}
                    >
                      {supply.quantity} {supply.unit}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        <div className="flex flex-col gap-2 pt-2 border-t border-border/50">
          <Button
            size="sm"
            className="w-full gap-2"
            onClick={() => addAllToCart(aggregatedSupplies.filter(s => s.inventoryMatch))}
            disabled={addingAllToCart || availableCount === 0}
          >
            {addingAllToCart ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <ShoppingCart className="h-3.5 w-3.5" />
            )}
            {addingAllToCart ? "Adding..." : `Add ${availableCount} Available to Cart`}
          </Button>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="flex-1 gap-2"
              onClick={exportList}
            >
              <Download className="h-3.5 w-3.5" />
              Export
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex-1 gap-2"
              onClick={printList}
            >
              <Printer className="h-3.5 w-3.5" />
              Print
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}