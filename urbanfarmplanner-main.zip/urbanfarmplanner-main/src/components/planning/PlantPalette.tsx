import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

interface PlantOption {
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
}

interface PlantPaletteProps {
  plantOptions: PlantOption[];
  selectedPlant: PlantOption | null;
  onSelectPlant: (plant: PlantOption | null) => void;
  gridItemsCount: number;
  onClearAll: () => void;
  getPlantColor: (type: string) => string;
}

export const PlantPalette = ({
  plantOptions,
  selectedPlant,
  onSelectPlant,
  gridItemsCount,
  onClearAll,
  getPlantColor,
}: PlantPaletteProps) => {
  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <h3 className="mb-2 text-sm font-semibold text-foreground">Plant Palette</h3>
      <p className="mb-3 text-xs text-muted-foreground">Select a plant, then click on grid</p>
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {plantOptions.map((plant) => (
          <button
            key={plant.name}
            onClick={() => {
              onSelectPlant(selectedPlant?.name === plant.name ? null : plant);
            }}
            className={`flex w-full items-center justify-between rounded-lg border p-3 transition-all ${
              selectedPlant?.name === plant.name
                ? "border-primary bg-primary/10"
                : "border-border hover:border-primary/30"
            }`}
          >
            <div className="flex items-center gap-2">
              <div 
                className="h-3 w-3 rounded-full"
                style={{ 
                  backgroundColor: `hsl(var(--${getPlantColor(plant.type)}))`
                }} 
              />
              <span className="text-sm text-foreground">{plant.name}</span>
            </div>
            <Badge variant="secondary" className="text-xs">{plant.type}</Badge>
          </button>
        ))}
      </div>
      {gridItemsCount > 0 && (
        <Button 
          variant="outline" 
          size="sm" 
          className="mt-4 w-full text-destructive hover:text-destructive"
          onClick={onClearAll}
        >
          <Trash2 className="mr-2 h-4 w-4" />
          Clear All
        </Button>
      )}
    </div>
  );
};