import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Sun, Cloud, Sunrise, Sunset, AlertTriangle, CheckCircle, MapPin, Clock } from 'lucide-react';
import { useLocation, cityData } from '@/contexts/LocationContext';

interface PlantItem {
  id: number;
  type: string;
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface SunlightAnalysisProps {
  gridItems: PlantItem[];
  mapMode: 'building' | 'street-divider' | 'balcony';
  timeOfDay: number;
  onTimeChange: (time: number) => void;
}

const plantSunRequirements: Record<string, 'full-sun' | 'partial-shade' | 'full-shade'> = {
  'Tomatoes': 'full-sun',
  'Peppers': 'full-sun',
  'Carrots': 'partial-shade',
  'Basil': 'full-sun',
  'Mint': 'partial-shade',
  'Rosemary': 'full-sun',
  'Lettuce': 'partial-shade',
  'Spinach': 'partial-shade',
  'Strawberries': 'full-sun',
};

// Calculate sun position based on date, time, and latitude
const calculateSunPosition = (date: Date, latitude: number): { altitude: number; azimuth: number; sunrise: number; sunset: number } => {
  const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
  const hour = date.getHours() + date.getMinutes() / 60;
  
  // Solar declination angle
  const declination = 23.45 * Math.sin((360 / 365) * (dayOfYear - 81) * Math.PI / 180);
  
  // Hour angle (15 degrees per hour from solar noon)
  const solarNoon = 12; // Simplified
  const hourAngle = (hour - solarNoon) * 15;
  
  // Convert to radians
  const latRad = latitude * Math.PI / 180;
  const decRad = declination * Math.PI / 180;
  const haRad = hourAngle * Math.PI / 180;
  
  // Solar altitude angle
  const sinAltitude = Math.sin(latRad) * Math.sin(decRad) + Math.cos(latRad) * Math.cos(decRad) * Math.cos(haRad);
  const altitude = Math.asin(sinAltitude) * 180 / Math.PI;
  
  // Solar azimuth angle
  const cosAzimuth = (Math.sin(decRad) - Math.sin(latRad) * sinAltitude) / (Math.cos(latRad) * Math.cos(altitude * Math.PI / 180));
  let azimuth = Math.acos(Math.max(-1, Math.min(1, cosAzimuth))) * 180 / Math.PI;
  if (hour > 12) azimuth = 360 - azimuth;
  
  // Calculate sunrise/sunset times
  const cosHourAngle = -Math.tan(latRad) * Math.tan(decRad);
  const sunriseHourAngle = Math.acos(Math.max(-1, Math.min(1, cosHourAngle))) * 180 / Math.PI;
  const sunrise = 12 - sunriseHourAngle / 15;
  const sunset = 12 + sunriseHourAngle / 15;
  
  return { altitude: Math.max(0, altitude), azimuth, sunrise, sunset };
};

// Get latitude from cityData context
const getCityLatitude = (city: string): number => {
  const cityInfo = cityData[city];
  return cityInfo?.lat || 40.7; // Default to NYC latitude
};

const getSunlightExposure = (
  row: number, 
  col: number, 
  mapMode: 'building' | 'street-divider' | 'balcony',
  timeOfDay: number,
  sunPosition: { altitude: number; azimuth: number; sunrise: number; sunset: number }
): { level: 'full-sun' | 'partial-shade' | 'full-shade'; hours: number; inShadow: boolean; sunIntensity: number } => {
  const { altitude, azimuth, sunrise, sunset } = sunPosition;
  const dayLength = sunset - sunrise;
  
  // Sun is below horizon
  if (altitude <= 0 || timeOfDay < sunrise || timeOfDay > sunset) {
    return { level: 'full-shade', hours: 0, inShadow: true, sunIntensity: 0 };
  }
  
  // Calculate shadow based on sun altitude (lower sun = longer shadows)
  const shadowMultiplier = altitude > 0 ? 1 / Math.tan(altitude * Math.PI / 180) : 10;
  const sunIntensity = Math.min(1, altitude / 45); // Peak at 45+ degrees
  
  if (mapMode === 'building') {
    const isRooftop = row >= 0 && row <= 2;
    const isEastBalcony = col === 0 && row >= 3 && row <= 5;
    const isWestBalcony = col === 7 && row >= 3 && row <= 5;
    const isGroundLevel = row >= 6;
    
    if (isRooftop) {
      return { level: 'full-sun', hours: Math.round(dayLength * 0.9), inShadow: false, sunIntensity };
    }
    
    if (isEastBalcony) {
      // East facing: gets morning sun when azimuth < 180
      const inSun = azimuth < 150;
      const hours = Math.round(dayLength * 0.4);
      return { 
        level: inSun ? 'full-sun' : 'partial-shade', 
        hours, 
        inShadow: !inSun,
        sunIntensity: inSun ? sunIntensity : sunIntensity * 0.3
      };
    }
    
    if (isWestBalcony) {
      // West facing: gets afternoon sun when azimuth > 180
      const inSun = azimuth > 210;
      const hours = Math.round(dayLength * 0.4);
      return { 
        level: inSun ? 'full-sun' : 'partial-shade', 
        hours, 
        inShadow: !inSun,
        sunIntensity: inSun ? sunIntensity : sunIntensity * 0.3
      };
    }
    
    if (isGroundLevel) {
      // Ground level shadowed by building - check sun angle
      const buildingHeight = 4; // Relative building height
      const distanceFromBuilding = Math.min(col, 7 - col);
      const shadowReach = buildingHeight * shadowMultiplier;
      const inShadow = distanceFromBuilding < shadowReach && altitude < 50;
      
      return { 
        level: inShadow ? 'full-shade' : 'partial-shade', 
        hours: Math.round(dayLength * 0.3), 
        inShadow,
        sunIntensity: inShadow ? 0.1 : sunIntensity * 0.5
      };
    }
    
    return { level: 'partial-shade', hours: Math.round(dayLength * 0.5), inShadow: false, sunIntensity: sunIntensity * 0.6 };
  } else {
    // Street divider - buildings on both sides
    const centerStrip = col >= 3 && col <= 4;
    
    if (centerStrip) {
      // Morning shadow from west building, afternoon shadow from east building
      const morningClear = azimuth > 120 && azimuth < 180;
      const afternoonClear = azimuth > 180 && azimuth < 240;
      const inShadow = altitude < 45 && !morningClear && !afternoonClear;
      
      return { 
        level: inShadow ? 'partial-shade' : 'full-sun', 
        hours: Math.round(dayLength * 0.6), 
        inShadow,
        sunIntensity: inShadow ? sunIntensity * 0.4 : sunIntensity
      };
    }
    
    return { level: 'full-shade', hours: Math.round(dayLength * 0.2), inShadow: true, sunIntensity: 0.1 };
  }
};

const getCompatibility = (
  plantRequirement: 'full-sun' | 'partial-shade' | 'full-shade',
  zoneLevel: 'full-sun' | 'partial-shade' | 'full-shade'
): 'optimal' | 'acceptable' | 'poor' => {
  if (plantRequirement === zoneLevel) return 'optimal';
  
  if (plantRequirement === 'full-sun' && zoneLevel === 'full-shade') return 'poor';
  if (plantRequirement === 'full-shade' && zoneLevel === 'full-sun') return 'poor';
  
  return 'acceptable';
};

export const SunlightAnalysis: React.FC<SunlightAnalysisProps> = ({ gridItems, mapMode, timeOfDay, onTimeChange }) => {
  const { city } = useLocation();
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Update current time every minute for real-time tracking
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(interval);
  }, []);
  
  const latitude = getCityLatitude(city);
  
  // Calculate sun position based on location and current time/slider
  const sunPosition = useMemo(() => {
    const date = new Date();
    date.setHours(timeOfDay, 0, 0, 0);
    return calculateSunPosition(date, latitude);
  }, [timeOfDay, latitude]);
  
  // Real-time sun position
  const realTimeSunPosition = useMemo(() => {
    return calculateSunPosition(currentTime, latitude);
  }, [currentTime, latitude]);
  
  const currentHour = timeOfDay;
  const timeLabel = currentHour < 12 ? `${currentHour} AM` : currentHour === 12 ? '12 PM' : `${currentHour - 12} PM`;
  
  const formatTime = (decimalHours: number) => {
    const hours = Math.floor(decimalHours);
    const minutes = Math.round((decimalHours - hours) * 60);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours > 12 ? hours - 12 : hours === 0 ? 12 : hours;
    return `${displayHours}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  };
  
  const plantAnalysis = gridItems.map(item => {
    const sunRequirement = plantSunRequirements[item.name] || 'partial-shade';
    const exposure = getSunlightExposure(item.y, item.x, mapMode, currentHour, sunPosition);
    const compatibility = getCompatibility(sunRequirement, exposure.level);
    
    return {
      ...item,
      sunRequirement,
      exposure,
      compatibility,
    };
  });
  
  const optimalCount = plantAnalysis.filter(p => p.compatibility === 'optimal').length;
  const acceptableCount = plantAnalysis.filter(p => p.compatibility === 'acceptable').length;
  const poorCount = plantAnalysis.filter(p => p.compatibility === 'poor').length;
  
  const overallScore = gridItems.length > 0 
    ? Math.round(((optimalCount * 100) + (acceptableCount * 60) + (poorCount * 20)) / gridItems.length)
    : 0;

  const getZoneDescription = () => {
    const dayLength = sunPosition.sunset - sunPosition.sunrise;
    if (mapMode === 'building') {
      return [
        { zone: 'Rooftop', exposure: `Full Sun (${Math.round(dayLength * 0.9)} hrs)`, icon: Sun },
        { zone: 'East Balconies', exposure: `Morning Sun (${Math.round(dayLength * 0.4)} hrs)`, icon: Sunrise },
        { zone: 'West Balconies', exposure: `Afternoon Sun (${Math.round(dayLength * 0.4)} hrs)`, icon: Sunset },
        { zone: 'Ground Level', exposure: `Partial Shade (${Math.round(dayLength * 0.3)} hrs)`, icon: Cloud },
      ];
    }
    return [
      { zone: 'Center Strip', exposure: `Midday Sun (${Math.round(dayLength * 0.6)} hrs)`, icon: Sun },
      { zone: 'Near Buildings', exposure: `Heavy Shade (${Math.round(dayLength * 0.2)} hrs)`, icon: Cloud },
    ];
  };

  return (
    <Card className="bg-card/50 backdrop-blur border-border/50">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Sun className="h-5 w-5 text-amber-500" />
          Sunlight Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Real-time Sun Info */}
        <div className="p-3 rounded-lg bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="h-4 w-4 text-amber-500" />
            <span className="text-sm font-medium">{city}</span>
            <Clock className="h-4 w-4 text-muted-foreground ml-auto" />
            <span className="text-xs text-muted-foreground">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1">
              <Sunrise className="h-3 w-3 text-amber-400" />
              <span className="text-muted-foreground">Sunrise: {formatTime(sunPosition.sunrise)}</span>
            </div>
            <div className="flex items-center gap-1">
              <Sunset className="h-3 w-3 text-orange-500" />
              <span className="text-muted-foreground">Sunset: {formatTime(sunPosition.sunset)}</span>
            </div>
            <div className="flex items-center gap-1">
              <Sun className="h-3 w-3 text-yellow-500" />
              <span className="text-muted-foreground">Altitude: {Math.round(sunPosition.altitude)}°</span>
            </div>
            <div className="flex items-center gap-1">
              <Sun className="h-3 w-3 text-amber-500" />
              <span className="text-muted-foreground">Azimuth: {Math.round(sunPosition.azimuth)}°</span>
            </div>
          </div>
        </div>

        {/* Time of Day Slider */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Simulate Time</span>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 text-xs"
                onClick={() => onTimeChange(new Date().getHours())}
              >
                Now
              </Button>
              <Badge variant="outline" className="font-mono">{timeLabel}</Badge>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Sunrise className="h-4 w-4 text-amber-400" />
            <Slider
              value={[timeOfDay]}
              onValueChange={(val) => onTimeChange(val[0])}
              min={Math.floor(sunPosition.sunrise)}
              max={Math.ceil(sunPosition.sunset)}
              step={1}
              className="flex-1"
            />
            <Sunset className="h-4 w-4 text-orange-500" />
          </div>
        </div>

        {/* Zone Descriptions */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-foreground">Exposure Zones</h4>
          <div className="grid gap-2">
            {getZoneDescription().map(({ zone, exposure, icon: Icon }) => (
              <div key={zone} className="flex items-center justify-between text-sm bg-muted/30 rounded-lg px-3 py-2">
                <div className="flex items-center gap-2">
                  <Icon className="h-4 w-4 text-amber-500" />
                  <span className="text-foreground">{zone}</span>
                </div>
                <span className="text-muted-foreground text-xs">{exposure}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Overall Score */}
        {gridItems.length > 0 && (
          <>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Placement Score</span>
                <span className={`text-lg font-bold ${
                  overallScore >= 80 ? 'text-emerald-500' : 
                  overallScore >= 50 ? 'text-amber-500' : 'text-red-500'
                }`}>
                  {overallScore}%
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all ${
                    overallScore >= 80 ? 'bg-emerald-500' : 
                    overallScore >= 50 ? 'bg-amber-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${overallScore}%` }}
                />
              </div>
            </div>

            {/* Compatibility Summary */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-emerald-500/10 rounded-lg p-2">
                <CheckCircle className="h-4 w-4 text-emerald-500 mx-auto mb-1" />
                <div className="text-lg font-bold text-emerald-500">{optimalCount}</div>
                <div className="text-xs text-muted-foreground">Optimal</div>
              </div>
              <div className="bg-amber-500/10 rounded-lg p-2">
                <Sun className="h-4 w-4 text-amber-500 mx-auto mb-1" />
                <div className="text-lg font-bold text-amber-500">{acceptableCount}</div>
                <div className="text-xs text-muted-foreground">Acceptable</div>
              </div>
              <div className="bg-red-500/10 rounded-lg p-2">
                <AlertTriangle className="h-4 w-4 text-red-500 mx-auto mb-1" />
                <div className="text-lg font-bold text-red-500">{poorCount}</div>
                <div className="text-xs text-muted-foreground">Poor</div>
              </div>
            </div>

            {/* Plant-specific warnings */}
            {poorCount > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                  Placement Issues
                </h4>
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {plantAnalysis
                    .filter(p => p.compatibility === 'poor')
                    .map(plant => (
                      <div key={plant.id} className="text-xs bg-red-500/10 text-red-400 rounded px-2 py-1">
                        <span className="font-medium">{plant.name}</span> needs {plant.sunRequirement.replace('-', ' ')} but is in {plant.exposure.level.replace('-', ' ')}
                      </div>
                    ))
                  }
                </div>
              </div>
            )}
          </>
        )}

        {gridItems.length === 0 && (
          <div className="text-center py-4 text-muted-foreground text-sm">
            Add plants to see sunlight compatibility analysis
          </div>
        )}
      </CardContent>
    </Card>
  );
};
