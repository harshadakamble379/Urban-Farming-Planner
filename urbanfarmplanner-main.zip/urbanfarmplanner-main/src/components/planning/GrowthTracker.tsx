import { useState } from "react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { 
  Sprout, 
  CalendarDays, 
  ChevronDown, 
  Clock,
  Leaf,
  Sun,
  Droplets
} from "lucide-react";
import { format } from "date-fns";
import { 
  getPlantInfo, 
  getGrowthProgress, 
  getCurrentStage, 
  getDaysUntilHarvest,
  getHarvestDate,
  GrowthStage
} from "@/data/plantData";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface GrowthTrackerProps {
  gridItems: PlantItem[];
  getPlantColor: (type: string) => string;
}

export const GrowthTracker = ({ gridItems, getPlantColor }: GrowthTrackerProps) => {
  const [expandedPlant, setExpandedPlant] = useState<number | null>(null);

  const plantsWithGrowthData = gridItems
    .filter(item => item.plantedAt)
    .map(item => {
      const plantInfo = getPlantInfo(item.name);
      if (!plantInfo) return null;
      
      const progress = getGrowthProgress(item.plantedAt!, plantInfo.daysToHarvest);
      const currentStage = getCurrentStage(item.plantedAt!, plantInfo.growthStages);
      const daysUntilHarvest = getDaysUntilHarvest(item.plantedAt!, plantInfo.daysToHarvest);
      const harvestDate = getHarvestDate(item.plantedAt!, plantInfo.daysToHarvest);
      
      return {
        ...item,
        plantInfo,
        progress,
        currentStage,
        daysUntilHarvest,
        harvestDate,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a!.daysUntilHarvest - b!.daysUntilHarvest);

  if (plantsWithGrowthData.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Sprout className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Growth Tracker</h3>
        </div>
        <p className="text-xs text-muted-foreground text-center py-4">
          No plants placed yet. Add plants to track their growth!
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <div className="flex items-center gap-2 mb-3">
        <Sprout className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Growth Tracker</h3>
        <Badge variant="secondary" className="ml-auto text-xs">
          {plantsWithGrowthData.length} plants
        </Badge>
      </div>
      
      <ScrollArea className="h-[300px] pr-2">
        <div className="space-y-3">
          {plantsWithGrowthData.map((plant) => {
            if (!plant) return null;
            const isExpanded = expandedPlant === plant.id;
            
            return (
              <Collapsible
                key={plant.id}
                open={isExpanded}
                onOpenChange={() => setExpandedPlant(isExpanded ? null : plant.id)}
              >
                <div className="rounded-lg border border-border p-3 transition-all hover:border-primary/30">
                  <CollapsibleTrigger asChild>
                    <button className="w-full">
                      <div className="flex items-center gap-3">
                        <div 
                          className="h-8 w-8 rounded-lg flex items-center justify-center"
                          style={{ 
                            backgroundColor: `hsl(var(--${getPlantColor(plant.type)}) / 0.2)`
                          }}
                        >
                          <Leaf 
                            className="h-4 w-4" 
                            style={{ color: `hsl(var(--${getPlantColor(plant.type)}))` }}
                          />
                        </div>
                        <div className="flex-1 text-left">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">{plant.name}</span>
                            <ChevronDown 
                              className={`h-4 w-4 text-muted-foreground transition-transform ${
                                isExpanded ? "rotate-180" : ""
                              }`}
                            />
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <Progress value={plant.progress} className="h-1.5 flex-1" />
                            <span className="text-xs text-muted-foreground w-10">
                              {Math.round(plant.progress)}%
                            </span>
                          </div>
                        </div>
                      </div>
                    </button>
                  </CollapsibleTrigger>
                  
                  <CollapsibleContent>
                    <div className="mt-3 pt-3 border-t border-border space-y-3">
                      {/* Current Stage */}
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Current Stage</span>
                        <Badge variant="outline" className="text-xs">
                          {plant.currentStage.name}
                        </Badge>
                      </div>
                      
                      <p className="text-xs text-muted-foreground">
                        {plant.currentStage.description}
                      </p>
                      
                      {/* Timeline */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-xs">
                          <CalendarDays className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">Planted:</span>
                          <span>{format(new Date(plant.plantedAt!), "MMM d, yyyy")}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs">
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">Harvest in:</span>
                          <span className="font-medium text-primary">
                            {plant.daysUntilHarvest > 0 
                              ? `${plant.daysUntilHarvest} days` 
                              : "Ready now!"}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-xs">
                          <CalendarDays className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">Expected:</span>
                          <span>{format(plant.harvestDate, "MMM d, yyyy")}</span>
                        </div>
                      </div>
                      
                      {/* Growth Stages Timeline */}
                      <div className="mt-3">
                        <p className="text-xs font-medium mb-2">Growth Stages</p>
                        <div className="relative">
                          <div className="absolute left-1.5 top-2 bottom-2 w-0.5 bg-border" />
                          {plant.plantInfo.growthStages.map((stage, index) => {
                            const isComplete = plant.currentStage.daysFromStart >= stage.daysFromStart;
                            const isCurrent = plant.currentStage.name === stage.name;
                            
                            return (
                              <div key={stage.name} className="relative flex items-start gap-3 pb-2">
                                <div 
                                  className={`relative z-10 h-3 w-3 rounded-full border-2 ${
                                    isCurrent 
                                      ? "bg-primary border-primary" 
                                      : isComplete 
                                        ? "bg-primary/50 border-primary/50" 
                                        : "bg-background border-muted"
                                  }`}
                                />
                                <div className="flex-1 -mt-0.5">
                                  <p className={`text-xs ${isCurrent ? "font-medium" : "text-muted-foreground"}`}>
                                    {stage.name}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    Day {stage.daysFromStart}
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      
                      {/* Requirements */}
                      <div className="flex gap-4 pt-2 border-t border-border">
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Sun className="h-3 w-3" />
                          <span className="capitalize">{plant.plantInfo.sunRequirement}</span>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Droplets className="h-3 w-3" />
                          <span>{plant.plantInfo.waterPerWeek}L/week</span>
                        </div>
                      </div>
                    </div>
                  </CollapsibleContent>
                </div>
              </Collapsible>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
};
