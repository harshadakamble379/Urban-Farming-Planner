import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Building2, 
  ZoomIn, 
  ZoomOut, 
  Leaf, 
  Droplets, 
  Trash2,
  Ruler,
  RailSymbol,
  Sun
} from "lucide-react";

export type MapMode = "building" | "street-divider" | "balcony";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface PlotConfig {
  width: number;
  height: number;
  unit: "meters" | "feet" | "yards";
  cellSize: number;
}

interface PlanningCanvasProps {
  plotConfig: PlotConfig;
  gridItems: PlantItem[];
  selectedPlant: { type: string; name: string } | null;
  showGrid: boolean;
  mapMode: MapMode;
  timeOfDay: number;
  onMapModeChange: (mode: MapMode) => void;
  onCanvasClick: (e: React.MouseEvent<HTMLDivElement>) => void;
  onRemovePlant: (id: number) => void;
  onDragPlant: (id: number, newX: number, newY: number) => void;
  onCancelPlacement: () => void;
  getPlantColor: (type: string) => string;
  unitLabels: Record<string, string>;
}

export const PlanningCanvas = ({
  plotConfig,
  gridItems,
  selectedPlant,
  showGrid,
  mapMode,
  timeOfDay,
  onMapModeChange,
  onCanvasClick,
  onRemovePlant,
  onDragPlant,
  onCancelPlacement,
  getPlantColor,
  unitLabels,
}: PlanningCanvasProps) => {
  const [zoom, setZoom] = useState(100);
  const [draggedItem, setDraggedItem] = useState<number | null>(null);

  // Define plantable zones based on map mode
  const getPlantableZones = () => {
    if (mapMode === "building") {
      return {
        type: "building",
        zones: [
          { x1: 1, y1: 0, x2: plotConfig.width - 2, y2: 1 },
          { x1: 0, y1: 2, x2: 0, y2: plotConfig.height - 2 },
          { x1: plotConfig.width - 1, y1: 2, x2: plotConfig.width - 1, y2: plotConfig.height - 2 },
          { x1: 1, y1: plotConfig.height - 1, x2: plotConfig.width - 2, y2: plotConfig.height - 1 },
        ]
      };
    } else if (mapMode === "balcony") {
      // Balcony mode: rectangular balcony with railing, plantable inside
      return {
        type: "balcony",
        zones: [
          // Main balcony floor area (inner area excluding railing)
          { x1: 1, y1: 1, x2: plotConfig.width - 2, y2: plotConfig.height - 2 },
        ]
      };
    } else {
      const centerStart = Math.floor(plotConfig.width / 2) - 1;
      const centerEnd = Math.floor(plotConfig.width / 2) + 1;
      return {
        type: "street-divider",
        zones: [
          { x1: centerStart, y1: 0, x2: centerEnd, y2: plotConfig.height - 1 },
        ]
      };
    }
  };

  const isInPlantableZone = (x: number, y: number) => {
    const { zones } = getPlantableZones();
    return zones.some(zone => 
      x >= zone.x1 && x <= zone.x2 && y >= zone.y1 && y <= zone.y2
    );
  };

  const handleDragStart = (e: React.DragEvent, itemId: number) => {
    e.stopPropagation();
    setDraggedItem(itemId);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedItem) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / plotConfig.cellSize);
    const y = Math.floor((e.clientY - rect.top) / plotConfig.cellSize);

    if (x < 0 || x >= plotConfig.width || y < 0 || y >= plotConfig.height) {
      setDraggedItem(null);
      return;
    }

    const isOccupied = gridItems.some(item => item.x === x && item.y === y && item.id !== draggedItem);
    if (!isOccupied) {
      onDragPlant(draggedItem, x, y);
    }
    
    setDraggedItem(null);
  };

  const totalArea = plotConfig.width * plotConfig.height;
  const waterEstimate = gridItems.length * 15;

  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      {/* Canvas Header */}
      <div className="mb-4 flex flex-col gap-3 border-b border-border pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {mapMode === "building" ? (
              <Building2 className="h-5 w-5 text-primary" />
            ) : mapMode === "balcony" ? (
              <Sun className="h-5 w-5 text-primary" />
            ) : (
              <RailSymbol className="h-5 w-5 text-primary" />
            )}
            <span className="font-medium text-foreground">
              {mapMode === "building" ? "Building Area" : mapMode === "balcony" ? "Balcony Garden" : "Street Divider"}
            </span>
            <Badge variant="secondary" className="ml-2">
              {plotConfig.width} × {plotConfig.height} {unitLabels[plotConfig.unit]}
            </Badge>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Zoom: {zoom}%</span>
            <div className="flex gap-1">
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom(Math.max(50, zoom - 10))}>
                <ZoomOut className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom(Math.min(200, zoom + 10))}>
                <ZoomIn className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Map Mode Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Map Type:</span>
          <div className="flex rounded-lg border border-border overflow-hidden">
            <button
              onClick={() => onMapModeChange("building")}
              className={`flex items-center gap-2 px-3 py-1.5 text-sm transition-colors ${
                mapMode === "building"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background hover:bg-secondary text-muted-foreground"
              }`}
            >
              <Building2 className="h-4 w-4" />
              Building Area
            </button>
            <button
              onClick={() => onMapModeChange("street-divider")}
              className={`flex items-center gap-2 px-3 py-1.5 text-sm transition-colors ${
                mapMode === "street-divider"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background hover:bg-secondary text-muted-foreground"
              }`}
            >
              <RailSymbol className="h-4 w-4" />
              Street Divider
            </button>
            <button
              onClick={() => onMapModeChange("balcony")}
              className={`flex items-center gap-2 px-3 py-1.5 text-sm transition-colors ${
                mapMode === "balcony"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background hover:bg-secondary text-muted-foreground"
              }`}
            >
              <Sun className="h-4 w-4" />
              Balcony
            </button>
          </div>
        </div>
      </div>

      {/* Selected Plant Indicator */}
      {selectedPlant && (
        <div className="mb-4 flex items-center gap-2 rounded-lg bg-primary/10 p-3">
          <Leaf className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">Placing: {selectedPlant.name}</span>
          <span className="text-xs text-muted-foreground">— Click on grid to place</span>
          <Button variant="ghost" size="sm" className="ml-auto h-7" onClick={onCancelPlacement}>
            Cancel
          </Button>
        </div>
      )}

      {/* Grid Canvas */}
      <div className="relative overflow-auto rounded-xl" style={{ maxHeight: "500px" }}>
        <div 
          className="relative transition-transform duration-200 ml-6 mt-6"
          style={{ 
            transform: `scale(${zoom / 100})`, 
            transformOrigin: "top left",
            width: plotConfig.width * plotConfig.cellSize,
            height: plotConfig.height * plotConfig.cellSize,
            cursor: selectedPlant ? "crosshair" : "default",
            backgroundColor: mapMode === "building" ? "hsl(var(--muted))" : mapMode === "balcony" ? "hsl(200 30% 85%)" : "hsl(var(--muted) / 0.5)",
          }}
          onClick={onCanvasClick}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          {/* Map Background Layer */}
          {mapMode === "building" ? (
            // Building structure visualization
            <>
              {/* Building body (non-plantable) */}
              <div 
                className="absolute bg-gradient-to-b from-slate-400 to-slate-500 border-2 border-slate-600"
                style={{
                  left: plotConfig.cellSize,
                  top: 2 * plotConfig.cellSize,
                  width: (plotConfig.width - 2) * plotConfig.cellSize,
                  height: (plotConfig.height - 3) * plotConfig.cellSize,
                }}
              >
                {Array.from({ length: Math.floor((plotConfig.height - 4) / 2) }).map((_, row) => (
                  <div key={row} className="flex justify-around py-2" style={{ marginTop: row === 0 ? '8px' : '0' }}>
                    {Array.from({ length: Math.min(4, plotConfig.width - 4) }).map((_, col) => (
                      <div 
                        key={col} 
                        className="bg-sky-200/60 border border-slate-600 rounded-sm"
                        style={{ width: plotConfig.cellSize * 0.6, height: plotConfig.cellSize * 0.8 }}
                      />
                    ))}
                  </div>
                ))}
              </div>
              <div 
                className="absolute bg-forest/20 border-2 border-dashed border-forest rounded-t-lg"
                style={{ left: plotConfig.cellSize, top: 0, width: (plotConfig.width - 2) * plotConfig.cellSize, height: 2 * plotConfig.cellSize }}
              >
                <span className="absolute top-1 left-2 text-[10px] font-medium text-forest">Rooftop Garden</span>
              </div>
              <div 
                className="absolute bg-forest/20 border-2 border-dashed border-forest rounded-l-lg"
                style={{ left: 0, top: 2 * plotConfig.cellSize, width: plotConfig.cellSize, height: (plotConfig.height - 4) * plotConfig.cellSize }}
              >
                <span className="absolute top-1 left-1 text-[9px] font-medium text-forest rotate-90 origin-top-left" style={{ whiteSpace: 'nowrap' }}>Balconies</span>
              </div>
              <div 
                className="absolute bg-forest/20 border-2 border-dashed border-forest rounded-r-lg"
                style={{ right: 0, top: 2 * plotConfig.cellSize, width: plotConfig.cellSize, height: (plotConfig.height - 4) * plotConfig.cellSize }}
              />
              <div 
                className="absolute bg-forest/20 border-2 border-dashed border-forest rounded-b-lg"
                style={{ left: plotConfig.cellSize, bottom: 0, width: (plotConfig.width - 2) * plotConfig.cellSize, height: plotConfig.cellSize }}
              >
                <span className="absolute top-1 left-2 text-[10px] font-medium text-forest">Ground Planters</span>
              </div>
            </>
          ) : mapMode === "balcony" ? (
            // Balcony visualization
            <>
              {/* Railing - top */}
              <div 
                className="absolute bg-gradient-to-b from-amber-700 to-amber-800 border border-amber-900"
                style={{ left: 0, top: 0, width: plotConfig.width * plotConfig.cellSize, height: plotConfig.cellSize }}
              >
                {/* Railing bars */}
                {Array.from({ length: plotConfig.width }).map((_, i) => (
                  <div key={i} className="absolute bg-amber-600 rounded-sm" style={{ left: i * plotConfig.cellSize + plotConfig.cellSize * 0.4, top: 2, width: 3, height: plotConfig.cellSize - 4 }} />
                ))}
                <span className="absolute top-1 left-2 text-[10px] font-medium text-amber-200">Railing</span>
              </div>
              {/* Railing - bottom */}
              <div 
                className="absolute bg-gradient-to-b from-amber-700 to-amber-800 border border-amber-900"
                style={{ left: 0, bottom: 0, width: plotConfig.width * plotConfig.cellSize, height: plotConfig.cellSize }}
              >
                {Array.from({ length: plotConfig.width }).map((_, i) => (
                  <div key={i} className="absolute bg-amber-600 rounded-sm" style={{ left: i * plotConfig.cellSize + plotConfig.cellSize * 0.4, top: 2, width: 3, height: plotConfig.cellSize - 4 }} />
                ))}
                <span className="absolute top-1 left-2 text-[10px] font-medium text-amber-200">Wall Side</span>
              </div>
              {/* Railing - left */}
              <div 
                className="absolute bg-gradient-to-r from-amber-700 to-amber-800 border border-amber-900"
                style={{ left: 0, top: plotConfig.cellSize, width: plotConfig.cellSize, height: (plotConfig.height - 2) * plotConfig.cellSize }}
              />
              {/* Railing - right */}
              <div 
                className="absolute bg-gradient-to-l from-amber-700 to-amber-800 border border-amber-900"
                style={{ right: 0, top: plotConfig.cellSize, width: plotConfig.cellSize, height: (plotConfig.height - 2) * plotConfig.cellSize }}
              />
              {/* Inner plantable area */}
              <div 
                className="absolute bg-forest/15 border-2 border-dashed border-forest rounded-lg"
                style={{
                  left: plotConfig.cellSize,
                  top: plotConfig.cellSize,
                  width: (plotConfig.width - 2) * plotConfig.cellSize,
                  height: (plotConfig.height - 2) * plotConfig.cellSize,
                }}
              >
                <span className="absolute top-1 left-2 text-[10px] font-medium text-forest">🌱 Balcony Planting Area</span>
              </div>
              {/* Floor tiles pattern */}
              <div 
                className="absolute pointer-events-none opacity-20"
                style={{
                  left: plotConfig.cellSize,
                  top: plotConfig.cellSize,
                  width: (plotConfig.width - 2) * plotConfig.cellSize,
                  height: (plotConfig.height - 2) * plotConfig.cellSize,
                  backgroundImage: `
                    linear-gradient(45deg, hsl(30 20% 60%) 25%, transparent 25%),
                    linear-gradient(-45deg, hsl(30 20% 60%) 25%, transparent 25%),
                    linear-gradient(45deg, transparent 75%, hsl(30 20% 60%) 75%),
                    linear-gradient(-45deg, transparent 75%, hsl(30 20% 60%) 75%)
                  `,
                  backgroundSize: `${plotConfig.cellSize}px ${plotConfig.cellSize}px`,
                  backgroundPosition: `0 0, 0 ${plotConfig.cellSize/2}px, ${plotConfig.cellSize/2}px -${plotConfig.cellSize/2}px, -${plotConfig.cellSize/2}px 0px`,
                }}
              />
            </>
          ) : (
            // Street divider visualization
            <>
              {/* Left road */}
              <div 
                className="absolute bg-slate-600"
                style={{
                  left: 0,
                  top: 0,
                  width: (Math.floor(plotConfig.width / 2) - 1) * plotConfig.cellSize,
                  height: plotConfig.height * plotConfig.cellSize,
                }}
              >
                {/* Road markings */}
                {Array.from({ length: plotConfig.height }).map((_, i) => (
                  <div 
                    key={i}
                    className="absolute bg-yellow-400"
                    style={{
                      right: 4,
                      top: i * plotConfig.cellSize + plotConfig.cellSize * 0.3,
                      width: 3,
                      height: plotConfig.cellSize * 0.4,
                    }}
                  />
                ))}
                <span className="absolute top-2 left-2 text-[10px] font-medium text-white/70">Road</span>
              </div>
              {/* Right road */}
              <div 
                className="absolute bg-slate-600"
                style={{
                  right: 0,
                  top: 0,
                  width: (Math.floor(plotConfig.width / 2) - 1) * plotConfig.cellSize,
                  height: plotConfig.height * plotConfig.cellSize,
                }}
              >
                {/* Road markings */}
                {Array.from({ length: plotConfig.height }).map((_, i) => (
                  <div 
                    key={i}
                    className="absolute bg-yellow-400"
                    style={{
                      left: 4,
                      top: i * plotConfig.cellSize + plotConfig.cellSize * 0.3,
                      width: 3,
                      height: plotConfig.cellSize * 0.4,
                    }}
                  />
                ))}
                <span className="absolute top-2 right-2 text-[10px] font-medium text-white/70">Road</span>
              </div>
              {/* Center divider - plantable area */}
              <div 
                className="absolute bg-forest/20 border-2 border-dashed border-forest"
                style={{
                  left: (Math.floor(plotConfig.width / 2) - 1) * plotConfig.cellSize,
                  top: 0,
                  width: 3 * plotConfig.cellSize,
                  height: plotConfig.height * plotConfig.cellSize,
                }}
              >
                <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-medium text-forest whitespace-nowrap">Planting Strip</span>
              </div>
            </>
          )}

          {/* Dynamic Shadow Overlay */}
          {(() => {
            // Calculate shadow based on time of day
            // Morning (6-12): shadows cast from east (right side)
            // Afternoon (12-20): shadows cast from west (left side)
            const sunAngle = ((timeOfDay - 6) / 14) * 180; // 0 to 180 degrees
            const shadowDirection = timeOfDay < 13 ? 'right' : 'left';
            const shadowIntensity = Math.abs(timeOfDay - 13) / 7; // Longer shadows at dawn/dusk
            const shadowLength = shadowIntensity * 3; // Max 3 cells of shadow
            
            if (mapMode === 'building') {
              return (
                <>
                  <div 
                    className="absolute pointer-events-none transition-all duration-500"
                    style={{
                      left: shadowDirection === 'left' 
                        ? plotConfig.cellSize - (shadowLength * plotConfig.cellSize)
                        : plotConfig.cellSize,
                      top: 2 * plotConfig.cellSize,
                      width: (plotConfig.width - 2) * plotConfig.cellSize,
                      height: (plotConfig.height - 2) * plotConfig.cellSize,
                      background: `linear-gradient(${shadowDirection === 'left' ? '90deg' : '270deg'}, 
                        rgba(0,0,0,${0.3 * shadowIntensity}) 0%, 
                        transparent ${Math.min(100, shadowLength * 30)}%)`,
                      transform: `skewX(${shadowDirection === 'left' ? -15 + (sunAngle * 0.1) : 15 - (sunAngle * 0.1)}deg)`,
                    }}
                  />
                  <div 
                    className="absolute pointer-events-none transition-all duration-500"
                    style={{
                      left: plotConfig.cellSize, top: 0,
                      width: (plotConfig.width - 2) * plotConfig.cellSize, height: 2 * plotConfig.cellSize,
                      background: `linear-gradient(180deg, rgba(255,200,50,${0.15 * (1 - shadowIntensity * 0.5)}) 0%, transparent 100%)`,
                    }}
                  />
                  {timeOfDay >= 14 && (
                    <div className="absolute pointer-events-none transition-all duration-500"
                      style={{ left: 0, top: 2 * plotConfig.cellSize, width: plotConfig.cellSize, height: (plotConfig.height - 4) * plotConfig.cellSize, background: `rgba(0,0,0,${0.2 + shadowIntensity * 0.2})` }}
                    />
                  )}
                  {timeOfDay < 12 && (
                    <div className="absolute pointer-events-none transition-all duration-500"
                      style={{ right: 0, top: 2 * plotConfig.cellSize, width: plotConfig.cellSize, height: (plotConfig.height - 4) * plotConfig.cellSize, background: `rgba(0,0,0,${0.2 + shadowIntensity * 0.2})` }}
                    />
                  )}
                  <div className="absolute pointer-events-none transition-all duration-500 rounded-full blur-xl"
                    style={{ width: 60, height: 60, background: 'radial-gradient(circle, rgba(255,200,50,0.4) 0%, transparent 70%)', left: shadowDirection === 'left' ? plotConfig.width * plotConfig.cellSize - 30 : -30, top: Math.max(0, (1 - Math.abs(timeOfDay - 13) / 7) * plotConfig.height * plotConfig.cellSize * 0.3) - 30 }}
                  />
                </>
              );
            } else if (mapMode === 'balcony') {
              // Balcony gets overhead sun with railing shadows
              return (
                <>
                  {/* Railing shadow from top railing */}
                  <div className="absolute pointer-events-none transition-all duration-500"
                    style={{
                      left: plotConfig.cellSize,
                      top: plotConfig.cellSize,
                      width: (plotConfig.width - 2) * plotConfig.cellSize,
                      height: Math.min(2, shadowLength) * plotConfig.cellSize,
                      background: `linear-gradient(180deg, rgba(0,0,0,${0.15 * shadowIntensity}) 0%, transparent 100%)`,
                    }}
                  />
                  {/* Sun glow on open area */}
                  {timeOfDay >= 10 && timeOfDay <= 16 && (
                    <div className="absolute pointer-events-none transition-all duration-500"
                      style={{
                        left: plotConfig.cellSize, top: plotConfig.cellSize,
                        width: (plotConfig.width - 2) * plotConfig.cellSize,
                        height: (plotConfig.height - 2) * plotConfig.cellSize,
                        background: `radial-gradient(ellipse at 50% 30%, rgba(255,200,50,${0.12 * (1 - Math.abs(timeOfDay - 13) / 3)}) 0%, transparent 70%)`,
                      }}
                    />
                  )}
                </>
              );
            } else {
              const centerStart = Math.floor(plotConfig.width / 2) - 1;
              return (
                <>
                  {timeOfDay < 10 && (
                    <div className="absolute pointer-events-none transition-all duration-500"
                      style={{ left: centerStart * plotConfig.cellSize, top: 0, width: 3 * plotConfig.cellSize, height: plotConfig.height * plotConfig.cellSize, background: `linear-gradient(270deg, rgba(0,0,0,${0.3 * (1 - timeOfDay / 10)}) 0%, transparent 60%)` }}
                    />
                  )}
                  {timeOfDay > 16 && (
                    <div className="absolute pointer-events-none transition-all duration-500"
                      style={{ left: centerStart * plotConfig.cellSize, top: 0, width: 3 * plotConfig.cellSize, height: plotConfig.height * plotConfig.cellSize, background: `linear-gradient(90deg, rgba(0,0,0,${0.3 * ((timeOfDay - 16) / 4)}) 0%, transparent 60%)` }}
                    />
                  )}
                  {timeOfDay >= 10 && timeOfDay <= 16 && (
                    <div className="absolute pointer-events-none transition-all duration-500"
                      style={{ left: centerStart * plotConfig.cellSize, top: 0, width: 3 * plotConfig.cellSize, height: plotConfig.height * plotConfig.cellSize, background: `linear-gradient(180deg, rgba(255,200,50,${0.1 * (1 - Math.abs(timeOfDay - 13) / 3)}) 0%, transparent 50%)` }}
                    />
                  )}
                </>
              );
            }
          })()}

          {/* Mini Sun Position Indicator */}
          <div 
            className="absolute pointer-events-none"
            style={{
              top: 8,
              right: 8,
              width: 80,
              height: 50,
            }}
          >
            {/* Background */}
            <div 
              className="absolute inset-0 rounded-lg overflow-hidden"
              style={{
                background: timeOfDay < 7 || timeOfDay > 19
                  ? 'linear-gradient(180deg, hsl(220 30% 20%) 0%, hsl(220 20% 35%) 100%)'
                  : timeOfDay < 10 || timeOfDay > 17
                  ? 'linear-gradient(180deg, hsl(30 80% 70%) 0%, hsl(200 60% 75%) 100%)'
                  : 'linear-gradient(180deg, hsl(200 80% 65%) 0%, hsl(200 70% 85%) 100%)',
                border: '1px solid hsl(var(--border) / 0.5)',
              }}
            >
              {/* Ground line */}
              <div 
                className="absolute bottom-0 left-0 right-0 h-3"
                style={{
                  background: mapMode === 'building' 
                    ? 'hsl(var(--muted))' 
                    : 'hsl(220 10% 40%)',
                }}
              />
            </div>
            
            {/* Sun arc path */}
            <svg 
              className="absolute inset-0 w-full h-full"
              viewBox="0 0 80 50"
              style={{ overflow: 'visible' }}
            >
              {/* Arc path (dashed) */}
              <path
                d="M 10 42 Q 40 -5 70 42"
                fill="none"
                stroke="hsl(45 90% 60% / 0.4)"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              
              {/* Sun position */}
              {(() => {
                // Map time (6-20) to arc position (0-1)
                const progress = Math.max(0, Math.min(1, (timeOfDay - 6) / 14));
                // Parametric quadratic bezier: B(t) = (1-t)²P0 + 2(1-t)tP1 + t²P2
                const t = progress;
                const x = (1-t)*(1-t)*10 + 2*(1-t)*t*40 + t*t*70;
                const y = (1-t)*(1-t)*42 + 2*(1-t)*t*(-5) + t*t*42;
                
                const isNight = timeOfDay < 6 || timeOfDay > 20;
                
                return (
                  <>
                    {/* Sun glow */}
                    <circle
                      cx={x}
                      cy={y}
                      r="12"
                      fill={isNight ? 'transparent' : 'hsl(45 100% 60% / 0.3)'}
                    />
                    {/* Sun */}
                    <circle
                      cx={x}
                      cy={y}
                      r="6"
                      fill={isNight ? 'hsl(45 20% 80%)' : 'hsl(45 100% 55%)'}
                      stroke={isNight ? 'hsl(45 20% 60%)' : 'hsl(35 100% 45%)'}
                      strokeWidth="1"
                    />
                    {/* Sun rays (only during day) */}
                    {!isNight && timeOfDay >= 8 && timeOfDay <= 18 && (
                      <>
                        {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => (
                          <line
                            key={angle}
                            x1={x + Math.cos(angle * Math.PI / 180) * 7}
                            y1={y + Math.sin(angle * Math.PI / 180) * 7}
                            x2={x + Math.cos(angle * Math.PI / 180) * 9}
                            y2={y + Math.sin(angle * Math.PI / 180) * 9}
                            stroke="hsl(45 100% 55%)"
                            strokeWidth="1"
                            strokeLinecap="round"
                          />
                        ))}
                      </>
                    )}
                  </>
                );
              })()}
            </svg>
            
            {/* Time label */}
            <div 
              className="absolute bottom-0.5 left-1/2 -translate-x-1/2 text-[9px] font-medium"
              style={{
                color: timeOfDay < 7 || timeOfDay > 19 ? 'hsl(0 0% 80%)' : 'hsl(var(--foreground))',
                textShadow: '0 1px 2px rgba(0,0,0,0.3)',
              }}
            >
              {timeOfDay}:00
            </div>
            
            {/* Direction indicators */}
            <div 
              className="absolute bottom-0.5 left-1 text-[7px] font-medium"
              style={{
                color: timeOfDay < 7 || timeOfDay > 19 ? 'hsl(0 0% 60%)' : 'hsl(var(--muted-foreground))',
              }}
            >
              E
            </div>
            <div 
              className="absolute bottom-0.5 right-1 text-[7px] font-medium"
              style={{
                color: timeOfDay < 7 || timeOfDay > 19 ? 'hsl(0 0% 60%)' : 'hsl(var(--muted-foreground))',
              }}
            >
              W
            </div>
          </div>

          {/* Grid Background */}
          {showGrid && (
            <div 
              className="absolute inset-0 pointer-events-none"
              style={{
                backgroundImage: `
                  linear-gradient(hsl(var(--border) / 0.5) 1px, transparent 1px),
                  linear-gradient(90deg, hsl(var(--border) / 0.5) 1px, transparent 1px)
                `,
                backgroundSize: `${plotConfig.cellSize}px ${plotConfig.cellSize}px`,
              }}
            />
          )}

          {/* Grid measurements - X axis */}
          <div className="absolute -top-5 left-0 flex text-xs text-muted-foreground">
            {Array.from({ length: plotConfig.width }).map((_, i) => (
              <div key={i} className="text-center" style={{ width: plotConfig.cellSize }}>
                {i + 1}
              </div>
            ))}
          </div>
          
          {/* Grid measurements - Y axis */}
          <div className="absolute -left-5 top-0 flex flex-col text-xs text-muted-foreground">
            {Array.from({ length: plotConfig.height }).map((_, i) => (
              <div key={i} className="flex items-center justify-center" style={{ height: plotConfig.cellSize }}>
                {i + 1}
              </div>
            ))}
          </div>
          
          {/* Planted Items */}
          {gridItems.map((item) => (
            <div
              key={item.id}
              draggable
              onDragStart={(e) => handleDragStart(e, item.id)}
              className="absolute flex cursor-move flex-col items-center justify-center rounded-lg border-2 border-dashed transition-all hover:scale-105 hover:shadow-lg group"
              style={{
                left: `${item.x * plotConfig.cellSize + 2}px`,
                top: `${item.y * plotConfig.cellSize + 2}px`,
                width: `${plotConfig.cellSize - 4}px`,
                height: `${plotConfig.cellSize - 4}px`,
                backgroundColor: `hsl(var(--${getPlantColor(item.type)}) / 0.2)`,
                borderColor: `hsl(var(--${getPlantColor(item.type)}))`,
                opacity: draggedItem === item.id ? 0.5 : 1,
              }}
              onClick={(e) => {
                e.stopPropagation();
                if (!selectedPlant) onRemovePlant(item.id);
              }}
              title={`${item.name} - Drag to move, Click to remove`}
            >
              <Leaf className="h-4 w-4 text-forest" />
              <span className="mt-0.5 text-[10px] font-medium text-foreground truncate max-w-full px-1">
                {item.name}
              </span>
              <div className="absolute inset-0 bg-destructive/20 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                <Trash2 className="h-4 w-4 text-destructive" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Canvas Footer */}
      <div className="mt-4 flex flex-wrap gap-2">
        <Badge className="bg-card text-foreground shadow-sm border">
          <Leaf className="mr-1 h-3 w-3" /> {gridItems.length} Plants
        </Badge>
        <Badge className="bg-card text-foreground shadow-sm border">
          <Droplets className="mr-1 h-3 w-3" /> {waterEstimate}L/week
        </Badge>
        <Badge className="bg-card text-foreground shadow-sm border">
          <Ruler className="mr-1 h-3 w-3" /> {totalArea} {unitLabels[plotConfig.unit]}²
        </Badge>
      </div>
    </div>
  );
};