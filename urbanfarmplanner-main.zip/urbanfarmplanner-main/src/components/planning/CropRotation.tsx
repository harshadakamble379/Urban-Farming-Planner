import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RotateCcw, Leaf, AlertTriangle, CheckCircle2, ArrowRight } from "lucide-react";
import { plantData, PlantFamily, SoilImpact } from "@/data/plantData";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface CropRotationProps {
  gridItems: PlantItem[];
  getPlantColor: (type: string) => string;
}

const familyLabels: Record<PlantFamily, string> = {
  flowering: "Flowering Plants",
  foliage: "Foliage Plants",
  palm: "Palms",
  succulent: "Succulents",
  fern: "Ferns",
  vine: "Vines",
  herb: "Herbs",
};

const soilImpactLabels: Record<SoilImpact, { label: string; color: string }> = {
  "heavy-feeder": { label: "Heavy Feeder", color: "bg-destructive/20 text-destructive" },
  "moderate-feeder": { label: "Moderate Feeder", color: "bg-warning/20 text-warning-foreground" },
  "light-feeder": { label: "Light Feeder", color: "bg-secondary text-secondary-foreground" },
  "nitrogen-fixer": { label: "Nitrogen Fixer", color: "bg-forest/20 text-forest" },
};

// Rotation sequence: Heavy Feeders → Light Feeders → Legumes (N-fixers) → Moderate Feeders
const rotationSequence: SoilImpact[] = ["heavy-feeder", "light-feeder", "nitrogen-fixer", "moderate-feeder"];

const getNextRotation = (currentImpact: SoilImpact): SoilImpact => {
  const currentIndex = rotationSequence.indexOf(currentImpact);
  return rotationSequence[(currentIndex + 1) % rotationSequence.length];
};

const getRecommendedPlants = (targetImpact: SoilImpact, excludeFamilies: PlantFamily[]): string[] => {
  return plantData
    .filter(p => p.soilImpact === targetImpact && !excludeFamilies.includes(p.family))
    .map(p => p.name)
    .slice(0, 3);
};

export function CropRotation({ gridItems, getPlantColor }: CropRotationProps) {
  // Analyze current plants
  const currentPlants = gridItems.map(item => {
    const plantInfo = plantData.find(p => p.name === item.name);
    return plantInfo;
  }).filter(Boolean);

  // Group by family
  const familyCounts: Record<PlantFamily, number> = {
    flowering: 0,
    foliage: 0,
    palm: 0,
    succulent: 0,
    fern: 0,
    vine: 0,
    herb: 0,
  };

  const soilImpactCounts: Record<SoilImpact, number> = {
    "heavy-feeder": 0,
    "moderate-feeder": 0,
    "light-feeder": 0,
    "nitrogen-fixer": 0,
  };

  currentPlants.forEach(plant => {
    if (plant) {
      familyCounts[plant.family]++;
      soilImpactCounts[plant.soilImpact]++;
    }
  });

  const usedFamilies = Object.entries(familyCounts)
    .filter(([_, count]) => count > 0)
    .map(([family]) => family as PlantFamily);

  // Determine dominant soil impact
  const dominantImpact = Object.entries(soilImpactCounts)
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])[0]?.[0] as SoilImpact | undefined;

  // Calculate soil health score
  const totalPlants = currentPlants.length;
  const nitrogenFixers = soilImpactCounts["nitrogen-fixer"];
  const heavyFeeders = soilImpactCounts["heavy-feeder"];
  
  let soilHealthScore = 100;
  if (totalPlants > 0) {
    // Penalize for too many heavy feeders without nitrogen fixers
    if (heavyFeeders > 0 && nitrogenFixers === 0) {
      soilHealthScore -= Math.min(40, heavyFeeders * 10);
    }
    // Bonus for balanced planting
    const uniqueImpacts = Object.values(soilImpactCounts).filter(c => c > 0).length;
    soilHealthScore += uniqueImpacts * 5;
    // Penalize monoculture
    if (usedFamilies.length === 1 && totalPlants > 3) {
      soilHealthScore -= 20;
    }
  }
  soilHealthScore = Math.max(0, Math.min(100, soilHealthScore));

  // Generate rotation recommendations
  const nextSeasonRecommendation = dominantImpact 
    ? getNextRotation(dominantImpact)
    : "nitrogen-fixer";

  const recommendedPlants = getRecommendedPlants(nextSeasonRecommendation, usedFamilies);

  const warnings: string[] = [];
  if (heavyFeeders > totalPlants * 0.6 && totalPlants > 2) {
    warnings.push("Too many heavy feeders may deplete soil nutrients quickly");
  }
  if (usedFamilies.length === 1 && totalPlants > 3) {
    warnings.push("Planting the same family repeatedly increases pest and disease risk");
  }
  if (nitrogenFixers === 0 && totalPlants > 4) {
    warnings.push("Consider adding legumes to naturally replenish soil nitrogen");
  }

  return (
    <Card className="shadow-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <RotateCcw className="h-5 w-5 text-primary" />
          Crop Rotation Guide
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Soil Health Score */}
        <div className="rounded-lg bg-muted p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Soil Health Score</span>
            <span className={`text-lg font-bold ${
              soilHealthScore >= 80 ? "text-forest" : 
              soilHealthScore >= 60 ? "text-warning-foreground" : "text-destructive"
            }`}>
              {soilHealthScore}%
            </span>
          </div>
          <div className="h-2 rounded-full bg-secondary">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                soilHealthScore >= 80 ? "bg-forest" : 
                soilHealthScore >= 60 ? "bg-warning" : "bg-destructive"
              }`}
              style={{ width: `${soilHealthScore}%` }}
            />
          </div>
        </div>

        {/* Current Plant Distribution */}
        {totalPlants > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-foreground">Current Distribution</h4>
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(soilImpactCounts)
                .filter(([_, count]) => count > 0)
                .map(([impact, count]) => (
                  <Badge 
                    key={impact} 
                    variant="outline"
                    className={soilImpactLabels[impact as SoilImpact].color}
                  >
                    {soilImpactLabels[impact as SoilImpact].label}: {count}
                  </Badge>
                ))}
            </div>
          </div>
        )}

        {/* Warnings */}
        {warnings.length > 0 && (
          <div className="space-y-2">
            {warnings.map((warning, i) => (
              <div key={i} className="flex items-start gap-2 rounded-lg bg-warning/10 p-2.5 text-sm">
                <AlertTriangle className="h-4 w-4 text-warning-foreground shrink-0 mt-0.5" />
                <span className="text-warning-foreground">{warning}</span>
              </div>
            ))}
          </div>
        )}

        {/* Next Season Recommendation */}
        <div className="rounded-lg border border-border p-3 space-y-2">
          <div className="flex items-center gap-2">
            <ArrowRight className="h-4 w-4 text-primary" />
            <h4 className="text-sm font-medium">Next Season Recommendation</h4>
          </div>
          <p className="text-sm text-muted-foreground">
            Plant <span className="font-medium text-foreground">
              {soilImpactLabels[nextSeasonRecommendation].label}s
            </span> to maintain soil balance
          </p>
          {recommendedPlants.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {recommendedPlants.map(plant => {
                const plantInfo = plantData.find(p => p.name === plant);
                return (
                  <Badge 
                    key={plant} 
                    variant="secondary"
                    className="flex items-center gap-1"
                  >
                    <Leaf className="h-3 w-3" />
                    {plant}
                  </Badge>
                );
              })}
            </div>
          )}
        </div>

        {/* Family Summary */}
        {usedFamilies.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-foreground">Plant Families Used</h4>
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              {usedFamilies.map(family => (
                <div 
                  key={family}
                  className="flex items-center gap-1.5 rounded bg-secondary/50 px-2 py-1.5"
                >
                  <CheckCircle2 className="h-3 w-3 text-forest" />
                  <span>{familyLabels[family]}</span>
                  <span className="ml-auto text-muted-foreground">×{familyCounts[family]}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              Avoid planting the same families in consecutive seasons
            </p>
          </div>
        )}

        {totalPlants === 0 && (
          <p className="text-sm text-muted-foreground text-center py-2">
            Add plants to see rotation recommendations
          </p>
        )}
      </CardContent>
    </Card>
  );
}