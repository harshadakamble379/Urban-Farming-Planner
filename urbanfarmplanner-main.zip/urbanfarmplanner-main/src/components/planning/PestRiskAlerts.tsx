import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { 
  Bug, 
  Thermometer, 
  Droplets,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Shield,
  Info
} from "lucide-react";
import { plantData } from "@/data/plantData";

interface PlantItem {
  id: number;
  type: "vegetable" | "herb" | "leafy" | "fruit";
  name: string;
  x: number;
  y: number;
  plantedAt?: string;
}

interface PestRiskAlertsProps {
  gridItems: PlantItem[];
  getPlantColor: (type: string) => string;
}

interface PestRisk {
  name: string;
  description: string;
  affectedPlants: string[];
  riskLevel: "high" | "medium" | "low";
  conditions: string;
  prevention: string;
}

interface DiseaseRisk {
  name: string;
  description: string;
  affectedPlants: string[];
  riskLevel: "high" | "medium" | "low";
  conditions: string;
  prevention: string;
}

// Pest data based on typical urban farming conditions
const pestDatabase: PestRisk[] = [
  {
    name: "Aphids",
    description: "Small sap-sucking insects that cluster on new growth",
    affectedPlants: ["Tomatoes", "Peppers", "Lettuce", "Spinach", "Basil"],
    riskLevel: "high",
    conditions: "Warm temps (18-25°C), moderate humidity",
    prevention: "Spray with water, introduce ladybugs, use neem oil",
  },
  {
    name: "Spider Mites",
    description: "Tiny arachnids causing yellowing and webbing on leaves",
    affectedPlants: ["Tomatoes", "Peppers", "Strawberry", "Basil"],
    riskLevel: "medium",
    conditions: "Hot, dry conditions (>25°C, <40% humidity)",
    prevention: "Increase humidity, spray undersides of leaves, use insecticidal soap",
  },
  {
    name: "Whiteflies",
    description: "Small white flying insects that weaken plants",
    affectedPlants: ["Tomatoes", "Peppers", "Lettuce", "Basil"],
    riskLevel: "medium",
    conditions: "Warm temps (20-30°C), greenhouse-like conditions",
    prevention: "Yellow sticky traps, reflective mulch, encourage natural predators",
  },
  {
    name: "Slugs & Snails",
    description: "Night feeders that leave holes in leaves",
    affectedPlants: ["Lettuce", "Spinach", "Strawberry", "Basil"],
    riskLevel: "high",
    conditions: "Moist conditions, mild temps, rainy periods",
    prevention: "Copper tape barriers, beer traps, evening patrol",
  },
  {
    name: "Caterpillars",
    description: "Larvae that chew large holes in foliage",
    affectedPlants: ["Lettuce", "Spinach", "Basil", "Mint"],
    riskLevel: "low",
    conditions: "Summer months, butterfly activity",
    prevention: "Hand-pick, use row covers, Bt spray",
  },
];

const diseaseDatabase: DiseaseRisk[] = [
  {
    name: "Powdery Mildew",
    description: "White powdery coating on leaves",
    affectedPlants: ["Basil", "Rosemary", "Mint", "Strawberry"],
    riskLevel: "high",
    conditions: "High humidity (>60%), poor air circulation, 15-27°C",
    prevention: "Improve airflow, avoid wetting leaves, use fungicide",
  },
  {
    name: "Blight",
    description: "Dark spots and wilting on stems and leaves",
    affectedPlants: ["Tomatoes", "Peppers"],
    riskLevel: "high",
    conditions: "Cool, wet conditions, 10-25°C with high moisture",
    prevention: "Water at base, remove affected parts, rotate crops",
  },
  {
    name: "Root Rot",
    description: "Mushy brown roots and wilting despite watering",
    affectedPlants: ["Basil", "Rosemary", "Mint", "Lettuce", "Spinach"],
    riskLevel: "medium",
    conditions: "Overwatering, poor drainage, waterlogged soil",
    prevention: "Ensure good drainage, let soil dry between watering",
  },
  {
    name: "Downy Mildew",
    description: "Yellow patches with fuzzy gray growth underneath",
    affectedPlants: ["Lettuce", "Spinach", "Basil"],
    riskLevel: "medium",
    conditions: "Cool temps (10-20°C), high humidity, wet leaves",
    prevention: "Morning watering, resistant varieties, good spacing",
  },
  {
    name: "Leaf Spot",
    description: "Brown or black spots on leaves",
    affectedPlants: ["Tomatoes", "Peppers", "Strawberry", "Lettuce"],
    riskLevel: "low",
    conditions: "Warm, humid conditions, water splashing",
    prevention: "Mulch to prevent splash, remove infected leaves",
  },
];

// Simulated current conditions (would be from weather API in production)
const getCurrentConditions = () => ({
  temperature: 22, // Celsius
  humidity: 65, // Percentage
  recentRain: true,
  season: "summer" as const,
});

export const PestRiskAlerts = ({
  gridItems,
  getPlantColor,
}: PestRiskAlertsProps) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState<"pests" | "diseases">("pests");

  const conditions = getCurrentConditions();

  // Get unique plant names from grid
  const plantNames = [...new Set(gridItems.map(item => item.name))];

  // Filter risks based on plants in the garden
  const relevantPests = pestDatabase.filter(pest => 
    pest.affectedPlants.some(plant => plantNames.includes(plant))
  );

  const relevantDiseases = diseaseDatabase.filter(disease => 
    disease.affectedPlants.some(plant => plantNames.includes(plant))
  );

  // Calculate condition-based risk adjustments
  const getConditionRisk = (riskType: "pest" | "disease") => {
    let riskScore = 0;
    
    // Temperature factor
    if (conditions.temperature >= 20 && conditions.temperature <= 28) {
      riskScore += 2; // Optimal for most pests
    }
    
    // Humidity factor
    if (conditions.humidity > 60) {
      riskScore += riskType === "disease" ? 3 : 1; // Diseases thrive in humidity
    }
    
    // Rain factor
    if (conditions.recentRain) {
      riskScore += riskType === "disease" ? 2 : 1;
    }
    
    if (riskScore >= 5) return "high";
    if (riskScore >= 3) return "medium";
    return "low";
  };

  const overallPestRisk = getConditionRisk("pest");
  const overallDiseaseRisk = getConditionRisk("disease");

  const getRiskColor = (level: string) => {
    switch (level) {
      case "high": return "text-destructive";
      case "medium": return "text-amber-500";
      case "low": return "text-forest";
      default: return "text-muted-foreground";
    }
  };

  const getRiskBg = (level: string) => {
    switch (level) {
      case "high": return "bg-destructive/10";
      case "medium": return "bg-amber-500/10";
      case "low": return "bg-forest/10";
      default: return "bg-muted";
    }
  };

  if (gridItems.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Bug className="h-5 w-5 text-primary" />
          <h3 className="font-semibold text-foreground">Pest & Disease Alerts</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          Add plants to see pest and disease risk alerts based on conditions.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <div 
        className="flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <Bug className="h-5 w-5 text-primary" />
          <h3 className="font-semibold text-foreground">Pest & Disease Alerts</h3>
          {(overallPestRisk === "high" || overallDiseaseRisk === "high") && (
            <Badge variant="destructive" className="text-xs animate-pulse">
              <AlertTriangle className="h-3 w-3 mr-1" />
              Alert
            </Badge>
          )}
        </div>
        {isExpanded ? (
          <ChevronUp className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        )}
      </div>

      {isExpanded && (
        <div className="mt-4 space-y-4">
          {/* Current Conditions */}
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg bg-secondary/50 p-2 text-center">
              <Thermometer className="h-4 w-4 mx-auto text-amber-500" />
              <p className="text-sm font-medium mt-1">{conditions.temperature}°C</p>
              <p className="text-[10px] text-muted-foreground">Temperature</p>
            </div>
            <div className="rounded-lg bg-secondary/50 p-2 text-center">
              <Droplets className="h-4 w-4 mx-auto text-blue-500" />
              <p className="text-sm font-medium mt-1">{conditions.humidity}%</p>
              <p className="text-[10px] text-muted-foreground">Humidity</p>
            </div>
            <div className="rounded-lg bg-secondary/50 p-2 text-center">
              <Shield className={`h-4 w-4 mx-auto ${getRiskColor(overallPestRisk)}`} />
              <p className={`text-sm font-medium mt-1 capitalize ${getRiskColor(overallPestRisk)}`}>
                {overallPestRisk}
              </p>
              <p className="text-[10px] text-muted-foreground">Risk Level</p>
            </div>
          </div>

          {/* Tab Switcher */}
          <div className="flex rounded-lg border border-border overflow-hidden">
            <button
              onClick={(e) => { e.stopPropagation(); setActiveTab("pests"); }}
              className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm transition-colors ${
                activeTab === "pests"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background hover:bg-secondary text-muted-foreground"
              }`}
            >
              <Bug className="h-4 w-4" />
              Pests ({relevantPests.length})
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); setActiveTab("diseases"); }}
              className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm transition-colors ${
                activeTab === "diseases"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background hover:bg-secondary text-muted-foreground"
              }`}
            >
              <AlertTriangle className="h-4 w-4" />
              Diseases ({relevantDiseases.length})
            </button>
          </div>

          {/* Risk List */}
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {activeTab === "pests" ? (
              relevantPests.length > 0 ? (
                relevantPests.map((pest) => (
                  <div 
                    key={pest.name}
                    className={`rounded-lg border border-border p-3 ${getRiskBg(pest.riskLevel)}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Bug className={`h-4 w-4 ${getRiskColor(pest.riskLevel)}`} />
                        <span className="font-medium text-sm">{pest.name}</span>
                      </div>
                      <Badge className={`${getRiskBg(pest.riskLevel)} ${getRiskColor(pest.riskLevel)} border-0 capitalize`}>
                        {pest.riskLevel}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{pest.description}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {pest.affectedPlants
                        .filter(p => plantNames.includes(p))
                        .map(plant => {
                          const plantInfo = plantData.find(pd => pd.name === plant);
                          return (
                            <Badge 
                              key={plant} 
                              variant="outline" 
                              className="text-[10px]"
                              style={{ 
                                borderColor: plantInfo ? `hsl(var(--${getPlantColor(plantInfo.type)}))` : undefined,
                                color: plantInfo ? `hsl(var(--${getPlantColor(plantInfo.type)}))` : undefined,
                              }}
                            >
                              {plant}
                            </Badge>
                          );
                        })}
                    </div>
                    <div className="mt-2 pt-2 border-t border-border/50">
                      <div className="flex items-start gap-1">
                        <Shield className="h-3 w-3 text-forest mt-0.5" />
                        <p className="text-[11px] text-muted-foreground">{pest.prevention}</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4 text-muted-foreground text-sm">
                  No pest risks for your current plants
                </div>
              )
            ) : (
              relevantDiseases.length > 0 ? (
                relevantDiseases.map((disease) => (
                  <div 
                    key={disease.name}
                    className={`rounded-lg border border-border p-3 ${getRiskBg(disease.riskLevel)}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className={`h-4 w-4 ${getRiskColor(disease.riskLevel)}`} />
                        <span className="font-medium text-sm">{disease.name}</span>
                      </div>
                      <Badge className={`${getRiskBg(disease.riskLevel)} ${getRiskColor(disease.riskLevel)} border-0 capitalize`}>
                        {disease.riskLevel}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{disease.description}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {disease.affectedPlants
                        .filter(p => plantNames.includes(p))
                        .map(plant => {
                          const plantInfo = plantData.find(pd => pd.name === plant);
                          return (
                            <Badge 
                              key={plant} 
                              variant="outline" 
                              className="text-[10px]"
                              style={{ 
                                borderColor: plantInfo ? `hsl(var(--${getPlantColor(plantInfo.type)}))` : undefined,
                                color: plantInfo ? `hsl(var(--${getPlantColor(plantInfo.type)}))` : undefined,
                              }}
                            >
                              {plant}
                            </Badge>
                          );
                        })}
                    </div>
                    <div className="mt-2 pt-2 border-t border-border/50">
                      <div className="flex items-start gap-1">
                        <Shield className="h-3 w-3 text-forest mt-0.5" />
                        <p className="text-[11px] text-muted-foreground">{disease.prevention}</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4 text-muted-foreground text-sm">
                  No disease risks for your current plants
                </div>
              )
            )}
          </div>

          {/* Info Note */}
          <div className="rounded-lg bg-muted/50 p-3">
            <div className="flex items-start gap-2">
              <Info className="h-4 w-4 text-muted-foreground mt-0.5" />
              <p className="text-xs text-muted-foreground">
                Risk levels are calculated based on current weather conditions, humidity, and the specific plants in your garden.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
