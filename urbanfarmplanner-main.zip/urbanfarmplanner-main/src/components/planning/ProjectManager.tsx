import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Save, FolderOpen, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface Project {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
}

interface ProjectManagerProps {
  projects: Project[];
  currentProjectId: string | null;
  onSave: (name: string) => void;
  onLoad: (projectId: string) => void;
  onDelete: (projectId: string) => void;
  loading: boolean;
}

export const ProjectManager = ({
  projects,
  currentProjectId,
  onSave,
  onLoad,
  onDelete,
  loading,
}: ProjectManagerProps) => {
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [loadDialogOpen, setLoadDialogOpen] = useState(false);
  const [projectName, setProjectName] = useState("");

  const handleSave = () => {
    if (!projectName.trim()) {
      toast.error("Please enter a project name");
      return;
    }
    onSave(projectName);
    setSaveDialogOpen(false);
    setProjectName("");
  };

  const handleLoad = (projectId: string) => {
    onLoad(projectId);
    setLoadDialogOpen(false);
  };

  const handleDelete = (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this project?")) {
      onDelete(projectId);
    }
  };

  return (
    <>
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-1.5 text-sm px-3">
            <Save className="h-4 w-4 shrink-0" />
            <span className="truncate">Save</span>
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Project</DialogTitle>
            <DialogDescription>
              {currentProjectId 
                ? "Update your current project or save as a new one" 
                : "Save your farm layout to load it later"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="project-name">Project Name</Label>
              <Input
                id="project-name"
                placeholder="My Urban Farm"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setSaveDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={loading}>
              {loading ? "Saving..." : "Save"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-1.5 text-sm px-3">
            <FolderOpen className="h-4 w-4 shrink-0" />
            <span className="truncate">Load</span>
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Load Project</DialogTitle>
            <DialogDescription>
              Select a project to load
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-y-auto py-4">
            {projects.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No saved projects yet
              </p>
            ) : (
              projects.map((project) => (
                <div
                  key={project.id}
                  className={`flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer hover:border-primary ${
                    currentProjectId === project.id ? "border-primary bg-primary/10" : "border-border"
                  }`}
                  onClick={() => handleLoad(project.id)}
                >
                  <div>
                    <p className="font-medium text-foreground">{project.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Updated: {new Date(project.updated_at).toLocaleDateString()}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-destructive hover:text-destructive"
                    onClick={(e) => handleDelete(project.id, e)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};