import { ReactNode, useState, useEffect } from "react";
import { Sidebar, MobileHeader } from "./Sidebar";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

const SIDEBAR_STORAGE_KEY = "urbangrow-sidebar-collapsed";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const isMobile = useIsMobile();
  const [mobileOpen, setMobileOpen] = useState(false);
  
  // Initialize from localStorage, default to false (expanded)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(SIDEBAR_STORAGE_KEY);
      return stored === "true";
    }
    return false;
  });

  // Persist to localStorage when changed
  useEffect(() => {
    localStorage.setItem(SIDEBAR_STORAGE_KEY, String(sidebarCollapsed));
  }, [sidebarCollapsed]);

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      {isMobile && <MobileHeader onMenuClick={() => setMobileOpen(true)} />}
      
      {/* Sidebar */}
      <Sidebar 
        collapsed={sidebarCollapsed} 
        onCollapsedChange={setSidebarCollapsed}
        isMobile={isMobile}
        mobileOpen={mobileOpen}
        onMobileOpenChange={setMobileOpen}
      />
      
      {/* Main Content */}
      <main className={cn(
        "min-h-screen transition-all duration-300",
        isMobile ? "pt-16 ml-0" : (sidebarCollapsed ? "ml-16" : "ml-64")
      )}>
        <div className={cn("p-4 md:p-6 lg:p-8")}>
          {children}
        </div>
      </main>
    </div>
  );
}
