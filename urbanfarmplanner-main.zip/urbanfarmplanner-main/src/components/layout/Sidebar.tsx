import { NavLink } from "@/components/NavLink";
import { 
  LayoutDashboard, 
  Map, 
  Leaf, 
  Droplets, 
  Package, 
  Settings,
  Sprout,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  MessageSquare,
  Camera
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Map, label: "Planning", path: "/planning" },
  { icon: Leaf, label: "Plants", path: "/plants" },
  { icon: Droplets, label: "Resources", path: "/resources" },
  { icon: Package, label: "Inventory", path: "/inventory" },
  { icon: MessageSquare, label: "Community", path: "/community" },
  { icon: Camera, label: "Identify Plant", path: "/identify" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

interface SidebarProps {
  collapsed?: boolean;
  onCollapsedChange?: (collapsed: boolean) => void;
  isMobile?: boolean;
  mobileOpen?: boolean;
  onMobileOpenChange?: (open: boolean) => void;
}

// Desktop Sidebar
function DesktopSidebar({ collapsed, onCollapsedChange }: { collapsed: boolean; onCollapsedChange: (v: boolean) => void }) {
  return (
    <aside 
      className={cn(
        "fixed left-0 top-0 z-40 h-screen bg-gradient-hero transition-all duration-300 hidden md:block",
        collapsed ? "w-16" : "w-64"
      )}
    >
      <div className="flex h-full flex-col">
        {/* Toggle Button & Logo */}
        <div className={cn(
          "flex items-center border-b border-sidebar-border py-3 transition-all duration-300",
          collapsed ? "flex-col gap-3 px-2" : "gap-3 px-4"
        )}>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onCollapsedChange(!collapsed)}
            className="h-8 w-8 shrink-0 text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
          
          <div className={cn("flex items-center gap-3 transition-all duration-300", collapsed && "flex-col")}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent shrink-0">
              <Sprout className="h-6 w-6 text-accent-foreground" />
            </div>
            {!collapsed && (
              <div className="overflow-hidden">
                <h1 className="text-lg font-bold text-sidebar-foreground">UrbanGrow</h1>
                <p className="text-xs text-sidebar-foreground/70">Farming Simulator</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 px-3 py-4">
          {navItems.map((item) => (
            collapsed ? (
              <Tooltip key={item.path} delayDuration={0}>
                <TooltipTrigger asChild>
                  <NavLink
                    to={item.path}
                    className="flex items-center justify-center rounded-lg p-3 text-sm font-medium text-sidebar-foreground/80 transition-all duration-200 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                    activeClassName="bg-sidebar-accent text-sidebar-foreground shadow-sm"
                  >
                    <item.icon className="h-5 w-5" />
                  </NavLink>
                </TooltipTrigger>
                <TooltipContent side="right" sideOffset={10}>
                  {item.label}
                </TooltipContent>
              </Tooltip>
            ) : (
              <NavLink
                key={item.path}
                to={item.path}
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-sidebar-foreground/80 transition-all duration-200 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                activeClassName="bg-sidebar-accent text-sidebar-foreground shadow-sm"
              >
                <item.icon className="h-5 w-5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </NavLink>
            )
          ))}
        </nav>

        {/* Footer */}
        {!collapsed && (
          <div className="border-t border-sidebar-border p-4">
            <div className="rounded-lg bg-sidebar-accent/50 p-4">
              <p className="text-xs font-medium text-sidebar-foreground">Pro Tip</p>
              <p className="mt-1 text-xs text-sidebar-foreground/70">
                Start with smaller plots for better yield management.
              </p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}

// Mobile Sidebar (Sheet/Drawer)
function MobileSidebar({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-64 p-0 bg-gradient-hero border-sidebar-border">
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex items-center gap-3 border-b border-sidebar-border px-4 py-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent shrink-0">
              <Sprout className="h-6 w-6 text-accent-foreground" />
            </div>
            <div className="overflow-hidden">
              <h1 className="text-lg font-bold text-sidebar-foreground">UrbanGrow</h1>
              <p className="text-xs text-sidebar-foreground/70">Farming Simulator</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-1 px-3 py-4">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => onOpenChange(false)}
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-sidebar-foreground/80 transition-all duration-200 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                activeClassName="bg-sidebar-accent text-sidebar-foreground shadow-sm"
              >
                <item.icon className="h-5 w-5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </NavLink>
            ))}
          </nav>

          {/* Footer */}
          <div className="border-t border-sidebar-border p-4">
            <div className="rounded-lg bg-sidebar-accent/50 p-4">
              <p className="text-xs font-medium text-sidebar-foreground">Pro Tip</p>
              <p className="mt-1 text-xs text-sidebar-foreground/70">
                Start with smaller plots for better yield management.
              </p>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// Mobile Header with Hamburger Menu
export function MobileHeader({ onMenuClick }: { onMenuClick: () => void }) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex items-center gap-3 border-b border-border bg-background/95 backdrop-blur px-4 py-3 md:hidden">
      <Button
        variant="ghost"
        size="icon"
        onClick={onMenuClick}
        className="h-9 w-9"
      >
        <Menu className="h-5 w-5" />
      </Button>
      <div className="flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent">
          <Sprout className="h-5 w-5 text-accent-foreground" />
        </div>
        <span className="font-semibold">UrbanGrow</span>
      </div>
    </header>
  );
}

export function Sidebar({ 
  collapsed = false, 
  onCollapsedChange, 
  isMobile = false, 
  mobileOpen = false, 
  onMobileOpenChange 
}: SidebarProps) {
  if (isMobile) {
    return <MobileSidebar open={mobileOpen} onOpenChange={onMobileOpenChange || (() => {})} />;
  }
  
  return <DesktopSidebar collapsed={collapsed} onCollapsedChange={onCollapsedChange || (() => {})} />;
}
