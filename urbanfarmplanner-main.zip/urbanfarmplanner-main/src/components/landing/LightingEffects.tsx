import { motion, AnimatePresence } from "framer-motion";
import { useMemo } from "react";

type TimeOfDay = "dawn" | "day" | "dusk" | "night";

interface LightingEffectsProps {
  timeOfDay: TimeOfDay;
}

export const LightingEffects = ({ timeOfDay }: LightingEffectsProps) => {
  // Generate sun rays for dawn
  const sunRays = useMemo(() => 
    Array.from({ length: 12 }, (_, i) => ({
      id: i,
      angle: (i * 30) - 60,
      length: 200 + Math.random() * 150,
      opacity: 0.15 + Math.random() * 0.15,
      delay: i * 0.1,
    })),
    []
  );

  // Generate aurora waves for night
  const auroraWaves = useMemo(() =>
    Array.from({ length: 5 }, (_, i) => ({
      id: i,
      yOffset: 10 + i * 8,
      color: i % 2 === 0 
        ? `rgba(100, 255, 180, ${0.15 + i * 0.03})` 
        : `rgba(150, 100, 255, ${0.12 + i * 0.02})`,
      duration: 8 + i * 2,
      delay: i * 0.5,
    })),
    []
  );

  // Dusk glow colors
  const isDawn = timeOfDay === "dawn";
  const isDusk = timeOfDay === "dusk";
  const isNight = timeOfDay === "night";

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-[2]">
      {/* Dawn sun rays */}
      <AnimatePresence>
        {isDawn && (
          <motion.div
            className="absolute"
            style={{
              right: "-5%",
              top: "10%",
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 }}
          >
            {/* Sun glow */}
            <motion.div
              className="absolute rounded-full"
              style={{
                width: 150,
                height: 150,
                background: "radial-gradient(circle, rgba(255, 200, 100, 0.8) 0%, rgba(255, 150, 50, 0.4) 40%, transparent 70%)",
                filter: "blur(20px)",
              }}
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.8, 1, 0.8],
              }}
              transition={{ duration: 4, repeat: Infinity }}
            />
            
            {/* Sun rays */}
            {sunRays.map(ray => (
              <motion.div
                key={ray.id}
                className="absolute origin-left"
                style={{
                  width: ray.length,
                  height: 3,
                  left: 75,
                  top: 75,
                  background: `linear-gradient(to right, rgba(255, 200, 100, ${ray.opacity}), transparent)`,
                  transform: `rotate(${ray.angle}deg)`,
                  filter: "blur(2px)",
                }}
                initial={{ scaleX: 0, opacity: 0 }}
                animate={{ 
                  scaleX: [0.5, 1, 0.5],
                  opacity: [ray.opacity * 0.5, ray.opacity, ray.opacity * 0.5],
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  delay: ray.delay,
                }}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dusk warm glow on horizon */}
      <AnimatePresence>
        {isDusk && (
          <motion.div
            className="absolute inset-x-0 bottom-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 }}
          >
            {/* Horizon glow */}
            <motion.div
              className="absolute inset-x-0 bottom-0 h-64"
              style={{
                background: "linear-gradient(to top, rgba(255, 100, 50, 0.3), rgba(255, 150, 100, 0.15), transparent)",
              }}
              animate={{
                opacity: [0.6, 0.8, 0.6],
              }}
              transition={{ duration: 5, repeat: Infinity }}
            />
            
            {/* Sun setting effect */}
            <motion.div
              className="absolute rounded-full"
              style={{
                width: 120,
                height: 60,
                left: "50%",
                bottom: -30,
                transform: "translateX(-50%)",
                background: "radial-gradient(ellipse at center bottom, rgba(255, 100, 0, 0.6) 0%, rgba(255, 50, 50, 0.3) 50%, transparent 80%)",
                filter: "blur(15px)",
              }}
              animate={{
                scale: [1, 1.1, 1],
              }}
              transition={{ duration: 4, repeat: Infinity }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Night aurora borealis */}
      <AnimatePresence>
        {isNight && (
          <motion.div
            className="absolute inset-x-0 top-0 h-96"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2 }}
          >
            {auroraWaves.map(wave => (
              <motion.div
                key={wave.id}
                className="absolute inset-x-0"
                style={{
                  top: `${wave.yOffset}%`,
                  height: "80px",
                }}
              >
                <motion.div
                  className="w-full h-full"
                  style={{
                    background: `linear-gradient(90deg, transparent 0%, ${wave.color} 20%, ${wave.color} 50%, ${wave.color} 80%, transparent 100%)`,
                    filter: "blur(30px)",
                    transformOrigin: "center",
                  }}
                  animate={{
                    scaleX: [0.8, 1.2, 0.9, 1.1, 0.8],
                    x: ["-10%", "10%", "-5%", "15%", "-10%"],
                    opacity: [0.4, 0.7, 0.5, 0.8, 0.4],
                  }}
                  transition={{
                    duration: wave.duration,
                    repeat: Infinity,
                    delay: wave.delay,
                    ease: "easeInOut",
                  }}
                />
              </motion.div>
            ))}
            
            {/* Aurora shimmer particles */}
            {Array.from({ length: 20 }).map((_, i) => (
              <motion.div
                key={`shimmer-${i}`}
                className="absolute rounded-full"
                style={{
                  width: 2 + Math.random() * 3,
                  height: 2 + Math.random() * 3,
                  left: `${5 + Math.random() * 90}%`,
                  top: `${10 + Math.random() * 50}%`,
                  background: i % 2 === 0 
                    ? "rgba(100, 255, 180, 0.8)" 
                    : "rgba(180, 100, 255, 0.8)",
                }}
                animate={{
                  opacity: [0, 1, 0],
                  scale: [0.5, 1, 0.5],
                }}
                transition={{
                  duration: 2 + Math.random() * 2,
                  repeat: Infinity,
                  delay: Math.random() * 3,
                }}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Day ambient light - subtle sun glow */}
      <AnimatePresence>
        {timeOfDay === "day" && (
          <motion.div
            className="absolute"
            style={{
              top: "-10%",
              right: "20%",
              width: 300,
              height: 300,
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
          >
            <motion.div
              className="w-full h-full rounded-full"
              style={{
                background: "radial-gradient(circle, rgba(255, 255, 200, 0.3) 0%, rgba(255, 255, 150, 0.1) 40%, transparent 70%)",
                filter: "blur(40px)",
              }}
              animate={{
                scale: [1, 1.05, 1],
                opacity: [0.5, 0.7, 0.5],
              }}
              transition={{ duration: 6, repeat: Infinity }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
