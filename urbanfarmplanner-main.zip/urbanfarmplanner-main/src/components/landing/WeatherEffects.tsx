import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface Raindrop {
  id: number;
  x: number;
  delay: number;
  duration: number;
  size: number;
}

interface Cloud {
  id: number;
  x: number;
  y: number;
  scale: number;
  speed: number;
  opacity: number;
}

interface LightningBolt {
  id: number;
  x: number;
  segments: { x: number; y: number }[];
  brightness: number;
}

type TimeOfDay = "dawn" | "day" | "dusk" | "night";

interface WeatherEffectsProps {
  isRaining?: boolean;
  showClouds?: boolean;
  isNight?: boolean;
  timeOfDay?: TimeOfDay;
  onWindChange?: (windIntensity: number) => void;
}

// Cloud colors based on time of day
const cloudColors: Record<TimeOfDay, { primary: string; secondary: string; tertiary: string }> = {
  dawn: { 
    primary: "bg-rose-200/60", 
    secondary: "bg-orange-200/50", 
    tertiary: "bg-pink-100/40" 
  },
  day: { 
    primary: "bg-white/80", 
    secondary: "bg-white/70", 
    tertiary: "bg-slate-100/60" 
  },
  dusk: { 
    primary: "bg-orange-300/60", 
    secondary: "bg-purple-300/50", 
    tertiary: "bg-pink-200/40" 
  },
  night: { 
    primary: "bg-slate-600/50", 
    secondary: "bg-slate-700/40", 
    tertiary: "bg-indigo-800/30" 
  },
};

// Cloud speed multiplier based on time
const cloudSpeedMultiplier: Record<TimeOfDay, number> = {
  dawn: 0.8,
  day: 1,
  dusk: 0.6,
  night: 0.4,
};

export const WeatherEffects = ({ 
  isRaining = false, 
  showClouds = true, 
  isNight = false, 
  timeOfDay = "day",
  onWindChange 
}: WeatherEffectsProps) => {
  const [raindrops, setRaindrops] = useState<Raindrop[]>([]);
  const [clouds, setClouds] = useState<Cloud[]>([]);
  const [lightning, setLightning] = useState<LightningBolt | null>(null);
  const [screenFlash, setScreenFlash] = useState(false);
  const [showRainbow, setShowRainbow] = useState(false);
  const [windIntensity, setWindIntensity] = useState(0);
  const wasRainingRef = useRef(false);
  const lightningTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recurringTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Handle wind intensity changes
  useEffect(() => {
    if (isRaining) {
      // Ramp up wind during storm
      const interval = setInterval(() => {
        setWindIntensity(prev => Math.min(1, prev + 0.1));
      }, 200);
      return () => clearInterval(interval);
    } else {
      // Ramp down wind when rain stops
      const interval = setInterval(() => {
        setWindIntensity(prev => Math.max(0, prev - 0.05));
      }, 100);
      return () => clearInterval(interval);
    }
  }, [isRaining]);

  // Notify parent of wind changes
  useEffect(() => {
    onWindChange?.(windIntensity);
  }, [windIntensity, onWindChange]);

  // Show rainbow when rain stops during daytime
  useEffect(() => {
    if (wasRainingRef.current && !isRaining && !isNight) {
      setShowRainbow(true);
      const timeout = setTimeout(() => setShowRainbow(false), 8000);
      return () => clearTimeout(timeout);
    }
    wasRainingRef.current = isRaining;
  }, [isRaining, isNight]);

  // Generate lightning bolt path
  const generateLightningPath = useCallback(() => {
    const startX = 20 + Math.random() * 60;
    const segments: { x: number; y: number }[] = [{ x: startX, y: 0 }];
    let currentX = startX;
    let currentY = 0;
    
    const numSegments = 6 + Math.floor(Math.random() * 4);
    
    for (let i = 0; i < numSegments; i++) {
      currentY += (100 / numSegments) * (0.8 + Math.random() * 0.4);
      currentX += (Math.random() - 0.5) * 15;
      currentX = Math.max(5, Math.min(95, currentX));
      segments.push({ x: currentX, y: currentY });
    }
    
    return {
      id: Date.now(),
      x: startX,
      segments,
      brightness: 0.8 + Math.random() * 0.2,
    };
  }, []);

  // Trigger lightning during rain - stops immediately when rain stops
  useEffect(() => {
    // Clear any existing timeouts when rain state changes
    if (lightningTimeoutRef.current) {
      clearTimeout(lightningTimeoutRef.current);
      lightningTimeoutRef.current = null;
    }
    if (recurringTimeoutRef.current) {
      clearTimeout(recurringTimeoutRef.current);
      recurringTimeoutRef.current = null;
    }

    if (!isRaining) {
      setLightning(null);
      setScreenFlash(false);
      return;
    }

    const triggerLightning = () => {
      if (!isRaining) return; // Double check we're still raining
      
      const bolt = generateLightningPath();
      setLightning(bolt);
      setScreenFlash(true);
      
      // Multiple flashes
      setTimeout(() => setScreenFlash(false), 100);
      setTimeout(() => setScreenFlash(true), 150);
      setTimeout(() => setScreenFlash(false), 200);
      setTimeout(() => {
        if (Math.random() > 0.5) {
          setScreenFlash(true);
          setTimeout(() => setScreenFlash(false), 50);
        }
      }, 300);
      
      // Clear lightning
      setTimeout(() => setLightning(null), 400);
    };

    // Random lightning strikes
    const scheduleNextLightning = () => {
      const delay = 3000 + Math.random() * 5000;
      recurringTimeoutRef.current = setTimeout(() => {
        if (isRaining) {
          triggerLightning();
          scheduleNextLightning();
        }
      }, delay);
    };

    // Initial strike after short delay
    lightningTimeoutRef.current = setTimeout(triggerLightning, 1500);
    scheduleNextLightning();

    return () => {
      if (lightningTimeoutRef.current) {
        clearTimeout(lightningTimeoutRef.current);
      }
      if (recurringTimeoutRef.current) {
        clearTimeout(recurringTimeoutRef.current);
      }
    };
  }, [isRaining, generateLightningPath]);

  // Initialize clouds
  useEffect(() => {
    const initialClouds: Cloud[] = Array.from({ length: 6 }, (_, i) => ({
      id: i,
      x: Math.random() * 120 - 10,
      y: 5 + Math.random() * 20,
      scale: 0.8 + Math.random() * 0.8,
      speed: 0.02 + Math.random() * 0.03,
      opacity: 0.3 + Math.random() * 0.4,
    }));
    setClouds(initialClouds);
  }, []);

// Animate clouds - speed varies by time of day, faster during rain/wind
  useEffect(() => {
    const speedMultiplier = cloudSpeedMultiplier[timeOfDay];
    const interval = setInterval(() => {
      setClouds(prev => prev.map(cloud => ({
        ...cloud,
        x: cloud.x > 110 ? -20 : cloud.x + cloud.speed * speedMultiplier * (1 + windIntensity * 3),
        opacity: isRaining ? Math.min(0.8, cloud.opacity + 0.1) : cloud.opacity,
      })));
    }, 50);
    return () => clearInterval(interval);
  }, [isRaining, windIntensity, timeOfDay]);

  // Generate raindrops when raining
  useEffect(() => {
    if (!isRaining) {
      setRaindrops([]);
      return;
    }

    const initialDrops: Raindrop[] = Array.from({ length: 100 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      delay: Math.random() * 2,
      duration: 0.5 + Math.random() * 0.5,
      size: 1 + Math.random() * 2,
    }));
    setRaindrops(initialDrops);
  }, [isRaining]);

  // Generate SVG path for lightning bolt
  const getLightningPath = (segments: { x: number; y: number }[]) => {
    if (segments.length < 2) return "";
    let path = `M ${segments[0].x} ${segments[0].y}`;
    for (let i = 1; i < segments.length; i++) {
      path += ` L ${segments[i].x} ${segments[i].y}`;
    }
    return path;
  };

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-10">
      {/* Rainbow effect */}
      <AnimatePresence>
        {showRainbow && (
          <motion.div
            className="absolute top-10 left-1/2 -translate-x-1/2"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 1.5 }}
            style={{
              width: '80vw',
              height: '40vw',
              maxWidth: '800px',
              maxHeight: '400px',
              borderRadius: '50% 50% 0 0',
              background: `
                linear-gradient(180deg, 
                  transparent 0%, 
                  transparent 40%,
                  rgba(255, 0, 0, 0.15) 42%,
                  rgba(255, 127, 0, 0.15) 48%,
                  rgba(255, 255, 0, 0.15) 54%,
                  rgba(0, 255, 0, 0.15) 60%,
                  rgba(0, 0, 255, 0.15) 66%,
                  rgba(75, 0, 130, 0.15) 72%,
                  rgba(148, 0, 211, 0.15) 78%,
                  transparent 84%
                )
              `,
              filter: 'blur(8px)',
            }}
          />
        )}
      </AnimatePresence>

      {/* Screen flash for lightning */}
      <AnimatePresence>
        {screenFlash && isRaining && (
          <motion.div
            className="absolute inset-0 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.05 }}
            style={{
              background: "radial-gradient(ellipse at center, rgba(255,255,255,0.9) 0%, rgba(200,200,255,0.4) 50%, transparent 80%)",
            }}
          />
        )}
      </AnimatePresence>

      {/* Lightning bolt */}
      <AnimatePresence>
        {lightning && isRaining && (
          <motion.svg
            className="absolute inset-0 w-full h-full z-40"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 0.3, 1, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, times: [0, 0.1, 0.2, 0.3, 1] }}
          >
            {/* Main bolt */}
            <motion.path
              d={getLightningPath(lightning.segments)}
              fill="none"
              stroke="white"
              strokeWidth="0.8"
              strokeLinecap="round"
              style={{
                filter: `drop-shadow(0 0 10px rgba(255,255,255,${lightning.brightness})) 
                         drop-shadow(0 0 20px rgba(150,150,255,${lightning.brightness}))
                         drop-shadow(0 0 40px rgba(100,100,255,0.5))`,
              }}
            />
            {/* Glow effect */}
            <motion.path
              d={getLightningPath(lightning.segments)}
              fill="none"
              stroke="rgba(200,200,255,0.5)"
              strokeWidth="2"
              strokeLinecap="round"
              style={{
                filter: "blur(2px)",
              }}
            />
            {/* Branch bolts */}
            {lightning.segments.slice(2, -1).map((segment, i) => {
              if (Math.random() > 0.6) return null;
              const branchLength = 5 + Math.random() * 10;
              const branchAngle = (Math.random() > 0.5 ? 1 : -1) * (30 + Math.random() * 30);
              const endX = segment.x + Math.cos((branchAngle * Math.PI) / 180) * branchLength;
              const endY = segment.y + Math.sin((90 + branchAngle) * Math.PI / 180) * branchLength;
              
              return (
                <motion.path
                  key={`branch-${i}`}
                  d={`M ${segment.x} ${segment.y} L ${endX} ${endY}`}
                  fill="none"
                  stroke="white"
                  strokeWidth="0.4"
                  strokeLinecap="round"
                  style={{
                    filter: `drop-shadow(0 0 5px rgba(255,255,255,0.8))`,
                    opacity: 0.7,
                  }}
                />
              );
            })}
          </motion.svg>
        )}
      </AnimatePresence>

      {/* Clouds with time-of-day colors */}
      {showClouds && clouds.map(cloud => {
        const colors = isRaining 
          ? { primary: "bg-slate-800/90", secondary: "bg-slate-700/80", tertiary: "bg-slate-900/70" }
          : cloudColors[timeOfDay];
        
        return (
          <motion.div
            key={`cloud-${cloud.id}`}
            className="absolute"
            style={{
              left: `${cloud.x}%`,
              top: `${cloud.y}%`,
              transform: `scale(${cloud.scale * (isRaining ? 1.3 : 1)})`,
              opacity: isRaining ? 0.9 : cloud.opacity,
            }}
          >
            <div className="relative">
              <div 
                className={`absolute w-20 h-12 rounded-full ${colors.primary} blur-sm transition-colors duration-[2000ms]`}
                style={{ left: 0, top: 0 }}
              />
              <div 
                className={`absolute w-16 h-10 rounded-full ${colors.secondary} blur-sm transition-colors duration-[2000ms]`}
                style={{ left: -10, top: 5 }}
              />
              <div 
                className={`absolute w-24 h-14 rounded-full ${colors.primary} blur-sm transition-colors duration-[2000ms]`}
                style={{ left: 15, top: -5 }}
              />
              <div 
                className={`absolute w-14 h-10 rounded-full ${colors.tertiary} blur-sm transition-colors duration-[2000ms]`}
                style={{ left: 35, top: 3 }}
              />
              <div 
                className={`absolute w-18 h-12 rounded-full ${colors.secondary} blur-sm transition-colors duration-[2000ms]`}
                style={{ left: 5, top: -8 }}
              />
            </div>
          </motion.div>
        );
      })}

      {/* Rain with wind effect */}
      <AnimatePresence>
        {isRaining && raindrops.map(drop => (
          <motion.div
            key={`rain-${drop.id}`}
            className="absolute"
            style={{
              left: `${drop.x}%`,
              width: drop.size,
            }}
            initial={{ top: "-5%", opacity: 0 }}
            animate={{ 
              top: "105%", 
              left: `${drop.x + windIntensity * 20}%`,
              opacity: [0, 0.7, 0.7, 0],
            }}
            transition={{
              duration: drop.duration,
              delay: drop.delay,
              repeat: Infinity,
              ease: "linear",
            }}
          >
            <div 
              className="w-full bg-gradient-to-b from-transparent via-blue-300/60 to-blue-400/80 rounded-full"
              style={{ 
                height: 15 + Math.random() * 10,
                transform: `rotate(${windIntensity * 15}deg)`,
              }}
            />
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Rain splash effects at bottom */}
      {isRaining && (
        <div className="absolute bottom-0 left-0 right-0 h-20">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={`splash-${i}`}
              className="absolute bottom-0"
              style={{ left: `${Math.random() * 100}%` }}
              animate={{
                scale: [0, 1, 0],
                opacity: [0, 0.5, 0],
              }}
              transition={{
                duration: 0.4,
                repeat: Infinity,
                delay: Math.random() * 2,
                repeatDelay: Math.random() * 1,
              }}
            >
              <div className="w-4 h-2 border-t-2 border-blue-300/50 rounded-full" />
            </motion.div>
          ))}
        </div>
      )}

      {/* Storm atmosphere overlay */}
      {isRaining && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-b from-slate-700/30 via-slate-600/20 to-slate-800/40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
        />
      )}
    </div>
  );
};
