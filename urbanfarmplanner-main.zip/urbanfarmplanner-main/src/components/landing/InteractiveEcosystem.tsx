import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flower2, TreeDeciduous, Leaf } from "lucide-react";

interface Plant {
  id: number;
  x: number;
  y: number;
  type: "flower" | "tree" | "sprout";
  color: string;
  scale: number;
}

type ButterflyVariety = "monarch" | "swallowtail" | "morpho" | "painted" | "luna";

interface Butterfly {
  id: number;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  color: string;
  secondaryColor: string;
  wingPhase: number;
  variety: ButterflyVariety;
  size: number;
  speed: number;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  type: "pollen" | "leaf" | "firefly";
  size: number;
  opacity: number;
  speed: number;
}

interface Firefly {
  id: number;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  size: number;
  glowIntensity: number;
  speed: number;
}

const plantTypes = [
  { type: "flower" as const, colors: ["#FF6B9D", "#FFB347", "#87CEEB", "#DDA0DD", "#98D8C8"] },
  { type: "tree" as const, colors: ["#228B22", "#32CD32", "#2E8B57", "#3CB371"] },
  { type: "sprout" as const, colors: ["#90EE90", "#98FB98", "#00FA9A", "#7CFC00"] },
];

const butterflyVarieties: { variety: ButterflyVariety; colors: [string, string][]; sizeRange: [number, number] }[] = [
  { variety: "monarch", colors: [["#FF8C00", "#000000"], ["#FFA500", "#8B4513"]], sizeRange: [1, 1.2] },
  { variety: "swallowtail", colors: [["#FFD700", "#000000"], ["#FFFF00", "#1a1a1a"]], sizeRange: [1.3, 1.5] },
  { variety: "morpho", colors: [["#00BFFF", "#1E90FF"], ["#4169E1", "#0000CD"]], sizeRange: [1.2, 1.4] },
  { variety: "painted", colors: [["#FF69B4", "#FF1493"], ["#DB7093", "#C71585"]], sizeRange: [0.8, 1] },
  { variety: "luna", colors: [["#98FB98", "#00FA9A"], ["#90EE90", "#32CD32"]], sizeRange: [1.4, 1.6] },
];

interface InteractiveEcosystemProps {
  isNight?: boolean;
  windIntensity?: number;
}

export const InteractiveEcosystem = ({ isNight = false, windIntensity = 0 }: InteractiveEcosystemProps) => {
  const [plants, setPlants] = useState<Plant[]>([]);
  const [butterflies, setButterflies] = useState<Butterfly[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [fireflies, setFireflies] = useState<Firefly[]>([]);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const plantIdRef = useRef(0);
  const particleIdRef = useRef(0);
  // Cache dimensions to avoid forced reflows
  const dimensionsRef = useRef({ width: 0, height: 0 });

  // Cache container dimensions on mount and resize
  useEffect(() => {
    const updateDimensions = () => {
      dimensionsRef.current = {
        width: window.innerWidth,
        height: window.innerHeight,
      };
    };
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  // Initialize butterflies with varieties
  useEffect(() => {
    const { width, height } = dimensionsRef.current;
    const initialButterflies: Butterfly[] = Array.from({ length: 8 }, (_, i) => {
      const varietyData = butterflyVarieties[i % butterflyVarieties.length];
      const colorPair = varietyData.colors[Math.floor(Math.random() * varietyData.colors.length)];
      const size = varietyData.sizeRange[0] + Math.random() * (varietyData.sizeRange[1] - varietyData.sizeRange[0]);
      
      return {
        id: i,
        x: Math.random() * width,
        y: Math.random() * height * 0.7,
        targetX: Math.random() * width,
        targetY: Math.random() * height * 0.7,
        color: colorPair[0],
        secondaryColor: colorPair[1],
        wingPhase: Math.random() * Math.PI * 2,
        variety: varietyData.variety,
        size,
        speed: 0.5 + Math.random() * 1,
      };
    });
    setButterflies(initialButterflies);
  }, []);

  // Initialize fireflies
  useEffect(() => {
    const { width, height } = dimensionsRef.current;
    const initialFireflies: Firefly[] = Array.from({ length: 25 }, (_, i) => ({
      id: i,
      x: Math.random() * width,
      y: Math.random() * height,
      targetX: Math.random() * width,
      targetY: Math.random() * height,
      size: 3 + Math.random() * 4,
      glowIntensity: Math.random(),
      speed: 0.3 + Math.random() * 0.5,
    }));
    setFireflies(initialFireflies);
  }, []);

  // Initialize ambient particles
  useEffect(() => {
    const { width, height } = dimensionsRef.current;
    const initialParticles: Particle[] = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * width,
      y: Math.random() * height,
      type: ["pollen", "leaf"][Math.floor(Math.random() * 2)] as Particle["type"],
      size: Math.random() * 8 + 4,
      opacity: Math.random() * 0.6 + 0.2,
      speed: Math.random() * 0.5 + 0.2,
    }));
    setParticles(initialParticles);
    particleIdRef.current = 15;
  }, []);

  // Animate particles with wind effect
  useEffect(() => {
    const interval = setInterval(() => {
      const { width, height } = dimensionsRef.current;
      setParticles(prev => prev.map(p => ({
        ...p,
        x: p.x + Math.sin(Date.now() * 0.001 + p.id) * p.speed + windIntensity * 3,
        y: p.y - p.speed * 0.5 + windIntensity * 0.5,
        opacity: p.y < 0 ? 0 : p.opacity,
      })).filter(p => p.y > -50 && p.x < width + 50).concat(
        Math.random() > 0.97 ? [{
          id: particleIdRef.current++,
          x: Math.random() * width,
          y: height + 20,
          type: ["pollen", "leaf"][Math.floor(Math.random() * 2)] as Particle["type"],
          size: Math.random() * 8 + 4,
          opacity: Math.random() * 0.6 + 0.2,
          speed: Math.random() * 0.5 + 0.2,
        }] : []
      ));
    }, 50);
    return () => clearInterval(interval);
  }, [windIntensity]);

  // Animate fireflies
  useEffect(() => {
    const interval = setInterval(() => {
      const { width, height } = dimensionsRef.current;
      setFireflies(prev => prev.map(f => {
        // Check if reached target, set new target
        const distToTarget = Math.hypot(f.targetX - f.x, f.targetY - f.y);
        let newTargetX = f.targetX;
        let newTargetY = f.targetY;
        
        if (distToTarget < 20) {
          newTargetX = Math.random() * width;
          newTargetY = Math.random() * height;
        }
        
        return {
          ...f,
          x: f.x + (f.targetX - f.x) * 0.01 * f.speed,
          y: f.y + (f.targetY - f.y) * 0.01 * f.speed + Math.sin(Date.now() * 0.003 + f.id) * 0.5,
          targetX: newTargetX,
          targetY: newTargetY,
          glowIntensity: 0.3 + Math.sin(Date.now() * 0.005 + f.id * 0.5) * 0.7,
        };
      }));
    }, 30);
    return () => clearInterval(interval);
  }, []);

  // Update butterfly positions - continuous roaming with mouse influence
  useEffect(() => {
    const interval = setInterval(() => {
      const { width, height } = dimensionsRef.current;
      setButterflies(prev => prev.map((b) => {
        // Calculate distance to mouse
        const distToMouse = Math.hypot(mousePos.x - b.x, mousePos.y - b.y);
        const mouseInfluence = Math.max(0, 1 - distToMouse / 300);
        
        // Check if reached target, set new random target
        const distToTarget = Math.hypot(b.targetX - b.x, b.targetY - b.y);
        let newTargetX = b.targetX;
        let newTargetY = b.targetY;
        
        if (distToTarget < 30) {
          newTargetX = Math.random() * width;
          newTargetY = Math.random() * height * 0.8;
        }
        
        // Blend between random roaming and following mouse
        const finalTargetX = newTargetX * (1 - mouseInfluence * 0.5) + mousePos.x * mouseInfluence * 0.5;
        const finalTargetY = newTargetY * (1 - mouseInfluence * 0.5) + (mousePos.y - 50) * mouseInfluence * 0.5;
        
        // Add some wobble to movement
        const wobbleX = Math.sin(Date.now() * 0.002 + b.id * 0.7) * 2;
        const wobbleY = Math.cos(Date.now() * 0.003 + b.id * 0.5) * 1.5;
        
        return {
          ...b,
          x: b.x + (finalTargetX - b.x) * 0.008 * b.speed + wobbleX,
          y: b.y + (finalTargetY - b.y) * 0.008 * b.speed + wobbleY,
          targetX: newTargetX,
          targetY: newTargetY,
          wingPhase: b.wingPhase + 0.25 + b.speed * 0.1,
        };
      }));
    }, 30);
    return () => clearInterval(interval);
  }, [mousePos]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
  }, []);

  // Use event coordinates directly to avoid getBoundingClientRect reflow
  const handleClick = useCallback((e: React.MouseEvent) => {
    // Use offsetX/offsetY to avoid getBoundingClientRect call
    const x = e.nativeEvent.offsetX;
    const y = e.nativeEvent.offsetY;

    const plantType = plantTypes[Math.floor(Math.random() * plantTypes.length)];
    const color = plantType.colors[Math.floor(Math.random() * plantType.colors.length)];

    const newPlant: Plant = {
      id: plantIdRef.current++,
      x,
      y,
      type: plantType.type,
      color,
      scale: 0.5 + Math.random() * 0.5,
    };

    setPlants(prev => [...prev.slice(-15), newPlant]);

    const newParticles: Particle[] = Array.from({ length: 5 }, () => ({
      id: particleIdRef.current++,
      x: x + (Math.random() - 0.5) * 20,
      y: y,
      type: "pollen" as const,
      size: Math.random() * 4 + 2,
      opacity: 0.8,
      speed: Math.random() * 1 + 0.5,
    }));
    setParticles(prev => [...prev, ...newParticles]);
  }, []);

  const renderButterflyWings = (butterfly: Butterfly, isGlowing: boolean) => {
    const { variety, color, secondaryColor, wingPhase, size } = butterfly;
    const wingFlap = Math.sin(wingPhase) * 60;
    
    const baseWidth = 16 * size;
    const baseHeight = 20 * size;
    
    const getWingStyle = (isLeft: boolean) => {
      const rotation = isLeft ? wingFlap : -wingFlap;
      const baseStyle = {
        width: baseWidth,
        height: baseHeight,
        transform: `rotateY(${rotation}deg) translateY(-50%)`,
        boxShadow: isGlowing 
          ? `0 0 20px ${color}, 0 0 40px ${color}80`
          : `0 0 10px ${color}60`,
      };

      switch (variety) {
        case "monarch":
          return {
            ...baseStyle,
            background: `
              radial-gradient(ellipse at ${isLeft ? '70%' : '30%'} 30%, ${color} 0%, ${color} 40%, ${secondaryColor} 41%, ${secondaryColor} 45%, ${color} 46%),
              linear-gradient(${isLeft ? '135deg' : '-135deg'}, ${color}, ${color}80)
            `,
            borderRadius: isLeft ? "50% 50% 50% 0" : "50% 50% 0 50%",
          };
        case "swallowtail":
          return {
            ...baseStyle,
            width: baseWidth * 1.1,
            height: baseHeight * 1.3,
            background: `
              linear-gradient(${isLeft ? '160deg' : '-160deg'}, 
                ${color} 0%, ${color} 30%, 
                ${secondaryColor} 31%, ${secondaryColor} 35%, 
                ${color} 36%, ${color} 60%,
                ${secondaryColor} 61%, ${secondaryColor} 65%,
                ${color} 66%
              )
            `,
            borderRadius: isLeft ? "50% 60% 80% 0" : "60% 50% 0 80%",
            clipPath: isLeft 
              ? "polygon(0 0, 100% 0, 100% 70%, 80% 100%, 0 80%)"
              : "polygon(0 0, 100% 0, 100% 80%, 20% 100%, 0 70%)",
          };
        case "morpho":
          return {
            ...baseStyle,
            background: `
              radial-gradient(ellipse at 50% 50%, #87CEEB 0%, ${color} 30%, ${secondaryColor} 100%)
            `,
            borderRadius: isLeft ? "60% 40% 40% 10%" : "40% 60% 10% 40%",
            filter: `drop-shadow(0 0 ${isGlowing ? 15 : 8}px ${color})`,
          };
        case "painted":
          return {
            ...baseStyle,
            background: `
              conic-gradient(from ${isLeft ? '0deg' : '180deg'} at 50% 50%, 
                ${color} 0deg, ${secondaryColor} 60deg, 
                ${color} 120deg, ${secondaryColor} 180deg,
                ${color} 240deg, ${secondaryColor} 300deg, ${color} 360deg
              )
            `,
            borderRadius: "50%",
          };
        case "luna":
          return {
            ...baseStyle,
            width: baseWidth * 1.2,
            height: baseHeight * 1.4,
            background: `
              radial-gradient(circle at 50% 30%, white 0%, ${color} 20%, ${secondaryColor} 100%)
            `,
            borderRadius: isLeft ? "50% 50% 70% 20%" : "50% 50% 20% 70%",
            opacity: 0.9,
          };
        default:
          return {
            ...baseStyle,
            background: `linear-gradient(${isLeft ? '135deg' : '-135deg'}, ${color}, ${color}80)`,
            borderRadius: isLeft ? "50% 50% 50% 0" : "50% 50% 0 50%",
          };
      }
    };

    return (
      <>
        {/* Left wing */}
        <motion.div
          className="absolute right-1/2 top-1/2 origin-right"
          style={getWingStyle(true)}
        />
        {/* Right wing */}
        <motion.div
          className="absolute left-1/2 top-1/2 origin-left"
          style={getWingStyle(false)}
        />
        {/* Lower wings for swallowtail and luna */}
        {(variety === "swallowtail" || variety === "luna") && (
          <>
            <motion.div
              className="absolute right-1/2 top-3/4 origin-right"
              style={{
                ...getWingStyle(true),
                width: baseWidth * 0.7,
                height: baseHeight * 0.6,
                transform: `rotateY(${wingFlap * 0.8}deg) translateY(-30%)`,
              }}
            />
            <motion.div
              className="absolute left-1/2 top-3/4 origin-left"
              style={{
                ...getWingStyle(false),
                width: baseWidth * 0.7,
                height: baseHeight * 0.6,
                transform: `rotateY(${-wingFlap * 0.8}deg) translateY(-30%)`,
              }}
            />
          </>
        )}
      </>
    );
  };

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 overflow-hidden pointer-events-auto cursor-crosshair"
      onMouseMove={handleMouseMove}
      onClick={handleClick}
    >
      {/* Fireflies - visible at night */}
      <AnimatePresence>
        {isNight && fireflies.map(firefly => (
          <motion.div
            key={`firefly-${firefly.id}`}
            className="absolute pointer-events-none z-30"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            transition={{ duration: 0.5, delay: firefly.id * 0.03 }}
            style={{
              left: firefly.x,
              top: firefly.y,
            }}
          >
            {/* Outer glow */}
            <motion.div
              className="absolute rounded-full"
              style={{
                width: firefly.size * 4,
                height: firefly.size * 4,
                left: -firefly.size * 1.5,
                top: -firefly.size * 1.5,
                background: `radial-gradient(circle, rgba(255, 255, 150, ${firefly.glowIntensity * 0.4}) 0%, transparent 70%)`,
              }}
            />
            {/* Inner glow */}
            <motion.div
              className="rounded-full"
              style={{
                width: firefly.size,
                height: firefly.size,
                background: `radial-gradient(circle, rgba(255, 255, 200, ${firefly.glowIntensity}) 0%, rgba(255, 230, 100, ${firefly.glowIntensity * 0.8}) 50%, transparent 100%)`,
                boxShadow: `0 0 ${firefly.size * 2}px rgba(255, 255, 150, ${firefly.glowIntensity}), 0 0 ${firefly.size * 4}px rgba(255, 230, 100, ${firefly.glowIntensity * 0.5})`,
              }}
            />
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Ambient particles */}
      {particles.map(particle => (
        <motion.div
          key={particle.id}
          className="absolute pointer-events-none"
          style={{
            left: particle.x,
            top: particle.y,
            opacity: isNight ? particle.opacity * 0.5 : particle.opacity,
          }}
          animate={{
            opacity: [particle.opacity, particle.opacity * 0.5, particle.opacity],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        >
          {particle.type === "pollen" && (
            <div
              className="rounded-full"
              style={{ 
                width: particle.size, 
                height: particle.size,
                background: isNight ? "rgba(255, 255, 200, 0.6)" : "#FDE68A",
              }}
            />
          )}
          {particle.type === "leaf" && (
            <Leaf
              className={isNight ? "text-emerald-400/40" : "text-lime-300/60"}
              style={{ width: particle.size * 2, height: particle.size * 2 }}
            />
          )}
        </motion.div>
      ))}

      {/* Plants with wind sway effect */}
      <AnimatePresence>
        {plants.map(plant => (
          <motion.div
            key={plant.id}
            className="absolute pointer-events-none"
            style={{
              left: plant.x,
              top: plant.y,
              transform: "translate(-50%, -100%)",
            }}
            initial={{ scale: 0, y: 20 }}
            animate={{ 
              scale: plant.scale, 
              y: 0,
              rotate: windIntensity * 15 * Math.sin(Date.now() * 0.002 + plant.id),
            }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{
              type: "spring",
              stiffness: 200,
              damping: 10,
              rotate: { duration: 0.3 },
            }}
          >
            <motion.div
              className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 bg-gradient-to-t from-green-700 to-green-500 rounded-full origin-bottom"
              style={{ height: 20 + plant.scale * 30, contain: 'layout', willChange: 'transform' }}
              initial={{ scaleY: 0 }}
              animate={{ 
                scaleY: 1,
                skewX: windIntensity * 10,
              }}
              transition={{ delay: 0.2, duration: 0.5 }}
            />
            
            <motion.div
              initial={{ scale: 0 }}
              animate={{ 
                scale: 1,
                rotate: windIntensity * 20 * Math.sin(Date.now() * 0.003 + plant.id * 2),
              }}
              transition={{ delay: 0.3, type: "spring" }}
              style={{ color: plant.color }}
            >
              {plant.type === "flower" && (
                <Flower2 className="w-8 h-8 drop-shadow-lg" style={{ filter: `drop-shadow(0 0 8px ${plant.color}40)` }} />
              )}
              {plant.type === "tree" && (
                <TreeDeciduous className="w-10 h-10 drop-shadow-lg" style={{ filter: `drop-shadow(0 0 8px ${plant.color}40)` }} />
              )}
              {plant.type === "sprout" && (
                <Leaf className="w-6 h-6 drop-shadow-lg" style={{ filter: `drop-shadow(0 0 8px ${plant.color}40)` }} />
              )}
            </motion.div>

            <motion.div
              className="absolute -top-2 -right-2"
              initial={{ scale: 0, opacity: 1 }}
              animate={{ scale: [0, 1.5, 0], opacity: [1, 0.5, 0] }}
              transition={{ duration: 0.8 }}
            >
              <div className="w-3 h-3 bg-yellow-300 rounded-full shadow-lg shadow-yellow-300/50" />
            </motion.div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Butterflies - only during day */}
      <AnimatePresence>
        {!isNight && butterflies.map(butterfly => {
          const distance = Math.hypot(butterfly.x - mousePos.x, butterfly.y - mousePos.y);
          const isGlowing = distance < 100;
          
          return (
            <motion.div
              key={butterfly.id}
              className="absolute pointer-events-none z-30"
              initial={{ opacity: 0, scale: 0 }}
              animate={{ 
                opacity: 1, 
                scale: isGlowing ? 1.3 : 1,
              }}
              exit={{ opacity: 0, scale: 0 }}
              transition={{ duration: 0.5, delay: butterfly.id * 0.05 }}
              style={{
                left: butterfly.x,
                top: butterfly.y,
                transform: "translate(-50%, -50%)",
              }}
            >
              {isGlowing && (
                <motion.div
                  className="absolute inset-0 -m-4 rounded-full"
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ 
                    opacity: [0.4, 0.8, 0.4],
                    scale: [1, 1.5, 1],
                  }}
                  transition={{ duration: 1, repeat: Infinity }}
                  style={{
                    background: `radial-gradient(circle, ${butterfly.color}60 0%, transparent 70%)`,
                    width: 60 * butterfly.size,
                    height: 60 * butterfly.size,
                    left: -22 * butterfly.size,
                    top: -20 * butterfly.size,
                  }}
                />
              )}
              
              <div className="relative" style={{ contain: 'layout' }}>
                {renderButterflyWings(butterfly, isGlowing)}
                {/* Body */}
                <div
                  className="relative rounded-full transition-shadow duration-300"
                  style={{ 
                    width: 2 * butterfly.size,
                    height: 8 * butterfly.size,
                    background: `linear-gradient(to bottom, ${butterfly.secondaryColor}, ${butterfly.color})`,
                    boxShadow: isGlowing ? `0 0 10px ${butterfly.color}` : 'none',
                    contain: 'strict',
                    willChange: 'transform',
                  }}
                />
                {/* Antennae */}
                <div
                  className="absolute -top-2 left-0"
                  style={{
                    width: 1,
                    height: 4 * butterfly.size,
                    background: butterfly.secondaryColor,
                    transform: "rotate(-30deg)",
                    transformOrigin: "bottom",
                    contain: 'strict',
                  }}
                />
                <div
                  className="absolute -top-2 right-0"
                  style={{
                    width: 1,
                    height: 4 * butterfly.size,
                    background: butterfly.secondaryColor,
                    transform: "rotate(30deg)",
                    transformOrigin: "bottom",
                    contain: 'strict',
                  }}
                />
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
