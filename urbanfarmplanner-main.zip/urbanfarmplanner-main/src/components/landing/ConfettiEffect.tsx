import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface ConfettiPiece {
  id: number;
  x: number;
  y: number;
  color: string;
  rotation: number;
  scale: number;
  shape: "square" | "circle" | "triangle";
  velocity: { x: number; y: number };
}

const confettiColors = [
  "#FF6B9D", "#FFB347", "#87CEEB", "#98D8C8", "#DDA0DD",
  "#FFD700", "#FF6347", "#00CED1", "#32CD32", "#FF69B4",
  "#9370DB", "#20B2AA", "#FFA500", "#7CFC00", "#FF1493"
];

interface ConfettiEffectProps {
  trigger: boolean;
  onComplete?: () => void;
}

export const ConfettiEffect = ({ trigger, onComplete }: ConfettiEffectProps) => {
  const [confetti, setConfetti] = useState<ConfettiPiece[]>([]);

  const createConfetti = useCallback(() => {
    const pieces: ConfettiPiece[] = [];
    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;

    for (let i = 0; i < 100; i++) {
      const angle = (Math.random() * Math.PI * 2);
      const velocity = 8 + Math.random() * 12;
      
      pieces.push({
        id: i,
        x: centerX,
        y: centerY,
        color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
        rotation: Math.random() * 360,
        scale: 0.5 + Math.random() * 0.8,
        shape: ["square", "circle", "triangle"][Math.floor(Math.random() * 3)] as ConfettiPiece["shape"],
        velocity: {
          x: Math.cos(angle) * velocity,
          y: Math.sin(angle) * velocity - 5, // Initial upward bias
        },
      });
    }

    setConfetti(pieces);

    // Clear confetti after animation
    setTimeout(() => {
      setConfetti([]);
      onComplete?.();
    }, 3000);
  }, [onComplete]);

  useEffect(() => {
    if (trigger) {
      createConfetti();
    }
  }, [trigger, createConfetti]);

  return (
    <AnimatePresence>
      {confetti.length > 0 && (
        <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
          {confetti.map((piece) => (
            <motion.div
              key={piece.id}
              className="absolute"
              initial={{
                x: piece.x,
                y: piece.y,
                rotate: piece.rotation,
                scale: 0,
                opacity: 1,
              }}
              animate={{
                x: piece.x + piece.velocity.x * 40,
                y: piece.y + piece.velocity.y * 40 + 300, // Gravity effect
                rotate: piece.rotation + (Math.random() > 0.5 ? 720 : -720),
                scale: piece.scale,
                opacity: [1, 1, 0],
              }}
              transition={{
                duration: 2.5 + Math.random() * 0.5,
                ease: [0.25, 0.46, 0.45, 0.94],
              }}
            >
              {piece.shape === "square" && (
                <div
                  className="w-3 h-3"
                  style={{
                    backgroundColor: piece.color,
                    boxShadow: `0 0 6px ${piece.color}`,
                  }}
                />
              )}
              {piece.shape === "circle" && (
                <div
                  className="w-3 h-3 rounded-full"
                  style={{
                    backgroundColor: piece.color,
                    boxShadow: `0 0 6px ${piece.color}`,
                  }}
                />
              )}
              {piece.shape === "triangle" && (
                <div
                  style={{
                    width: 0,
                    height: 0,
                    borderLeft: "6px solid transparent",
                    borderRight: "6px solid transparent",
                    borderBottom: `12px solid ${piece.color}`,
                    filter: `drop-shadow(0 0 4px ${piece.color})`,
                  }}
                />
              )}
            </motion.div>
          ))}
          
          {/* Center burst effect */}
          <motion.div
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
            initial={{ scale: 0, opacity: 1 }}
            animate={{ scale: 3, opacity: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="w-32 h-32 rounded-full bg-gradient-to-r from-emerald-400 via-yellow-300 to-pink-400 blur-2xl" />
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
