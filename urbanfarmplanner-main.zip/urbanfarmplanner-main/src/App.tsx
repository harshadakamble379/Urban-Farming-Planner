import React, { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { LocationProvider } from "@/contexts/LocationContext";
import { AnimatePresence, motion } from "framer-motion";

// Eager load Landing for best LCP
import Landing from "./pages/Landing";

// Lazy load other routes for code splitting with preload support
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Planning = lazy(() => import("./pages/Planning"));
const Plants = lazy(() => import("./pages/Plants"));
const Resources = lazy(() => import("./pages/Resources"));
const Inventory = lazy(() => import("./pages/Inventory"));
const Settings = lazy(() => import("./pages/Settings"));
const Auth = lazy(() => import("./pages/Auth"));
const NotFound = lazy(() => import("./pages/NotFound"));
const SharedGarden = lazy(() => import("./pages/SharedGarden"));
const Community = lazy(() => import("./pages/Community"));
const PlantIdentify = lazy(() => import("./pages/PlantIdentify"));

// Preload main routes after initial load for instant navigation
const preloadRoutes = () => {
  import("./pages/Dashboard");
  import("./pages/Planning");
  import("./pages/Inventory");
  import("./pages/Plants");
  import("./pages/Resources");
};

// Preload after initial render
if (typeof window !== "undefined") {
  if ("requestIdleCallback" in window) {
    (window as any).requestIdleCallback(preloadRoutes);
  } else {
    setTimeout(preloadRoutes, 1000);
  }
}

const queryClient = new QueryClient();

// Minimal loading fallback - ultra fast with no visible flash for quick loads
const PageLoader = () => (
  <div className="min-h-screen bg-background" />
);

// Page transition wrapper
const PageTransitionWrapper = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 6 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -6 }}
    transition={{ duration: 0.15, ease: "easeOut" }}
    className="w-full h-full"
  >
    {children}
  </motion.div>
);

// Animated routes component
const AnimatedRoutes = () => {
  const location = useLocation();
  
  return (
    <AnimatePresence mode="wait" initial={false}>
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Landing />} />
        <Route path="/auth" element={<PageTransitionWrapper><Auth /></PageTransitionWrapper>} />
        <Route path="/shared-garden/:token" element={<PageTransitionWrapper><SharedGarden /></PageTransitionWrapper>} />
        <Route path="/dashboard" element={<ProtectedRoute><PageTransitionWrapper><Dashboard /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="/planning" element={<ProtectedRoute><PageTransitionWrapper><Planning /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="/plants" element={<ProtectedRoute><PageTransitionWrapper><Plants /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="/resources" element={<ProtectedRoute><PageTransitionWrapper><Resources /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="/inventory" element={<ProtectedRoute><PageTransitionWrapper><Inventory /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><PageTransitionWrapper><Settings /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="/community" element={<ProtectedRoute><PageTransitionWrapper><Community /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="/identify" element={<ProtectedRoute><PageTransitionWrapper><PlantIdentify /></PageTransitionWrapper></ProtectedRoute>} />
        <Route path="*" element={<PageTransitionWrapper><NotFound /></PageTransitionWrapper>} />
      </Routes>
    </AnimatePresence>
  );
};

const App: React.FC = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <LocationProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Suspense fallback={<PageLoader />}>
              <AnimatedRoutes />
            </Suspense>
          </BrowserRouter>
        </TooltipProvider>
      </LocationProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
