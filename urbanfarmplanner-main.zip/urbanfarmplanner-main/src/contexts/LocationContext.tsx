import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

// Climate zone data with temperature ranges in Celsius
export const climateZones = [
  { id: "tropical", name: "Tropical", tempRange: "25-35°C", avgTemp: 30 },
  { id: "subtropical", name: "Subtropical", tempRange: "20-30°C", avgTemp: 25 },
  { id: "temperate", name: "Temperate", tempRange: "10-20°C", avgTemp: 15 },
  { id: "continental", name: "Continental", tempRange: "-5-25°C", avgTemp: 10 },
  { id: "polar", name: "Polar", tempRange: "-30-10°C", avgTemp: -10 },
  { id: "arid", name: "Arid/Desert", tempRange: "20-45°C", avgTemp: 32 },
  { id: "mediterranean", name: "Mediterranean", tempRange: "15-30°C", avgTemp: 22 },
];

// City data with coordinates and climate info
export const cityData: Record<string, { lat: number; lon: number; climate: string; avgTemp: number }> = {
  "New York": { lat: 40.7128, lon: -74.0060, climate: "temperate", avgTemp: 12 },
  "Los Angeles": { lat: 34.0522, lon: -118.2437, climate: "mediterranean", avgTemp: 18 },
  "London": { lat: 51.5074, lon: -0.1278, climate: "temperate", avgTemp: 11 },
  "Paris": { lat: 48.8566, lon: 2.3522, climate: "temperate", avgTemp: 12 },
  "Tokyo": { lat: 35.6762, lon: 139.6503, climate: "subtropical", avgTemp: 16 },
  "Sydney": { lat: -33.8688, lon: 151.2093, climate: "subtropical", avgTemp: 18 },
  "Dubai": { lat: 25.2048, lon: 55.2708, climate: "arid", avgTemp: 28 },
  "Singapore": { lat: 1.3521, lon: 103.8198, climate: "tropical", avgTemp: 27 },
  "Mumbai": { lat: 19.0760, lon: 72.8777, climate: "tropical", avgTemp: 27 },
  "Delhi": { lat: 28.6139, lon: 77.2090, climate: "subtropical", avgTemp: 25 },
  "Berlin": { lat: 52.5200, lon: 13.4050, climate: "temperate", avgTemp: 10 },
  "Moscow": { lat: 55.7558, lon: 37.6173, climate: "continental", avgTemp: 6 },
  "Beijing": { lat: 39.9042, lon: 116.4074, climate: "continental", avgTemp: 13 },
  "São Paulo": { lat: -23.5505, lon: -46.6333, climate: "subtropical", avgTemp: 20 },
  "Cairo": { lat: 30.0444, lon: 31.2357, climate: "arid", avgTemp: 22 },
  "Lagos": { lat: 6.5244, lon: 3.3792, climate: "tropical", avgTemp: 27 },
  "Bangkok": { lat: 13.7563, lon: 100.5018, climate: "tropical", avgTemp: 28 },
};

interface LocationSettings {
  city: string;
  climateZone: string;
  avgTemperature: number;
  currentTemperature: number;
  humidity: number;
  windSpeed: number;
  isLiveWeather: boolean;
  loading: boolean;
  lastUpdated: Date | null;
}

interface LocationContextType extends LocationSettings {
  updateCity: (city: string) => void;
  updateClimateZone: (zone: string) => void;
  refreshWeather: () => void;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export function LocationProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<LocationSettings>({
    city: "New York",
    climateZone: "Temperate (12°C avg)",
    avgTemperature: 12,
    currentTemperature: 15,
    humidity: 65,
    windSpeed: 0,
    isLiveWeather: false,
    loading: true,
    lastUpdated: null,
  });

  const fetchLiveWeather = useCallback(async (lat: number, lon: number) => {
    try {
      const { data, error } = await supabase.functions.invoke("get-weather", {
        body: { lat, lon },
      });

      if (error) {
        console.error("Weather fetch error:", error);
        return null;
      }

      return data;
    } catch (err) {
      console.error("Weather fetch failed:", err);
      return null;
    }
  }, []);

  const loadSettings = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setSettings(prev => ({ ...prev, loading: false }));
      return;
    }

    const { data } = await supabase
      .from("user_settings")
      .select("city, climate_zone")
      .eq("user_id", user.id)
      .maybeSingle();

    const city = data?.city || "New York";
    const cityInfo = cityData[city];
    const climate = cityInfo ? climateZones.find(z => z.id === cityInfo.climate) : null;

    // Fetch live weather data
    if (cityInfo) {
      const weatherData = await fetchLiveWeather(cityInfo.lat, cityInfo.lon);
      
      if (weatherData) {
        setSettings({
          city,
          climateZone: climate 
            ? `${climate.name} (${cityInfo.avgTemp}°C avg)` 
            : data?.climate_zone || "Temperate (12°C avg)",
          avgTemperature: cityInfo.avgTemp,
          currentTemperature: weatherData.temperature,
          humidity: weatherData.humidity,
          windSpeed: weatherData.windSpeed || 0,
          isLiveWeather: true,
          loading: false,
          lastUpdated: new Date(),
        });
        return;
      }
    }

    // Fallback to simulated weather if API fails
    const baseTemp = cityInfo?.avgTemp || 15;
    const variation = Math.random() * 6 - 3;

    setSettings({
      city,
      climateZone: climate 
        ? `${climate.name} (${cityInfo?.avgTemp || 15}°C avg)` 
        : data?.climate_zone || "Temperate (12°C avg)",
      avgTemperature: cityInfo?.avgTemp || 15,
      currentTemperature: Math.round(baseTemp + variation),
      humidity: 55 + Math.round(Math.random() * 30),
      windSpeed: Math.round(Math.random() * 20),
      isLiveWeather: false,
      loading: false,
      lastUpdated: new Date(),
    });
  }, [fetchLiveWeather]);

  useEffect(() => {
    loadSettings();

    // Refresh weather every 10 minutes
    const interval = setInterval(loadSettings, 10 * 60 * 1000);
    return () => clearInterval(interval);
  }, [loadSettings]);

  const updateCity = async (city: string) => {
    const cityInfo = cityData[city];
    const climate = cityInfo ? climateZones.find(z => z.id === cityInfo.climate) : null;
    
    setSettings(prev => ({ ...prev, loading: true }));

    // Fetch live weather for new city
    if (cityInfo) {
      const weatherData = await fetchLiveWeather(cityInfo.lat, cityInfo.lon);
      
      if (weatherData) {
        setSettings({
          city,
          climateZone: climate 
            ? `${climate.name} (${cityInfo.avgTemp}°C avg)` 
            : `Temperate (15°C avg)`,
          avgTemperature: cityInfo.avgTemp,
          currentTemperature: weatherData.temperature,
          humidity: weatherData.humidity,
          windSpeed: weatherData.windSpeed || 0,
          isLiveWeather: true,
          loading: false,
          lastUpdated: new Date(),
        });
      } else {
        // Fallback
        const baseTemp = cityInfo.avgTemp;
        const variation = Math.random() * 6 - 3;
        setSettings({
          city,
          climateZone: climate 
            ? `${climate.name} (${cityInfo.avgTemp}°C avg)` 
            : `Temperate (15°C avg)`,
          avgTemperature: cityInfo.avgTemp,
          currentTemperature: Math.round(baseTemp + variation),
          humidity: 55 + Math.round(Math.random() * 30),
          windSpeed: Math.round(Math.random() * 20),
          isLiveWeather: false,
          loading: false,
          lastUpdated: new Date(),
        });
      }
    }

    // Save to database
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase
        .from("user_settings")
        .upsert({
          user_id: user.id,
          city,
          climate_zone: climate ? `${climate.name} (${cityInfo?.avgTemp}°C avg)` : "Temperate (15°C avg)",
        }, { onConflict: "user_id" });
    }
  };

  const updateClimateZone = (zone: string) => {
    setSettings(prev => ({ ...prev, climateZone: zone }));
  };

  const refreshWeather = () => {
    loadSettings();
  };

  return (
    <LocationContext.Provider value={{ ...settings, updateCity, updateClimateZone, refreshWeather }}>
      {children}
    </LocationContext.Provider>
  );
}

export function useLocation() {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error("useLocation must be used within a LocationProvider");
  }
  return context;
}
